package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Reliable external backup layer.
 *
 * Live database: Android private app storage.
 * External backups: Download/Hesabdarman/ on shared storage.
 *
 * Two generations are kept:
 *  - hesabdar_database.db          = newest valid backup
 *  - hesabdar_database_previous.db = previous valid backup
 *
 * The external backup survives uninstall/reinstall. On a fresh install the app
 * never silently replaces a new database with old data; it detects a valid
 * external backup and asks the user whether it should be restored.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    const val LEGACY_NAME = "hesabdar_database"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            checkpoint(context)
            val source = DbHelper.databaseFile(context)
            if (!source.exists() || source.length() < 4096L) {
                error("پایگاه داده هنوز آماده پشتیبان‌گیری نیست")
            }
            validateDatabase(source)

            // Keep the previous valid backup before replacing the newest one.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                rotateMediaStoreBackups(context)
                writeMediaStoreFile(context, CANONICAL_NAME, source)
            } else {
                rotateLegacyBackups(source)
            }

            DatabaseManager.createRecoverySnapshot(context)
            if (!silent) {
                Toast.makeText(
                    context,
                    "پشتیبان خودکار در Download/Hesabdarman/$CANONICAL_NAME ذخیره شد.",
                    Toast.LENGTH_LONG
                ).show()
            }
            true
        } catch (e: Exception) {
            if (!silent) {
                Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message}", Toast.LENGTH_LONG).show()
            }
            false
        }
    }

    /**
     * Finds a valid external backup without changing the live database.
     * Used after reinstall/reset to offer an explicit restore choice.
     */
    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val names = listOf(CANONICAL_NAME, PREVIOUS_NAME, LEGACY_NAME)
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            for (name in names) {
                resolver.query(
                    collection,
                    arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
                    "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
                    arrayOf(RELATIVE_PATH, name),
                    "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val uri = Uri.withAppendedPath(collection, c.getLong(0).toString())
                        if (isValidUri(context, uri)) return uri
                    }
                }
            }
            null
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "Hesabdarman"
            )
            listOf(CANONICAL_NAME, PREVIOUS_NAME, LEGACY_NAME)
                .map { File(dir, it) }
                .firstOrNull { it.exists() && runCatching { validateDatabase(it); true }.getOrDefault(false) }
                ?.let { Uri.fromFile(it) }
        }
    }

    /** Restore an explicitly selected backup file. */
    fun restore(context: Context, uri: Uri): Boolean {
        val dbFile = DbHelper.databaseFile(context)
        val tmp = File(context.cacheDir, "restore_candidate.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
            } ?: error("فایل قابل خواندن نیست")

            validateDatabase(tmp)
            DbHelper.closeAll()
            dbFile.parentFile?.mkdirs()
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()

            // Atomic replacement: write beside the live database, validate again,
            // then replace it. A failed import can never leave a half-written DB.
            val replacement = File(dbFile.parentFile, "${dbFile.name}.restore.tmp")
            FileInputStream(tmp).use { input ->
                FileOutputStream(replacement, false).use { output -> input.copyTo(output) }
            }
            validateDatabase(replacement)
            if (dbFile.exists() && !dbFile.delete()) error("پایگاه داده فعلی قابل جایگزینی نیست")
            if (!replacement.renameTo(dbFile)) {
                FileInputStream(tmp).use { input ->
                    FileOutputStream(dbFile, false).use { output -> input.copyTo(output) }
                }
                replacement.delete()
            }
            tmp.delete()
            // Immediately refresh the canonical external backup from restored data.
            backup(context, true)
            true
        } catch (e: Exception) {
            tmp.delete()
            File(dbFile.parentFile, "${dbFile.name}.restore.tmp").delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun checkpoint(context: Context) {
        val helper = DbHelper(context)
        try {
            helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
        } finally {
            helper.close()
        }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf(
                "folders", "notebooks", "tx", "invoices", "invoice_items",
                "installment_plans", "installment_items", "checks"
            )
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use {
                while (it.moveToNext()) found += it.getString(0)
            }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")

            val quickOk = db.rawQuery("PRAGMA quick_check", null).use {
                it.moveToFirst() && it.getString(0).equals("ok", true)
            }
            if (!quickOk) error("فایل پشتیبان آسیب‌دیده است")

            val version = db.rawQuery("PRAGMA user_version", null).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (version > DbHelper.DATABASE_VERSION) {
                error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
            }
        } finally {
            db.close()
        }
    }

    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val tmp = File(context.cacheDir, "backup_probe.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
            } ?: return false
            validateDatabase(tmp)
            true
        } catch (_: Exception) {
            false
        } finally {
            tmp.delete()
        }
    }

    private fun findMediaStoreFile(context: Context, name: String): Uri? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH, name),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            if (c.moveToFirst()) return Uri.withAppendedPath(collection, c.getLong(0).toString())
        }
        return null
    }

    private fun writeMediaStoreFile(context: Context, name: String, source: File) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        var uri = findMediaStoreFile(context, name)
        if (uri == null) {
            uri = resolver.insert(collection, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")
        }

        val temp = File(context.cacheDir, "$name.write.tmp")
        FileInputStream(source).use { input ->
            FileOutputStream(temp, false).use { output -> input.copyTo(output) }
        }
        // Validate the exact bytes before exposing them as the public backup.
        validateDatabase(temp)
        resolver.openOutputStream(uri, "wt")?.use { output ->
            FileInputStream(temp).use { input -> input.copyTo(output) }
        } ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")
        temp.delete()
        resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    }

    private fun rotateMediaStoreBackups(context: Context) {
        val primary = findMediaStoreFile(context, CANONICAL_NAME)
        if (primary != null && isValidUri(context, primary)) {
            val source = File(context.cacheDir, "previous_backup_source.db")
            try {
                context.contentResolver.openInputStream(primary)?.use { input ->
                    FileOutputStream(source, false).use { output -> input.copyTo(output) }
                } ?: return
                validateDatabase(source)
                writeMediaStoreFile(context, PREVIOUS_NAME, source)
            } finally {
                source.delete()
            }
        }
    }

    private fun rotateLegacyBackups(source: File) {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "Hesabdarman"
        )
        if (!dir.exists()) dir.mkdirs()
        val primary = File(dir, CANONICAL_NAME)
        val previous = File(dir, PREVIOUS_NAME)
        if (primary.exists() && runCatching { validateDatabase(primary); true }.getOrDefault(false)) {
            primary.copyTo(previous, overwrite = true)
        }
        source.copyTo(primary, overwrite = true)
        // Keep legacy extensionless name synchronized for old file managers.
        source.copyTo(File(dir, LEGACY_NAME), overwrite = true)
    }
}
