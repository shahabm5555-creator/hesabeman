package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FolderGridAdapter(
    private var items: List<FolderItem>,
    private val onClick: (FolderItem) -> Unit,
    private val onLongClick: (FolderItem) -> Unit
) : RecyclerView.Adapter<FolderGridAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.folderCard)
        val iconBg: View = view.findViewById(R.id.folderIconBg)
        val order: TextView = view.findViewById(R.id.folderOrder)
        val name: TextView = view.findViewById(R.id.folderName)
        val count: TextView = view.findViewById(R.id.folderCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder_grid, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]

        holder.name.text = item.name
        holder.count.text = "${item.notebookCount} حساب"
        holder.order.text = item.sortOrder.toString()

        val parsed = try {
            Color.parseColor(item.color)
        } catch (_: Exception) {
            Color.parseColor("#4B9B7C")
        }
        val surface = ContextCompat.getColor(holder.itemView.context, R.color.surface)

        // Solid color for the icon badge / order chip / count pill so every category reads
        // clearly regardless of how pale or saturated its base color is.
        val solid = ColorStateList.valueOf(parsed)
        // Soft tinted card body + a visibly stronger stroke, so cards are always distinguishable
        // from the plain background, not just barely-there pastel like before.
        val cardTint = ColorUtils.blendARGB(surface, parsed, 0.14f)
        val strokeTint = ColorUtils.blendARGB(parsed, surface, 0.55f)

        holder.card.setCardBackgroundColor(cardTint)
        holder.card.strokeColor = strokeTint
        holder.iconBg.backgroundTintList = solid
        holder.order.backgroundTintList = solid
        holder.count.backgroundTintList = solid
        holder.name.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text))

        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size

    fun submit(newItems: List<FolderItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
