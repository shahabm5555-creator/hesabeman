# Hesabdar Personal v1.0.0 — Backup/Restore Fix

## Important behavior

- Live SQLite database stays in Android private app storage.
- External durable backup is stored in `Download/Hesabdarman/` using MediaStore on Android 10+.
- Canonical backup: `hesabdar_database.db`
- Previous backup: `hesabdar_database_previous.db`
- The app **never creates or overwrites an external backup during startup**.
- On a fresh installation, if a valid backup is already present, the app offers to restore it.
- Manual restore accepts a backup selected through Android's file picker, including a backup copied or moved to another folder.
- Automatic backup is triggered after successful database writes and is flushed when an activity stops.
- The flush waits for the backup job, reducing the chance that a process death loses the newest backup.
- Backup files are validated with SQLite `quick_check` and required application tables before they are accepted.
- The current canonical file is never overwritten in-place. A complete temporary MediaStore entry is written and validated first; only then is the old canonical entry removed and the new entry published.
- A second local recovery snapshot is maintained in app-private storage for crash recovery while the app remains installed.

## Why the previous version lost the old backup after reinstall

The previous build called the automatic backup scheduler from `MainActivity.onCreate()`. After reinstall, Android creates a new empty private database. That startup call then copied the empty database to the canonical external backup, replacing the real backup before the user could restore it.

This version removes that startup backup call and instead detects a fresh database and offers restoration from the existing external backup.

## Recommended test

1. Install fresh.
2. Create at least two users, folders with different colors, transactions, a check, an invoice, and an installment.
3. Close/open the app and confirm the backup file exists in `Download/Hesabdarman/`.
4. Copy the backup to a second folder as an extra safety copy.
5. Uninstall the app.
6. Reinstall the app.
7. On first launch, accept `پشتیبان قبلی پیدا شد`.
8. Confirm all users, folders/colors, transactions, checks, invoices, installments, and settings that are stored in the database are present.
9. Repeat using Settings > `بازیابی پشتیبان` and select the copied backup from another folder.
10. Verify that a failed/invalid file is rejected without damaging the current database.
