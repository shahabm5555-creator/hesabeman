package com.mobileshahab.hesabeman

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Debounced automatic backup. Any screen can request a backup after a data change.
 * The actual filesystem/database work is off the main thread.
 */
object BackupScheduler {
    private const val DELAY_MS = 1200L
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val dirty = AtomicBoolean(false)
    private var appContext: Context? = null

    @Synchronized
    fun request(context: Context) {
        appContext = context.applicationContext
        if (!AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) return
        dirty.set(true)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ runBackup(false) }, DELAY_MS)
    }

    @Synchronized
    fun flush(context: Context) {
        appContext = context.applicationContext
        if (!dirty.get()) return
        handler.removeCallbacksAndMessages(null)
        // Activity.onStop may be followed by process death. Wait for the backup
        // task here so a successful database write is not left only in RAM/WAL.
        runBackup(true)
    }

    private fun runBackup(wait: Boolean) {
        val context = appContext ?: return
        if (!dirty.compareAndSet(true, false)) return
        val future = executor.submit { BackupManager.backup(context, silent = true) }
        if (wait) runCatching { future.get(15, java.util.concurrent.TimeUnit.SECONDS) }
    }
}
