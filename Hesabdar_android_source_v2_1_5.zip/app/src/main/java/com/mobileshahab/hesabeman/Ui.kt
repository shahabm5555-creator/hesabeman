package com.mobileshahab.hesabeman

import android.app.TimePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

private fun normalizeDigits(value: String): String = value.map {
    when (it) {
        in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
        else -> it
    }
}.joinToString("")

private fun formatAmountInput(value: String): String {
    val digits = normalizeDigits(value).filter(Char::isDigit).trimStart('0').ifEmpty { "0" }
    // Group manually with a literal ASCII comma instead of String.format/Locale — on some
    // OEM ROMs (custom Persian firmware) the "en_US" locale's number symbols get overridden
    // system-wide, so Locale-based formatting can silently emit Persian digits/separators,
    // which then fails to be recognized as a valid amount.
    return groupDigits(digits)
}

private fun groupDigits(digits: String): String {
    val sb = StringBuilder()
    for ((i, c) in digits.reversed().withIndex()) {
        if (i > 0 && i % 3 == 0) sb.append(',')
        sb.append(c)
    }
    return sb.reverse().toString()
}

private fun dp(context: Context, value: Int) = (value * context.resources.displayMetrics.density).toInt()

private fun rounded(fill: Int, stroke: Int? = null, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
    setColor(fill); cornerRadius = radius
    if (stroke != null) setStroke((Resources.getSystem().displayMetrics.density * 1.5f).toInt().coerceAtLeast(2), stroke)
}

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint; textDirection = View.TEXT_DIRECTION_RTL; textSize = 16f
        setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 18)); background = rounded(Color.WHITE, Color.rgb(225, 234, 231), 16f)
    }
    val wrap = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(context, 20), dp(context, 4), dp(context, 20), 0) }
    wrap.addView(input, LinearLayout.LayoutParams(-1, dp(context, 58)))
    MaterialAlertDialogBuilder(context).setTitle(title).setView(wrap)
        .setPositiveButton("ثبت") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(context, 20), dp(context, 8), dp(context, 20), 0) }
    fun field(hint: String, type: Int) = EditText(context).apply {
        this.hint = hint; inputType = type; textSize = 15f; minHeight = dp(context, 56); gravity = Gravity.CENTER_VERTICAL or Gravity.END
        background = rounded(Color.WHITE, Color.rgb(225, 234, 231), 16f); setPadding(dp(context, 16), 0, dp(context, 16), 0)
    }
    val name = field("نام شخص / حساب", InputType.TYPE_CLASS_TEXT)
    val phone = field("شماره موبایل (اختیاری)", InputType.TYPE_CLASS_PHONE)
    box.addView(name); box.addView(gap(context, 8)); box.addView(phone)
    MaterialAlertDialogBuilder(context).setTitle("حساب جدید").setView(box)
        .setPositiveButton("ساخت حساب") { _, _ -> name.text.toString().trim().takeIf { it.isNotEmpty() }?.let { done(it, normalizeDigits(phone.text.toString().trim())) } }
        .setNegativeButton("انصراف", null).show()
}

fun promptOrder(context: Context, title: String, current: Int, max: Int, done: (Int) -> Unit) {
    val input = EditText(context).apply { hint = "۱ تا $max"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 17f; minHeight = dp(context, 58); setText(current.toString()); selectAll() }
    MaterialAlertDialogBuilder(context).setTitle(title).setMessage("ردیف جدید را وارد کنید.").setView(input)
        .setPositiveButton("انتقال") { _, _ -> input.text.toString().toIntOrNull()?.takeIf { it in 1..max }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

private fun gap(context: Context, height: Int) = View(context).apply { layoutParams = LinearLayout.LayoutParams(1, dp(context, height)) }

fun promptTransaction(
    context: Context,
    title: String,
    initialKind: String = "debt",
    initialAmount: Long? = null,
    initialNote: String = "",
    initialDateTime: String = Jalali.now(),
    done: (String, Long, String, String) -> Unit
) {
    val sheet = BottomSheetDialog(context)
    val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        setBackgroundColor(Color.WHITE); setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 14))
    }
    // On API 35+ (targetSdk 35) edge-to-edge is enforced by default, so this sheet can be
    // drawn behind a 3-button navigation bar unless we add matching bottom padding ourselves.
    val basePad = dp(context, 14)
    androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
        val navBar = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()).bottom
        v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, basePad + navBar)
        insets
    }

    val handle = View(context).apply { background = rounded(Color.rgb(205, 218, 214), null, 20f) }
    root.addView(handle, LinearLayout.LayoutParams(dp(context, 42), dp(context, 5)).apply { gravity = Gravity.CENTER; bottomMargin = dp(context, 8) })

    val header = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
    val titleView = TextView(context).apply { text = if (title.contains("ویرایش")) "ویرایش تراکنش" else "ثبت تراکنش جدید"; textSize = 19f; setTextColor(Color.rgb(31, 47, 45)); gravity = Gravity.CENTER; setTypeface(typeface, android.graphics.Typeface.BOLD) }
    val close = MaterialButton(context).apply { text = "×"; textSize = 24f; setTextColor(Color.rgb(105, 120, 117)); backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT); minWidth = 0; insetTop = 0; insetBottom = 0; setPadding(0, 0, 0, 0); setOnClickListener { sheet.dismiss() } }
    header.addView(titleView, LinearLayout.LayoutParams(0, dp(context, 48), 1f)); header.addView(close, LinearLayout.LayoutParams(dp(context, 48), dp(context, 48)))
    root.addView(header)
    root.addView(gap(context, 2))

    val typeGroup = RadioGroup(context).apply { orientation = RadioGroup.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER; setPadding(dp(context, 2), dp(context, 2), dp(context, 2), dp(context, 2)) }
    val debt = RadioButton(context).apply {
        id = View.generateViewId(); text = "↑  پرداخت کردم"; textSize = 13f; gravity = Gravity.CENTER; includeFontPadding = false; minHeight = dp(context, 52); maxLines = 1
        buttonTintList = ColorStateList.valueOf(Color.rgb(220, 91, 91)); setPadding(dp(context, 8), 0, dp(context, 8), 0)
    }
    val credit = RadioButton(context).apply {
        id = View.generateViewId(); text = "↓  دریافت کردم"; textSize = 13f; gravity = Gravity.CENTER; includeFontPadding = false; minHeight = dp(context, 52); maxLines = 1
        buttonTintList = ColorStateList.valueOf(Color.rgb(52, 160, 104)); setPadding(dp(context, 8), 0, dp(context, 8), 0)
    }
    typeGroup.addView(debt, RadioGroup.LayoutParams(0, dp(context, 52), 1f).apply { marginEnd = dp(context, 4) })
    typeGroup.addView(credit, RadioGroup.LayoutParams(0, dp(context, 52), 1f).apply { marginStart = dp(context, 4) })
    typeGroup.check(if (initialKind == "credit") credit.id else debt.id)
    fun syncType() {
        debt.background = rounded(if (debt.isChecked) Color.rgb(255, 238, 238) else Color.WHITE, if (debt.isChecked) Color.rgb(225, 111, 111) else Color.rgb(231, 238, 236), 16f)
        credit.background = rounded(if (credit.isChecked) Color.rgb(234, 249, 241) else Color.WHITE, if (credit.isChecked) Color.rgb(82, 177, 123) else Color.rgb(224, 235, 231), 16f)
    }
    typeGroup.setOnCheckedChangeListener { _, _ -> syncType(); val selected = if (credit.isChecked) credit else debt; selected.animate().scaleX(1.02f).scaleY(1.02f).setDuration(90).withEndAction { selected.animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start() }
    syncType(); root.addView(typeGroup)

    fun field(hint: String, size: Float = 14f): EditText = EditText(context).apply {
        this.hint = hint; textSize = size; gravity = Gravity.CENTER_VERTICAL or Gravity.END; includeFontPadding = false
        background = rounded(Color.WHITE, Color.rgb(189, 207, 202), 15f); setPadding(dp(context, 16), 0, dp(context, 16), 0)
    }

    root.addView(gap(context, 6))
    val amount = field("مبلغ به تومان", 17f).apply {
        // TYPE_CLASS_PHONE: a dial-pad style numeric keypad. Chosen over TYPE_CLASS_NUMBER
        // (which some ROMs' numeric keypad refuses to accept any input on) and over plain
        // TYPE_CLASS_TEXT (whose keyboard flips back to letters after a few digits on some
        // MIUI/Xiaomi keyboards). The dial pad only ever shows digits, avoiding both issues.
        // Any stray dial characters (+, *, #, -) are stripped by the TextWatcher below anyway.
        inputType = InputType.TYPE_CLASS_PHONE; imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        filters = arrayOf(InputFilter.LengthFilter(24)); setText(initialAmount?.let { groupDigits(it.toString()) } ?: ""); setSelection(text.length)
        addTextChangedListener(object : TextWatcher { var busy = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(e: Editable?) { if (busy) return; val f = formatAmountInput(e?.toString().orEmpty()); if (e?.toString() != f) { busy = true; setText(f); setSelection(text.length); busy = false } }
        })
    }
    root.addView(label(context, "مبلغ")); root.addView(amount, LinearLayout.LayoutParams(-1, dp(context, 52)))
    root.addView(gap(context, 5))
    val note = field("توضیحات (اختیاری)", 14f).apply { setSingleLine(true); setText(initialNote) }
    root.addView(label(context, "شرح")); root.addView(note, LinearLayout.LayoutParams(-1, dp(context, 52)))
    root.addView(gap(context, 5))

    val parts = initialDateTime.split(" - ")
    val date = field("تاریخ شمسی", 13f).apply { isFocusable = false; isClickable = true; setText(parts.getOrNull(0).orEmpty()); setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_calendar_color, 0); compoundDrawablePadding = dp(context, 7); setOnClickListener { showJalaliDatePicker(context, text.toString()) { setText(it) } } }
    val time = field("ساعت", 13f).apply { isFocusable = false; isClickable = true; setText(parts.getOrNull(1).orEmpty()); setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_clock_color, 0); compoundDrawablePadding = dp(context, 7); setOnClickListener { showTimePicker(context, text.toString()) { setText(it) } } }
    val dt = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
    dt.addView(date, LinearLayout.LayoutParams(0, dp(context, 54), 1f).apply { marginStart = dp(context, 2) })
    dt.addView(time, LinearLayout.LayoutParams(0, dp(context, 54), 1f).apply { marginEnd = dp(context, 2) })
    root.addView(label(context, "زمان ثبت")); root.addView(dt)
    root.addView(gap(context, 7))

    val submit = MaterialButton(context).apply {
        text = "ثبت تراکنش  ✓"; textSize = 14f; minHeight = dp(context, 52); cornerRadius = dp(context, 15); backgroundTintList = ColorStateList.valueOf(Color.rgb(22, 124, 120)); setTextColor(Color.WHITE)
    }
    root.addView(submit, LinearLayout.LayoutParams(-1, dp(context, 52)))
    submit.setOnClickListener {
        val a = normalizeDigits(amount.text.toString()).replace(",", "").toLongOrNull()
        val d = normalizeDigits(date.text.toString().trim())
        val t = normalizeDigits(time.text.toString().trim())
        val now = Jalali.now()
        val finalDate = if (d.isBlank()) now.substringBefore(" - ") else d
        val finalTime = if (t.isBlank()) now.substringAfter(" - ") else t
        when {
            a == null || a <= 0L -> Toast.makeText(context, "مبلغ معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
            !Jalali.isValidDate(finalDate) -> Toast.makeText(context, "تاریخ شمسی معتبر نیست.", Toast.LENGTH_SHORT).show()
            !Jalali.isValidTime(finalTime) -> Toast.makeText(context, "ساعت معتبر نیست.", Toast.LENGTH_SHORT).show()
            else -> { done(if (debt.isChecked) "debt" else "credit", a, note.text.toString().trim(), "$finalDate - $finalTime"); sheet.dismiss() }
        }
    }

    sheet.setContentView(root)
    sheet.setOnShowListener {
        val bottom = sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        bottom?.setBackgroundColor(Color.TRANSPARENT)
        root.alpha = 0f; root.translationY = dp(context, 24).toFloat(); root.animate().alpha(1f).translationY(0f).setDuration(220).start()
    }
    sheet.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    sheet.show()
}

private fun label(context: Context, text: String) = TextView(context).apply { this.text = text; textSize = 10f; setTextColor(Color.rgb(111, 127, 124)); gravity = Gravity.END; setPadding(dp(context, 3), 0, dp(context, 3), dp(context, 4)) }

private fun showJalaliDatePicker(context: Context, current: String, title: String = "انتخاب تاریخ شمسی", done: (String) -> Unit) {
    val now = Jalali.now().substringBefore(" - "); val source = if (Jalali.isValidDate(current)) current else now; val parts = source.split("/")
    val year = parts.getOrNull(0)?.toIntOrNull() ?: 1405; val month = parts.getOrNull(1)?.toIntOrNull() ?: 1; val day = parts.getOrNull(2)?.toIntOrNull() ?: 1
    val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(dp(context, 8), dp(context, 4), dp(context, 8), dp(context, 4)) }
    fun noManualEntry(p: NumberPicker) { p.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS }
    val y = NumberPicker(context).apply { minValue = 1200; maxValue = 1600; value = year; wrapSelectorWheel = false; noManualEntry(this) }
    val m = NumberPicker(context).apply { minValue = 1; maxValue = 12; value = month; wrapSelectorWheel = false; noManualEntry(this) }
    val d = NumberPicker(context).apply { minValue = 1; maxValue = jalaliMonthDays(year, month); value = day.coerceAtMost(maxValue); wrapSelectorWheel = false; noManualEntry(this) }
    fun sync() { d.maxValue = jalaliMonthDays(y.value, m.value); if (d.value > d.maxValue) d.value = d.maxValue }
    y.setOnValueChangedListener { _, _, _ -> sync() }; m.setOnValueChangedListener { _, _, _ -> sync() }
    row.addView(d, LinearLayout.LayoutParams(dp(context, 82), dp(context, 150))); row.addView(m, LinearLayout.LayoutParams(dp(context, 82), dp(context, 150))); row.addView(y, LinearLayout.LayoutParams(dp(context, 100), dp(context, 150)))
    MaterialAlertDialogBuilder(context).setTitle(title).setView(row).setPositiveButton("انتخاب") { _, _ -> done("%04d/%02d/%02d".format(y.value, m.value, d.value)) }.setNegativeButton("انصراف", null).show()
}

private fun jalaliMonthDays(year: Int, month: Int) = when { month in 1..6 -> 31; month in 7..11 -> 30; else -> if (Jalali.isValidDate("%04d/12/30".format(year))) 30 else 29 }

// Public wrapper so other files (e.g. NotebookActivity) can open the same
// spinner-only Jalali calendar used for the transaction date, instead of a free-text prompt.
fun promptJalaliDate(context: Context, current: String, done: (String) -> Unit) = showJalaliDatePicker(context, current, "انتخاب تاریخ سررسید", done)

private fun showTimePicker(context: Context, current: String, done: (String) -> Unit) {
    val parts = normalizeDigits(current).split(":"); val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY); val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE)
    TimePickerDialog(context, { _: android.widget.TimePicker, h: Int, m: Int -> done("%02d:%02d".format(h, m)) }, hour, minute, true).show()
}
