package com.mobileshahab.hesabeman

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class HesabemanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // این برنامه فقط تم روشن دارد. برخی گوشی‌ها (مثلاً با حالت تاریک اجباری سیستم)
        // بدون این خط، رنگ‌ها و فونت‌ها را نادرست یا نامرئی نمایش می‌دهند.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
    }
}
