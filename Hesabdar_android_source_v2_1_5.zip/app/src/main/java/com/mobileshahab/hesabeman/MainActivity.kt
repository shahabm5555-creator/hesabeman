package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.util.TypedValue
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter
    private var dueShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        b.summaryTitle.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
        b.totalDebt.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f)
        b.totalCredit.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f)
        b.debtLabel.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
        b.creditLabel.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
        b.debtorLabel.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
        b.creditorLabel.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
        b.debtorCount.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
        b.creditorCount.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
        adapter = FolderGridAdapter(emptyList(),
            onClick = { startActivity(Intent(this, FolderActivity::class.java).putExtra("folder_id", it.id).putExtra("folder_name", it.name)) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = GridLayoutManager(this, 2); b.list.adapter = adapter
        b.add.setOnClickListener {
            if (db.countFolders(null) >= DbHelper.MAX_FOLDERS) {
                Toast.makeText(this, "حداکثر ۳۰ پوشه مجاز است.", Toast.LENGTH_LONG).show()
            } else {
                promptText(this, "پوشه جدید", "نام پوشه") { name -> if (db.addFolder(null, name)) refresh() }
            }
        }
        b.searchButton.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ", "تغییر ردیف", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
                2 -> changeFolderRow(item)
                3 -> MaterialAlertDialogBuilder(this)
                    .setTitle("حذف پوشه")
                    .setMessage("پوشه و حساب‌های داخل آن تا ۵ روز در سطل زباله قابل بازیابی هستند.")
                    .setPositiveButton("حذف") { _, _ -> db.trashFolder(item.id); refresh() }
                    .setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        val names = arrayOf("سبز ملایم", "آبی ملایم", "کرم", "بنفش ملایم", "صورتی ملایم", "خاکستری روشن")
        val colors = arrayOf("#CFE8D8", "#D1E4F2", "#F0E6C9", "#E4D8EF", "#F1D5DD", "#DDE3E5")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which ->
            db.setFolderColor(item.id, colors[which]); refresh()
        }.show()
    }

    private fun changeFolderRow(item: FolderItem) {
        val max = db.countFolders(null).coerceAtLeast(1)
        promptOrder(this, "تغییر ردیف پوشه", item.sortOrder, max) { newRow ->
            db.setFolderOrder(item.id, newRow)
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        db.purgeExpiredTrash()
        refresh()
        if (!dueShown) { dueShown = true; showDueReminder() } // v2.1.5 patched
    }

    private fun showDueReminder() {
        val today = Jalali.now().substringBefore(" - ")
        val due = db.dueNotebooks(today)
        if (due.isEmpty()) return
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val checks = mutableMapOf<Long, android.widget.CheckBox>()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        due.forEachIndexed { idx, n ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(12), dp(10), dp(12), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.rgb(255, 248, 235))
                    cornerRadius = dp(12).toFloat()
                }
            }
            row.addView(android.widget.TextView(this).apply {
                text = "${n.name} — ${"%,d".format(kotlin.math.abs(n.balance))} تومان\nسررسید: ${n.dueDate}"
                textSize = 13f; setTextColor(android.graphics.Color.rgb(42, 49, 47))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            val check = android.widget.CheckBox(this).apply {
                text = "دیگر برای سررسید همین تاریخ این حساب نمایش نده"
                textSize = 11f; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(2), dp(6), dp(2), 0)
            }
            checks[n.id] = check
            row.addView(check)
            box.addView(row)
            if (idx != due.lastIndex) box.addView(android.widget.Space(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(-1, dp(8))
            })
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(box)
            layoutParams = android.view.ViewGroup.LayoutParams(-1, if (due.size > 4) dp(360) else android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("یادآوری سررسید بدهی (${due.size} حساب)")
            .setView(scroll)
            .setPositiveButton("بررسی شد") { _, _ ->
                checks.forEach { (id, cb) -> if (cb.isChecked) db.ackDueReminder(id) }
            }.show()
    }

    private fun refresh() {
        val items = db.folderItems(); adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val s = db.accountSummary()
        b.totalDebt.text = "${formatMoney(s.totalDebt)} تومان"
        b.totalCredit.text = "${formatMoney(s.totalCredit)} تومان"
        b.debtorCount.text = "${s.debtors} نفر"
        b.creditorCount.text = "${s.creditors} نفر"
    }

    private fun formatMoney(value: Long) = "%,d".format(value)
}
