package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InvoiceListActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1
    private var notebookName = ""
    private var notebookPhone = ""
    private lateinit var listContainer: LinearLayout
    private var pendingShareInv: DbHelper.InvoiceHeader? = null

    private val pdfSaveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) pendingShareInv?.let { exportAndShare(it, uri, share = false) }
    }
    private val pdfShareLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) pendingShareInv?.let { exportAndShare(it, uri, share = true) }
    }
    private val newInvoiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) loadList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""
        notebookPhone = intent.getStringExtra("notebook_phone") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(color(R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, ins ->
                val b = ins.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, b.top, 0, b.bottom); ins
            }
        }

        // Toolbar
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(color(R.color.surface))
            layoutParams = LinearLayout.LayoutParams(-1, dp(60))
            addView(MaterialButton(this@InvoiceListActivity).apply {
                text = "×"; textSize = 22f; minWidth = 0; insetTop = 0; insetBottom = 0
                setPadding(dp(14), 0, dp(14), 0)
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(color(R.color.text))
                layoutParams = LinearLayout.LayoutParams(-2, -1)
                setOnClickListener { finish() }
            })
            addView(TextView(this@InvoiceListActivity).apply {
                text = "فاکتورهای $notebookName"; textSize = 15f; gravity = Gravity.CENTER
                setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(MaterialButton(this@InvoiceListActivity).apply {
                text = "+ جدید"; textSize = 12f; cornerRadius = dp(14); insetTop = 0; insetBottom = 0
                setPadding(dp(12), 0, dp(12), 0)
                layoutParams = LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(10) }
                setOnClickListener {
                    newInvoiceLauncher.launch(Intent(this@InvoiceListActivity, InvoiceActivity::class.java).apply {
                        putExtra("notebook_id", notebookId)
                        putExtra("notebook_name", notebookName)
                        putExtra("notebook_phone", notebookPhone)
                    })
                }
            })
        })

        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(16))
        }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadList()
    }

    private fun loadList() {
        listContainer.removeAllViews()
        val invoices = db.invoices(notebookId)
        if (invoices.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "هیچ فاکتوری ثبت نشده"; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(color(R.color.secondary)); setPadding(0, dp(40), 0, 0)
            }); return
        }
        invoices.forEach { inv -> listContainer.addView(buildInvoiceCard(inv)) }
    }

    private fun buildInvoiceCard(inv: DbHelper.InvoiceHeader): View {
        val card = MaterialCardView(this).apply {
            radius = dp(16).toFloat(); cardElevation = dp(2).toFloat()
            setCardBackgroundColor(color(R.color.surface))
            strokeWidth = dp(1); strokeColor = color(R.color.divider)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // ── Top row: pill + number + date ──
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val isDebt = inv.kind == "debt"
        topRow.addView(TextView(this).apply {
            text = if (isDebt) "↑ پرداختی" else "↓ دریافتی"; textSize = 10f
            setTextColor(color(if (isDebt) R.color.debt_text else R.color.credit_text))
            backgroundTintList = ColorStateList.valueOf(color(if (isDebt) R.color.debt_soft else R.color.credit_soft))
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_status_pill)
            setPadding(dp(8), dp(3), dp(8), dp(3))
        })
        topRow.addView(TextView(this).apply {
            text = "  فاکتور شماره ${inv.number}"; textSize = 14f
            setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        topRow.addView(TextView(this).apply {
            text = inv.createdAt; textSize = 10f; setTextColor(color(R.color.secondary))
        })
        box.addView(topRow)

        // ── Amounts ──
        val remaining = (inv.total - inv.prepay).coerceAtLeast(0L)
        val amtRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }
        amtRow.addView(TextView(this).apply {
            text = "جمع: %,d تومان".format(inv.total); textSize = 12f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        amtRow.addView(TextView(this).apply {
            text = "مانده: %,d تومان".format(remaining); textSize = 13f
            setTextColor(color(R.color.primary)); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(amtRow)

        // ── Prepay + due date ──
        if (inv.prepay > 0 || inv.dueDate.isNotBlank()) {
            val extraRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
            }
            if (inv.prepay > 0) extraRow.addView(TextView(this).apply {
                text = "پیش‌پرداخت: %,d".format(inv.prepay); textSize = 11f
                setTextColor(color(R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            if (inv.dueDate.isNotBlank()) extraRow.addView(TextView(this).apply {
                text = "سررسید: ${inv.dueDate}"; textSize = 11f
                setTextColor(color(R.color.orange))
            })
            box.addView(extraRow)
        }

        // ── Items summary ──
        val invItems = db.invoiceItems(inv.id)
        if (invItems.isNotEmpty()) {
            val divider = View(this).apply {
                setBackgroundColor(color(R.color.divider))
                layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(6) }
            }
            box.addView(divider)
            invItems.take(3).forEach { item ->
                box.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) }
                    addView(TextView(this@InvoiceListActivity).apply {
                        text = "• ${item.name}"; textSize = 11f
                        setTextColor(color(R.color.text))
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    })
                    addView(TextView(this@InvoiceListActivity).apply {
                        text = "${item.qty}× %,d".format(item.unitPrice); textSize = 11f
                        setTextColor(color(R.color.secondary))
                    })
                })
            }
            if (invItems.size > 3) box.addView(TextView(this).apply {
                text = "و ${invItems.size - 3} قلم دیگر…"; textSize = 10f
                setTextColor(color(R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
            })
        }

        // ── Action buttons ──
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        fun btn(label: String, bg: Int, tc: Int, action: () -> Unit) = MaterialButton(this).apply {
            text = label; textSize = 11f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(bg))
            setTextColor(color(tc))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) }
            setOnClickListener { action() }
        }
        btnRow.addView(btn("ویرایش", R.color.primary_soft, R.color.primary) { showEditDialog(inv) })
        btnRow.addView(btn("اشتراک PDF", R.color.credit_soft, R.color.credit_text) {
            pendingShareInv = inv
            pdfShareLauncher.launch("فاکتور-${notebookName}-شماره${inv.number}.pdf")
        })
        btnRow.addView(btn("ذخیره PDF", R.color.neutral_soft, R.color.text) {
            pendingShareInv = inv
            pdfSaveLauncher.launch("فاکتور-${notebookName}-شماره${inv.number}.pdf")
        })
        box.addView(btnRow)
        card.addView(box)
        return card
    }

    private fun exportAndShare(inv: DbHelper.InvoiceHeader, uri: Uri, share: Boolean) {
        val items = db.invoiceItems(inv.id)
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        InvoicePdfExporter.export(
            context = this, uri = uri,
            invoiceNumber = inv.number,
            buyerName = notebookName, buyerPhone = notebookPhone,
            sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: "",
            sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "",
            sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "",
            sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: "",
            items = items, date = inv.createdAt, prepay = inv.prepay, dueDate = inv.dueDate
        ) { savedUri ->
            if (share) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, savedUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "ارسال فاکتور"))
            } else {
                Toast.makeText(this, "فاکتور PDF ذخیره شد.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEditDialog(inv: DbHelper.InvoiceHeader) {
        val items = db.invoiceItems(inv.id).toMutableList()
        var dueDate = inv.dueDate

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        // Items list
        val itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshItems() {
            itemsBox.removeAllViews()
            items.forEachIndexed { idx, item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                row.addView(TextView(this).apply {
                    text = "${item.name}  ×${item.qty}  @%,d = %,d تومان".format(item.unitPrice, item.total)
                    textSize = 11f; setTextColor(color(R.color.text))
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                })
                row.addView(MaterialButton(this).apply {
                    text = "×"; textSize = 14f; minWidth = 0; insetTop = 0; insetBottom = 0
                    setPadding(dp(8), 0, dp(8), 0)
                    backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                    setTextColor(color(R.color.debt_text))
                    setOnClickListener { items.removeAt(idx); refreshItems() }
                })
                itemsBox.addView(row)
            }
        }
        refreshItems()

        val addBtn = MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            layoutParams = LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(8) }
            setOnClickListener {
                val iBox = LinearLayout(this@InvoiceListActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(16), dp(4), dp(16), dp(4))
                }
                fun ef(hint: String, num: Boolean = false) = EditText(this@InvoiceListActivity).apply {
                    this.hint = hint; textSize = 13f
                    gravity = if (num) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.END or Gravity.CENTER_VERTICAL
                    inputType = if (num) android.text.InputType.TYPE_CLASS_PHONE else android.text.InputType.TYPE_CLASS_TEXT
                    layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) }
                }
                val nf = ef("نام کالا"); val qf = ef("تعداد", true).also { it.setText("1") }
                val pf = ef("فی (تومان)", true)
                iBox.addView(nf); iBox.addView(qf); iBox.addView(pf)
                MaterialAlertDialogBuilder(this@InvoiceListActivity).setTitle("افزودن قلم").setView(iBox)
                    .setPositiveButton("افزودن") { _, _ ->
                        val n = nf.text.toString().trim()
                        val q = qf.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val p = pf.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        if (n.isNotBlank() && q > 0 && p > 0) { items.add(InvoiceItem(name = n, qty = q, unitPrice = p)); refreshItems() }
                    }.setNegativeButton("انصراف", null).show()
            }
        }

        // Kind
        val kindGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        val rdDebt = RadioButton(this).apply { id = View.generateViewId(); text = "↑ پرداختی"; layoutParams = RadioGroup.LayoutParams(0, -2, 1f) }
        val rdCredit = RadioButton(this).apply { id = View.generateViewId(); text = "↓ دریافتی"; layoutParams = RadioGroup.LayoutParams(0, -2, 1f) }
        kindGroup.addView(rdDebt); kindGroup.addView(rdCredit)
        kindGroup.check(if (inv.kind == "debt") rdDebt.id else rdCredit.id)

        // Prepay
        val prepayField = EditText(this).apply {
            hint = "پیش‌پرداخت (تومان)"; textSize = 13f; gravity = Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setText(if (inv.prepay > 0) "%,d".format(inv.prepay) else "")
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
        }

        // Due date
        val dueDateLabel = TextView(this).apply {
            text = if (dueDate.isNotBlank()) "سررسید: $dueDate" else "سررسید: انتخاب نشده"
            textSize = 12f; setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        val dueDateBtn = MaterialButton(this).apply {
            text = "📅 تغییر سررسید"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft))
            setTextColor(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) }
            setOnClickListener {
                promptJalaliDate(this@InvoiceListActivity, dueDate) { d ->
                    dueDate = d; dueDateLabel.text = "سررسید: $d"
                    dueDateLabel.setTextColor(color(R.color.text))
                }
            }
        }

        box.addView(itemsBox); box.addView(addBtn)
        box.addView(TextView(this).apply { text = "نوع تراکنش"; textSize = 11f; setTextColor(color(R.color.secondary)); setPadding(0, dp(10), 0, 0) })
        box.addView(kindGroup); box.addView(prepayField)
        box.addView(dueDateLabel); box.addView(dueDateBtn)

        MaterialAlertDialogBuilder(this)
            .setTitle("ویرایش فاکتور شماره ${inv.number}")
            .setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                if (items.isEmpty()) { toast("حداقل یک قلم لازم است"); return@setPositiveButton }
                val newKind = if (kindGroup.checkedRadioButtonId == rdDebt.id) "debt" else "credit"
                val newPrepay = prepayField.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                db.updateInvoice(inv.id, notebookId, newKind, items, inv.note, newPrepay, dueDate, inv.txId)
                toast("فاکتور ویرایش شد"); loadList()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
