package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val helper = DbHelper(context)
            helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            helper.close()
            val src = context.getDatabasePath(DbHelper.DB_NAME)
            val stamp = SimpleDateFormat("yyMMdd_HHmm", Locale.US).format(Date())
            val name = "hesabdar_backup_${stamp}.db"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Hesabdar")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Cannot create backup file")
                context.contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(src).use { it.copyTo(out) } }
                    ?: error("Cannot open backup output")
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdar")
                if (!dir.exists()) dir.mkdirs()
                FileInputStream(src).use { input -> FileOutputStream(File(dir, name)).use { output -> input.copyTo(output) } }
            }
            if (!silent) Toast.makeText(context, "پشتیبان در Download/Hesabdar ذخیره شد.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun maybeAutoBackup(context: Context) {
        val prefs = AppPrefs.prefs(context)
        if (!prefs.getBoolean(AppPrefs.AUTO_BACKUP, true)) return
        val now = System.currentTimeMillis()
        val last = prefs.getLong(AppPrefs.LAST_AUTO_BACKUP, 0L)
        if (now - last >= 24L * 60L * 60L * 1000L && backup(context, true)) {
            prefs.edit().putLong(AppPrefs.LAST_AUTO_BACKUP, now).apply()
        }
    }

    fun restore(context: Context, uri: Uri): Boolean {
        val dbFile = context.getDatabasePath(DbHelper.DB_NAME)
        val tmp = File(context.cacheDir, "restore_candidate.db")
        val previous = File(context.cacheDir, "restore_previous.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output) }
            } ?: error("فایل قابل خواندن نیست")

            if (!tmp.exists() || tmp.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")

            val check = android.database.sqlite.SQLiteDatabase.openDatabase(
                tmp.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
            )
            try {
                val required = setOf("folders", "notebooks", "tx")
                val found = mutableSetOf<String>()
                check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use {
                    while (it.moveToNext()) found += it.getString(0)
                }
                if (!found.containsAll(required)) error("این فایل پشتیبان معتبر حسابدار من نیست")

                val quickCheck = check.rawQuery("PRAGMA quick_check", null).use {
                    it.moveToFirst() && it.getString(0).equals("ok", ignoreCase = true)
                }
                if (!quickCheck) error("فایل پشتیبان آسیب‌دیده است")

                val version = check.rawQuery("PRAGMA user_version", null).use {
                    if (it.moveToFirst()) it.getInt(0) else 0
                }
                if (version > DbHelper.DATABASE_VERSION) error("نسخه این پشتیبان از نسخه فعلی برنامه جدیدتر است")
            } finally {
                check.close()
            }

            dbFile.parentFile?.mkdirs()
            if (dbFile.exists()) {
                previous.delete()
                FileInputStream(dbFile).use { input -> FileOutputStream(previous).use { output -> input.copyTo(output) } }
            }
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()

            try {
                FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { output -> input.copyTo(output) } }
                tmp.delete()
                previous.delete()
                true
            } catch (replaceError: Exception) {
                if (previous.exists()) {
                    FileInputStream(previous).use { input -> FileOutputStream(dbFile, false).use { output -> input.copyTo(output) } }
                }
                throw replaceError
            }
        } catch (e: Exception) {
            tmp.delete()
            previous.delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
