package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Backup is intentionally a single canonical SQLite file named `hesabdar_database`.
 * It lives in Download/Hesabdar so it survives uninstall/reinstall.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database"
    private const val CANONICAL_RELATIVE_PATH = "Download/Hesabdar/"

    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            checkpoint(context)
            val src = context.getDatabasePath(DbHelper.DB_NAME)
            if (!src.exists() || src.length() < 4096L) error("پایگاه داده هنوز آماده پشتیبان‌گیری نیست")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) writeCanonicalMediaStore(context, src)
            else writeCanonicalLegacy(src)
            if (!silent) Toast.makeText(context, "پشتیبان اصلی در Download/Hesabdar/$CANONICAL_NAME ذخیره شد.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    /** Called before the first Activity is created, so the external file becomes authoritative. */
    fun restoreCanonicalIfPresent(context: Context): Boolean {
        return try {
            val source = findCanonical(context) ?: return false
            val tmp = File(context.cacheDir, "canonical_database.tmp")
            context.contentResolver.openInputStream(source)?.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                ?: error("فایل اصلی قابل خواندن نیست")
            validateDatabase(tmp)
            val dbFile = context.getDatabasePath(DbHelper.DB_NAME)
            dbFile.parentFile?.mkdirs()
            File(dbFile.path + "-wal").delete(); File(dbFile.path + "-shm").delete()
            FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { input.copyTo(it) } }
            tmp.delete()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun maybeAutoBackup(context: Context) {
        if (AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) backup(context, true)
    }

    fun restore(context: Context, uri: Uri): Boolean {
        val dbFile = context.getDatabasePath(DbHelper.DB_NAME)
        val tmp = File(context.cacheDir, "restore_candidate.db")
        val previous = File(context.cacheDir, "restore_previous.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                ?: error("فایل قابل خواندن نیست")
            validateDatabase(tmp)
            dbFile.parentFile?.mkdirs()
            if (dbFile.exists()) {
                previous.delete()
                FileInputStream(dbFile).use { input -> FileOutputStream(previous).use { input.copyTo(it) } }
            }
            File(dbFile.path + "-wal").delete(); File(dbFile.path + "-shm").delete()
            FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { input.copyTo(it) } }
            tmp.delete(); previous.delete()
            // A manually restored database immediately becomes the canonical database too.
            backup(context, true)
            true
        } catch (e: Exception) {
            tmp.delete(); previous.delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun checkpoint(context: Context) {
        val helper = DbHelper(context)
        try { helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { } }
        finally { helper.close() }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(file.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf("folders", "notebooks", "tx", "invoices", "invoice_items", "installment_plans", "installment_items")
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { while (it.moveToNext()) found += it.getString(0) }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار من نیست")
            val ok = db.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0).equals("ok", true) }
            if (!ok) error("فایل پشتیبان آسیب‌دیده است")
            val version = db.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        } finally { db.close() }
    }

    private fun findCanonical(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            resolver.query(
                collection,
                arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
                arrayOf(CANONICAL_NAME, CANONICAL_RELATIVE_PATH),
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
            )?.use { c -> if (c.moveToFirst()) return Uri.withAppendedPath(collection, c.getLong(0).toString()) }
            return null
        }
        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdar/$CANONICAL_NAME")
        return if (file.exists()) Uri.fromFile(file) else null
    }

    private fun writeCanonicalMediaStore(context: Context, src: File) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        cleanupDuplicateCanonicalEntries(context)
        val existing = findCanonical(context)
        val uri = if (existing != null) existing else resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, CANONICAL_NAME)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
            put(MediaStore.Downloads.RELATIVE_PATH, CANONICAL_RELATIVE_PATH)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }) ?: error("امکان ساخت فایل اصلی وجود ندارد")
        resolver.openOutputStream(uri, "wt")?.use { out -> FileInputStream(src).use { it.copyTo(out) } }
            ?: error("امکان نوشتن فایل اصلی وجود ندارد")
        if (existing == null) resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    }

    /** Removes stale duplicate/pending canonical backup entries left by interrupted writes. */
    private fun cleanupDuplicateCanonicalEntries(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val keep = findCanonical(context)
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
            arrayOf(CANONICAL_NAME, CANONICAL_RELATIVE_PATH),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val uri = Uri.withAppendedPath(collection, c.getLong(0).toString())
                if (keep == null || uri != keep) resolver.delete(uri, null, null)
            }
        }
    }

    private fun writeCanonicalLegacy(src: File) {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdar")
        if (!dir.exists()) dir.mkdirs()
        FileInputStream(src).use { input -> FileOutputStream(File(dir, CANONICAL_NAME), false).use { input.copyTo(it) } }
    }
}
