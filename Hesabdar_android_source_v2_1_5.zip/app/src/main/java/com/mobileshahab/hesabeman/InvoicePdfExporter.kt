package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import kotlin.math.min

/**
 * Printable sales/purchase invoice PDF.
 * RTL layout is preserved, while numeric columns are visually left-oriented.
 */
object InvoicePdfExporter {
    fun export(
        context: Context, uri: Uri, invoiceNumber: Int,
        invoiceKind: String = "debt",
        buyerName: String, buyerPhone: String = "",
        sellerName: String, sellerAddress: String, sellerPhone: String, sellerSlogan: String,
        items: List<InvoiceItem>, date: String, prepay: Long = 0L, dueDate: String = "",
        onDone: (Uri) -> Unit
    ): Boolean = try {
        val W = 595f; val H = 842f; val m = 30f
        val left = m; val right = W - m
        val green = Color.rgb(0,112,96); val light = Color.rgb(228,242,235)
        val dark = Color.rgb(42,49,47); val grid = Color.rgb(155,190,178)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), 1).create())
        val c = page.canvas
        val bold = Typeface.DEFAULT_BOLD
        fun p(size:Float,color:Int=dark,align:Paint.Align=Paint.Align.CENTER)=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=size;typeface=bold;this.color=color;textAlign=align}
        fun fill(color:Int)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color}
        fun stroke(color:Int,w:Float=0.8f)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;strokeWidth=w;style=Paint.Style.STROKE}
        fun rr(l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int,border:Int?=null){c.drawRoundRect(RectF(l,t,r,b),rad,rad,fill(color));if(border!=null)c.drawRoundRect(RectF(l,t,r,b),rad,rad,stroke(border,1f))}
        fun fit(s:String,paint:Paint,max:Float):String{if(paint.measureText(s)<=max)return s;var x=s;while(x.length>1&&paint.measureText("$x…")>max)x=x.dropLast(1);return x+"…"}

        var y=m
        val title=if(invoiceKind=="credit")"فاکتور خرید" else "فاکتور فروش"
        val headerHeight=if(sellerName.isBlank()) 70f else 82f
        rr(left,y,right,y+tableHeaderHeight,14f,green)
        c.drawText(title,W/2,y+29,p(23f,Color.WHITE))
        if(sellerName.isNotBlank()) c.drawText(fit(sellerName,p(12f,Color.WHITE),W-2*m-20),W/2,y+54,p(12f,Color.WHITE))
        y+=tableHeaderHeight+10

        rr(left,y,right,y+34,7f,light,green)
        c.drawText("فاکتور شماره: $invoiceNumber",right-10,y+22,p(11f,green,Paint.Align.RIGHT))
        c.drawText("تاریخ: $date",left+10,y+22,p(11f,green,Paint.Align.LEFT))
        y+=42
        if(dueDate.isNotBlank()){rr(left,y,right,y+24,6f,Color.rgb(255,244,224),Color.rgb(225,165,75));c.drawText("سررسید: $dueDate",W/2,y+16,p(10f,Color.rgb(170,105,0)));y+=31}

        // Buyer card now contains BOTH the account name and mobile number.
        val gap=10f; val cardW=(right-left-gap)/2f; val cardH=70f
        fun infoCard(x:Float,label:String,name:String,phone:String,address:String=""){
            rr(x,y,x+cardW,y+cardH,9f,light,green);rr(x,y,x+cardW,y+20,9f,green);c.drawRect(x,y+10,x+cardW,y+20,fill(green))
            c.drawText(label,x+cardW/2,y+14,p(9f,Color.WHITE))
            var yy=y+38
            if(name.isNotBlank()){c.drawText(fit(name,p(9.5f,dark),cardW-14),x+cardW/2,yy,p(9.5f));yy+=14}
            if(phone.isNotBlank()){c.drawText(fit(phone,p(8.8f,dark),cardW-14),x+cardW/2,yy,p(8.8f));yy+=13}
            if(address.isNotBlank()) c.drawText(fit(address,p(8.2f,Color.DKGRAY),cardW-14),x+cardW/2,yy,p(8.2f,Color.DKGRAY))
        }
        infoCard(left,"خریدار",buyerName,buyerPhone)
        infoCard(right-cardW,"فروشنده",sellerName,sellerPhone,sellerAddress)
        y+=cardH+12

        // Table: RTL columns are ordered from right to left. Numeric columns use centered
        // cells but are clipped to their exact grid; this prevents long amounts from spilling.
        val xR=right; val xNo=xR-42; val xDesc=xNo-245; val xQty=xDesc-55; val xPrice=xQty-92; val xTotal=left
        val tableHeaderH=28f; val rowH=30f; val tableTop=y
        c.drawRect(xTotal,y,xR,y+tableHeaderHeight,fill(green))
        c.drawText("ردیف",(xNo+xR)/2,y+19,p(8.8f,Color.WHITE))
        c.drawText("نام / شرح کالا",(xDesc+xNo)/2,y+19,p(8.8f,Color.WHITE))
        c.drawText("تعداد",(xQty+xDesc)/2,y+19,p(8.8f,Color.WHITE))
        c.drawText("فی",(xPrice+xQty)/2,y+19,p(8.8f,Color.WHITE))
        c.drawText("جمع",(xTotal+xPrice)/2,y+19,p(8.8f,Color.WHITE))
        y+=tableHeaderH
        items.forEachIndexed{idx,item->
            val top=y
            c.drawRect(xTotal,top,xR,top+rowH,fill(if(idx%2==0)Color.WHITE else Color.rgb(247,251,249)))
            val numP=p(8.3f); val descP=p(8.3f,dark,Paint.Align.RIGHT)
            fun cell(text:String,l:Float,r:Float){c.save();c.clipRect(l+2,top+2,r-2,top+rowH-2);c.drawText(fit(text,numP,r-l-6),(l+r)/2,top+20,numP);c.restore()}
            cell("${idx+1}",xNo,xR)
            val desc=if(item.description.isBlank())item.name else "${item.name} — ${item.description}"
            c.save();c.clipRect(xDesc+4,top+2,xNo-4,top+rowH-2);c.drawText(fit(desc,descP,xNo-xDesc-10),xNo-7,top+20,descP);c.restore()
            cell("${item.qty}",xQty,xDesc);cell("%,d".format(item.unitPrice),xPrice,xQty);cell("%,d".format(item.total),xTotal,xPrice)
            y+=rowH
        }
        val tableBottom=y
        c.drawRect(xTotal,tableTop,xR,tableBottom,stroke(grid,1f))
        listOf(xNo,xDesc,xQty,xPrice).forEach{xx->c.drawLine(xx,tableTop,xx,tableBottom,stroke(grid,0.7f))}
        var ly=tableTop+tableHeaderH;repeat(items.size){c.drawLine(xTotal,ly,xR,ly,stroke(Color.rgb(210,225,218),0.5f));ly+=rowH}
        y+=10

        val total=items.sumOf{it.total};val qty=items.sumOf{it.qty};val remaining=(total-prepay).coerceAtLeast(0)
        val totalsH=if(prepay>0) 70f else 50f
        rr(left,y,right,y+totalsH,9f,light,green)
        c.drawText("تعداد کل: $qty",left+12,y+18,p(9f,green,Paint.Align.LEFT))
        c.drawText("جمع کل: ${"%,d".format(total)} تومان",right-12,y+18,p(10f,dark,Paint.Align.RIGHT))
        if(prepay>0){c.drawText("پیش‌پرداخت: ${"%,d".format(prepay)} تومان",left+12,y+44,p(9f,dark,Paint.Align.LEFT));c.drawText("مانده قابل پرداخت: ${"%,d".format(remaining)} تومان",right-12,y+44,p(10f,green,Paint.Align.RIGHT))}
        else c.drawText("مانده قابل پرداخت: ${"%,d".format(remaining)} تومان",right-12,y+38,p(10f,green,Paint.Align.RIGHT))
        y+=totalsH+14

        val sigGap=12f;val sigW=(right-left-sigGap)/2f;val sigH=92f;val sloganGap=if(sellerSlogan.isNotBlank())26f else 0f;val sy=min(y,H-m-sigH-sloganGap)
        fun signature(x:Float,label:String){rr(x,sy,x+sigW,sy+sigH,10f,Color.WHITE,green);rr(x,sy,x+sigW,sy+23,10f,green);c.drawRect(x,sy+12,x+sigW,sy+23,fill(green));c.drawText(label,x+sigW/2,sy+16,p(9f,Color.WHITE));c.drawText("مهر / امضا",x+sigW/2,sy+59,p(9f,Color.rgb(145,160,155)))}
        signature(left,"امضا خریدار");signature(left+sigW+sigGap,"امضا فروشنده")
        if(sellerSlogan.isNotBlank()) c.drawText(fit(sellerSlogan,p(9f,green),W-2*m),W/2,H-m-8,p(9f,green))

        doc.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("Cannot open PDF output")
        doc.close();onDone(uri);true
    }catch(e:Exception){Toast.makeText(context,"خطا در ساخت فاکتور PDF: ${e.message}",Toast.LENGTH_LONG).show();false}
}
