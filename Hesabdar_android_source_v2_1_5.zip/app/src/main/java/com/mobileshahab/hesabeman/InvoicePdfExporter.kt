package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import kotlin.math.min

object InvoicePdfExporter {

    fun export(
        context: Context, uri: Uri, invoiceNumber: Int,
        invoiceKind: String = "debt",
        buyerName: String, buyerPhone: String = "",
        sellerName: String, sellerAddress: String, sellerPhone: String, sellerSlogan: String,
        items: List<InvoiceItem>, date: String, prepay: Long = 0L, dueDate: String = "",
        onDone: (Uri) -> Unit
    ): Boolean {
        return try {
            val W = 595f
            val H = 842f
            val m = 30f
            val contentRight = W - m
            val contentLeft = m
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), 1).create())
            val c = page.canvas

            val bold = Typeface.DEFAULT_BOLD
            val green = Color.rgb(0, 112, 96)
            val lightGreen = Color.rgb(228, 242, 235)
            val dark = Color.rgb(42, 49, 47)
            val grid = Color.rgb(155, 190, 178)

            fun paint(size: Float, color: Int = dark, align: Paint.Align = Paint.Align.CENTER) =
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = size
                    typeface = bold
                    this.color = color
                    textAlign = align
                }
            fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
            fun stroke(color: Int, width: Float = 0.8f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color; strokeWidth = width; style = Paint.Style.STROKE
            }
            fun rr(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int, border: Int? = null) {
                c.drawRoundRect(RectF(l, t, r, b), radius, radius, fill(color))
                if (border != null) c.drawRoundRect(RectF(l, t, r, b), radius, radius, stroke(border, 1f))
            }
            fun fitText(text: String, p: Paint, maxWidth: Float): String {
                if (p.measureText(text) <= maxWidth) return text
                var value = text
                while (value.length > 1 && p.measureText("$value…") > maxWidth) value = value.dropLast(1)
                return value + "…"
            }
            fun safeText(text: String, max: Int): String = if (text.length > max) text.take(max - 1) + "…" else text

            var y = m
            val title = if (invoiceKind == "credit") "فاکتور خرید" else "فاکتور فروش"

            // Header: title, then business name underneath.
            val headerH = if (sellerName.isNotBlank()) 82f else 70f
            rr(contentLeft, y, contentRight, y + headerH, 14f, green)
            c.drawText(title, W / 2f, y + 29f, paint(23f, Color.WHITE))
            if (sellerName.isNotBlank()) {
                c.drawText(safeText(sellerName, 40), W / 2f, y + 53f, paint(12f, Color.WHITE))
            }
            y += headerH + 10f

            // Invoice info
            rr(contentLeft, y, contentRight, y + 34f, 7f, lightGreen, green)
            c.drawText("فاکتور شماره: $invoiceNumber", contentRight - 10f, y + 22f, paint(12f, green, Paint.Align.RIGHT))
            c.drawText("تاریخ: $date", contentLeft + 10f, y + 22f, paint(12f, green, Paint.Align.LEFT))
            y += 42f
            if (dueDate.isNotBlank()) {
                rr(contentLeft, y, contentRight, y + 24f, 6f, Color.rgb(255, 244, 224), Color.rgb(225, 165, 75))
                c.drawText("سررسید: $dueDate", W / 2f, y + 16f, paint(10f, Color.rgb(170, 105, 0)))
                y += 31f
            }

            // Seller right / buyer left (RTL)
            val gap = 10f
            val cardW = (contentRight - contentLeft - gap) / 2f
            val cardH = 62f
            fun infoCard(x: Float, label: String, phone: String, address: String) {
                rr(x, y, x + cardW, y + cardH, 9f, lightGreen, green)
                rr(x, y, x + cardW, y + 20f, 9f, green)
                c.drawRect(x, y + 10f, x + cardW, y + 20f, fill(green))
                c.drawText(label, x + cardW / 2f, y + 14f, paint(9f, Color.WHITE))
                var yy = y + 38f
                if (phone.isNotBlank()) { c.drawText(safeText(phone, 25), x + cardW / 2f, yy, paint(9f)); yy += 14f }
                if (address.isNotBlank()) c.drawText(safeText(address, 38), x + cardW / 2f, yy, paint(8.5f, Color.DKGRAY))
            }
            infoCard(contentLeft, "خریدار", buyerPhone, "")
            infoCard(contentRight - cardW, "فروشنده", sellerPhone, sellerAddress)
            y += cardH + 12f

            // Items table: RTL = ردیف | شرح کالا | تعداد | فی | جمع
            val tableTop = y
            val xR = contentRight
            val xRow = xR - 45f
            val xDesc = xRow - 270f
            val xQty = xDesc - 55f
            val xPrice = xQty - 85f
            val xTotal = contentLeft
            val tableHeaderH = 27f
            val rowH = 31f

            c.drawRect(xTotal, y, xR, y + tableHeaderH, fill(green))
            c.drawText("ردیف", (xRow + xR) / 2f, y + 18f, paint(9f, Color.WHITE))
            c.drawText("شرح کالا", (xDesc + xRow) / 2f, y + 18f, paint(9f, Color.WHITE))
            c.drawText("تعداد", (xQty + xDesc) / 2f, y + 18f, paint(9f, Color.WHITE))
            c.drawText("فی", (xPrice + xQty) / 2f, y + 18f, paint(9f, Color.WHITE))
            c.drawText("جمع", (xTotal + xPrice) / 2f, y + 18f, paint(9f, Color.WHITE))
            y += tableHeaderH

            items.forEachIndexed { index, item ->
                val top = y
                c.drawRect(xTotal, top, xR, top + rowH, fill(if (index % 2 == 0) Color.WHITE else Color.rgb(247, 251, 249)))
                val cy = top + 20f
                c.drawText("${index + 1}", (xRow + xR) / 2f, cy, paint(8.5f))

                // Keep description strictly inside its own column.
                val descPaint = paint(8.5f, dark, Paint.Align.RIGHT)
                val desc = if (item.description.isBlank()) item.name else "${item.name} — ${item.description}"
                val maxDescWidth = (xRow - xDesc) - 14f
                val descText = fitText(desc, descPaint, maxDescWidth)
                c.save()
                c.clipRect(xDesc + 4f, top + 2f, xRow - 4f, top + rowH - 2f)
                c.drawText(descText, xRow - 7f, cy, descPaint)
                c.restore()

                c.drawText("${item.qty}", (xQty + xDesc) / 2f, cy, paint(8.5f))
                c.drawText("%,d".format(item.unitPrice), (xPrice + xQty) / 2f, cy, paint(8.5f))
                c.drawText("%,d".format(item.total), (xTotal + xPrice) / 2f, cy, paint(8.5f))
                y += rowH
            }
            val tableBottom = y
            c.drawRect(xTotal, tableTop, xR, tableBottom, stroke(grid, 1f))
            listOf(xRow, xDesc, xQty, xPrice).forEach { xx -> c.drawLine(xx, tableTop, xx, tableBottom, stroke(grid, 0.7f)) }
            var ly = tableTop + tableHeaderH
            repeat(items.size) {
                c.drawLine(xTotal, ly, xR, ly, stroke(Color.rgb(210, 225, 218), 0.5f))
                ly += rowH
            }
            y += 10f

            // Totals: no "تعداد اقلام"; keep row numbers in the table.
            val grandTotal = items.sumOf { it.total }
            val totalQty = items.sumOf { it.qty }
            val remaining = (grandTotal - prepay).coerceAtLeast(0L)
            val totalsH = if (prepay > 0) 68f else 48f
            rr(contentLeft, y, contentRight, y + totalsH, 9f, lightGreen, green)
            c.drawText("تعداد کل: $totalQty", contentLeft + 12f, y + 18f, paint(9f, green, Paint.Align.LEFT))
            c.drawText("جمع کل: %,d تومان".format(grandTotal), contentRight - 12f, y + 18f, paint(10f, dark, Paint.Align.RIGHT))
            if (prepay > 0) {
                c.drawText("پیش‌پرداخت: %,d تومان".format(prepay), contentLeft + 12f, y + 43f, paint(9f, dark, Paint.Align.LEFT))
                c.drawText("مانده قابل پرداخت: %,d تومان".format(remaining), contentRight - 12f, y + 43f, paint(10f, green, Paint.Align.RIGHT))
            } else {
                c.drawText("مانده قابل پرداخت: %,d تومان".format(remaining), contentRight - 12f, y + 38f, paint(10f, green, Paint.Align.RIGHT))
            }
            y += totalsH + 14f

            // Signature / stamp areas.
            val sigGap = 12f
            val sigW = (contentRight - contentLeft - sigGap) / 2f
            val sigH = 92f
            val sloganGap = if (sellerSlogan.isNotBlank()) 26f else 0f
            val sigY = minOf(y, H - m - sigH - sloganGap)
            fun signature(x: Float, label: String) {
                rr(x, sigY, x + sigW, sigY + sigH, 10f, Color.WHITE, green)
                rr(x, sigY, x + sigW, sigY + 23f, 10f, green)
                c.drawRect(x, sigY + 12f, x + sigW, sigY + 23f, fill(green))
                c.drawText(label, x + sigW / 2f, sigY + 16f, paint(9f, Color.WHITE))
                c.drawText("مهر / امضا", x + sigW / 2f, sigY + 59f, paint(9f, Color.rgb(145, 160, 155)))
            }
            signature(contentLeft, "امضا خریدار")
            signature(contentLeft + sigW + sigGap, "امضا فروشنده")

            // Footer slogan: bold text, no surrounding table/card.
            if (sellerSlogan.isNotBlank()) {
                c.drawText(
                    sellerSlogan,
                    W / 2f,
                    sigY + sigH + 20f,
                    paint(12f, green, Paint.Align.CENTER)
                )
            }

            doc.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Cannot open PDF output")
            doc.close()
            onDone(uri)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ساخت PDF: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
