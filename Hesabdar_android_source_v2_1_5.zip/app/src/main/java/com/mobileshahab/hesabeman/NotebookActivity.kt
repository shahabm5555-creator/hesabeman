package com.mobileshahab.hesabeman

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityNotebookBinding

class NotebookActivity : BaseActivity() {
    private lateinit var b: ActivityNotebookBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: TxAdapter
    private var notebookId = 0L
    private var notebookName = "حساب"
    private var phone = ""

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) PdfExporter.export(this, uri, notebookName, db.txRecords(notebookId), db.balance(notebookId))
    }

    private val invoiceLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNotebookBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this); notebookId = intent.getLongExtra("notebook_id", 0); loadNotebookInfo()
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material); b.toolbar.setNavigationOnClickListener { finish() }
        adapter = TxAdapter(emptyList(), { editTransaction(it) }, { confirmDeleteTransaction(it) }) { tx ->
            if (!tx.note.startsWith("فاکتور شماره")) return@TxAdapter
            val info = db.notebookInfo(notebookId)
            startActivity(Intent(this, InvoiceListActivity::class.java).apply {
                putExtra("notebook_id", notebookId)
                putExtra("notebook_name", notebookName)
                putExtra("notebook_phone", info.phone)
            })
        }
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter
        b.addTransaction.setOnClickListener { add("debt", "ثبت تراکنش") }
        b.addTransaction.setOnTouchListener { v, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        b.sms.setOnClickListener { sendBalanceSms() }; b.report.setOnClickListener { showReport() }
        b.dueDate.setOnClickListener { editDueDate() }
        b.exportPdf.setOnClickListener { pdfPicker.launch("${notebookName.replace("/", "-")}.pdf") }
        b.invoiceBtn.setOnClickListener {
            val info = db.notebookInfo(notebookId)
            val intent = android.content.Intent(this, InvoiceActivity::class.java).apply {
                putExtra("notebook_id", notebookId); putExtra("notebook_name", notebookName); putExtra("notebook_phone", info.phone)
            }
            invoiceLauncher.launch(intent)
        }
        b.installmentBtn.setOnClickListener {
            startActivity(Intent(this, InstallmentActivity::class.java).apply {
                putExtra("notebook_id", notebookId)
                putExtra("notebook_name", notebookName)
            })
        }
        b.invoiceListBtn.setOnClickListener {
            val info = db.notebookInfo(notebookId)
            val intent = android.content.Intent(this, InvoiceListActivity::class.java).apply {
                putExtra("notebook_id", notebookId); putExtra("notebook_name", notebookName); putExtra("notebook_phone", info.phone)
            }
            startActivity(intent)
        }
        b.phoneIcon.setOnClickListener { callPerson() }; b.phoneText.setOnLongClickListener { editPhone(); true }; b.phoneGroup.setOnClickListener { callPerson() }
        b.personName.setOnClickListener { editName() }
    }

    private fun loadNotebookInfo() {
        val info = db.notebookInfo(notebookId); notebookName = info.name; phone = info.phone
        b.toolbar.title = notebookName; b.personName.text = notebookName
        b.avatar.text = notebookName.trim().firstOrNull()?.toString() ?: "ح"
        b.phoneText.text = if (phone.isBlank()) "" else phone
        b.phoneIcon.visibility = android.view.View.VISIBLE
        b.phoneText.visibility = if (phone.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun add(kind: String, title: String) {
        promptTransaction(this, title, kind) { selectedKind, amount, note, dateTime ->
            if (db.addTx(notebookId, selectedKind, amount, note, dateTime) > 0L) refresh()
            else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDeleteTransaction(record: TxRecord) {
        MaterialAlertDialogBuilder(this)
            .setTitle("حذف ریز حساب")
            .setMessage("این تراکنش حذف شود؟ این عمل قابل بازگردانی نیست.")
            .setPositiveButton("حذف") { _, _ ->
                if (db.deleteTx(record.id)) refresh()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun editTransaction(record: TxRecord) {
        promptTransaction(this, "ویرایش تراکنش", record.kind, record.amount, record.note, record.createdAt) { selectedKind, amount, note, dateTime ->
            if (db.updateTx(record.id, amount, note, dateTime) && db.updateTxKind(record.id, selectedKind)) refresh()
            else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
        }
    }

    private fun editName() {
        promptText(this, "نام حساب", notebookName) { value ->
            if (db.updateNotebookName(notebookId, value)) {
                loadNotebookInfo()
                Toast.makeText(this, "نام حساب تغییر کرد.", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "نام حساب نمی‌تواند خالی باشد.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editPhone() { promptText(this, "شماره موبایل", "مثال: 09123456789", numeric = true) { db.updateNotebookPhone(notebookId, it); loadNotebookInfo() } }
    private fun editDueDate() {
        val current = db.notebookInfo(notebookId).dueDate
        promptJalaliDate(this, current) {
            db.setDueDate(notebookId, it); Toast.makeText(this, "تاریخ سررسید ذخیره شد.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun callPerson() {
        if (phone.isBlank()) { Toast.makeText(this, "ابتدا شماره موبایل را برای این حساب ثبت کنید.", Toast.LENGTH_LONG).show(); editPhone(); return }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    }

    private fun sendBalanceSms() {
        if (phone.isBlank()) { Toast.makeText(this, "ابتدا شماره موبایل را برای این حساب ثبت کنید.", Toast.LENGTH_LONG).show(); editPhone(); return }
        val credit = db.totalCredit(notebookId); val debt = db.totalDebt(notebookId); val net = credit - debt
        val message = buildString {
            append("با سلام $notebookName\n")
            append("گزارش مانده حساب شما:\n")
            append("کل پرداختی: ${formatMoney(debt)} تومان\n")
            append("کل دریافتی: ${formatMoney(credit)} تومان\n")
            when {
                net < 0L -> {
                    append("مانده بدهکاری: ${formatMoney(-net)} تومان\n")
                    append("لطفاً حساب خود را تسویه نمایید.\n")
                }
                net > 0L -> {
                    append("مانده بستانکاری: ${formatMoney(net)} تومان\n")
                    append("این مبلغ مانده طلب شماست.\n")
                }
                else -> append("وضعیت حساب: تسویه شده\n")
            }
            append("نرم افزار حسابدار من")
        }
        MaterialAlertDialogBuilder(this).setTitle("ارسال مانده حساب").setMessage(message)
            .setPositiveButton("ارسال پیامک") { _, _ -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", message)) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun showReport() {
        val records = db.txRecords(notebookId)
        val payments = records.count { it.kind == "debt" }
        val receipts = records.count { it.kind == "credit" }
        val totalPayments = db.totalDebt(notebookId)
        val totalReceipts = db.totalCredit(notebookId)
        val net = totalReceipts - totalPayments
        val status = when { net > 0 -> "بستانکار"; net < 0 -> "بدهکار"; else -> "تسویه" }
        val message = """تعداد پرداختی: $payments
تعداد دریافتی: $receipts
کل مبلغ پرداختی: ${formatMoney(totalPayments)} تومان
کل مبلغ دریافتی: ${formatMoney(totalReceipts)} تومان
مانده حساب: ${formatMoney(kotlin.math.abs(net))} تومان ($status)"""
        MaterialAlertDialogBuilder(this).setTitle("گزارش حساب").setMessage(message).setPositiveButton("باشه", null).show()
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        loadNotebookInfo(); adapter.submit(db.txRecords(notebookId))
        val credit = db.totalCredit(notebookId); val debt = db.totalDebt(notebookId); val x = credit - debt
        b.balance.text = "${formatMoney(kotlin.math.abs(x))} تومان ${when { x > 0 -> "بستانکار"; x < 0 -> "بدهکار"; else -> "تسویه" }}"
        b.balance.setTextColor(getColor(when { x > 0 -> R.color.credit_text; x < 0 -> R.color.debt_text; else -> R.color.neutral_text }))
    }
    private fun formatMoney(value: Long) = "%,d".format(value)
}
