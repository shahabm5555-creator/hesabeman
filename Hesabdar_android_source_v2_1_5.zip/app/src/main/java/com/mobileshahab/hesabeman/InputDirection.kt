package com.mobileshahab.hesabeman

import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText

fun EditText.autoInputDirection(): EditText {
    textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            val first = s?.toString()?.firstOrNull { !it.isWhitespace() }
            gravity = if (first != null && (first.isDigit() || first in '۰'..'۹' || first in '٠'..'٩')) {
                Gravity.LEFT or Gravity.CENTER_VERTICAL
            } else {
                Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
        }
        override fun afterTextChanged(s: Editable?) {}
    })
    return this
}
