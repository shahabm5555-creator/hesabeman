package com.mobileshahab.hesabeman

import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText

/**
 * Direction of text inside inputs:
 * numbers -> left aligned
 * Persian/normal text -> right aligned
 */
fun EditText.autoInputDirection(): EditText {
    textDirection = View.TEXT_DIRECTION_LTR
    textAlignment = View.TEXT_ALIGNMENT_VIEW_START

    fun update(value: CharSequence?) {
        val first = value?.toString()?.firstOrNull { !it.isWhitespace() }
        val isNumber = first != null && (first.isDigit() ||
                first in '۰'..'۹' || first in '٠'..'٩')
        if (isNumber) {
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        } else {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_RTL
            textAlignment = View.TEXT_ALIGNMENT_VIEW_END
        }
    }

    update(text)

    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            update(s)
        }
        override fun afterTextChanged(s: Editable?) {}
    })
    return this
}
