package com.mobileshahab.hesabeman

import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText

/**
 * Direction of text inside inputs:
 * numbers -> left aligned
 * Persian/normal text -> right aligned
 */
fun EditText.autoInputDirection(): EditText {
    // Preserve whatever vertical gravity the caller already set (e.g. multi-line note
    // fields use TOP so text starts at the top instead of jumping to the middle) — we only
    // ever want to drive the horizontal side/direction here.
    val verticalGravity = (gravity and Gravity.VERTICAL_GRAVITY_MASK)
        .let { if (it == 0) Gravity.CENTER_VERTICAL else it }

    // Track the last applied mode so we only touch textDirection/textAlignment/gravity when
    // the number-vs-text classification actually flips, not on every keystroke. Previously
    // this ran unconditionally from a TextWatcher on every character typed; reassigning
    // textDirection while the IME has an active composing region corrupts that composing
    // span, which is what made typed Persian letters (and digit runs) render out of order.
    var isNumberMode: Boolean? = null

    fun classify(value: CharSequence?): Boolean {
        val first = value?.toString()?.firstOrNull { !it.isWhitespace() }
        if (first != null) {
            return first.isDigit() || first in '۰'..'۹' || first in '٠'..'٩'
        }

        // Empty numeric fields must already be left-aligned before the first key is
        // pressed. This is important for fields whose value is supplied later or whose
        // keyboard/inputType is numeric.
        val cls = inputType and android.text.InputType.TYPE_MASK_CLASS
        return cls == android.text.InputType.TYPE_CLASS_NUMBER ||
            cls == android.text.InputType.TYPE_CLASS_PHONE ||
            cls == android.text.InputType.TYPE_CLASS_DATETIME
    }

    fun apply(isNumber: Boolean) {
        if (isNumberMode == isNumber) return
        isNumberMode = isNumber
        if (isNumber) {
            gravity = Gravity.LEFT or verticalGravity
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        } else {
            gravity = Gravity.RIGHT or verticalGravity
            textDirection = View.TEXT_DIRECTION_RTL
            textAlignment = View.TEXT_ALIGNMENT_VIEW_END
        }
    }

    apply(classify(text))

    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            apply(classify(s))
        }
    })
    return this
}
