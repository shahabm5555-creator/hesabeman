package com.mobileshahab.hesabeman

import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText

/**
 * Direction of text inside inputs:
 * numbers -> left aligned
 * Persian/normal text -> right aligned
 */
fun EditText.autoInputDirection(): EditText {
    // Preserve whatever vertical gravity the caller already set (e.g. multi-line note
    // fields use TOP so text starts at the top instead of jumping to the middle) — we only
    // ever want to drive the horizontal side/direction here.
    val verticalGravity = (gravity and Gravity.VERTICAL_GRAVITY_MASK)
        .let { if (it == 0) Gravity.CENTER_VERTICAL else it }

    // Track the last applied mode so we only touch textDirection/textAlignment/gravity when
    // the number-vs-text classification actually flips, not on every keystroke. Previously
    // this ran unconditionally from a TextWatcher on every character typed; reassigning
    // textDirection while the IME has an active composing region corrupts that composing
    // span, which is what made typed Persian letters (and digit runs) render out of order.
    var isNumberMode: Boolean? = null

    fun classify(value: CharSequence?): Boolean {
        val first = value?.toString()?.firstOrNull { !it.isWhitespace() } ?: return false
        return first.isDigit() || first in '۰'..'۹' || first in '٠'..'٩'
    }

    fun apply(isNumber: Boolean) {
        if (isNumberMode == isNumber) return
        isNumberMode = isNumber
        if (isNumber) {
            // LEFT/RIGHT are absolute here: the app itself is RTL, but numeric values
            // must still start from the physical left edge of the field.
            gravity = Gravity.LEFT or verticalGravity
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_GRAVITY
        } else {
            // Persian/normal text must start from the physical right edge.
            gravity = Gravity.RIGHT or verticalGravity
            textDirection = View.TEXT_DIRECTION_RTL
            textAlignment = View.TEXT_ALIGNMENT_GRAVITY
        }
    }

    apply(classify(text))

    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            apply(classify(s))
        }
    })
    return this
}
