package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

object InstallmentPdfExporter {
    fun export(
        context: Context, uri: Uri, notebookName: String, notebookPhone: String,
        sellerName: String, sellerAddress: String, sellerPhone: String, sellerSlogan: String,
        plan: InstallmentPlan, items: List<InstallmentItem>, onDone: (Uri) -> Unit
    ): Boolean = try {
        val W = 595f; val H = 842f; val m = 30f
        val green = Color.rgb(0,112,96); val light = Color.rgb(228,242,235); val dark = Color.rgb(42,49,47); val grid = Color.rgb(155,190,178)
        val doc = PdfDocument()
        fun paint(size: Float, color: Int = dark, align: Paint.Align = Paint.Align.CENTER) = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=size; typeface=Typeface.DEFAULT_BOLD; this.color=color; textAlign=align }
        fun fill(color:Int)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color}
        fun stroke(color:Int,w:Float=0.8f)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;strokeWidth=w;style=Paint.Style.STROKE}
        fun rr(c:Canvas,l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int,border:Int?=null){c.drawRoundRect(RectF(l,t,r,b),rad,rad,fill(color));if(border!=null)c.drawRoundRect(RectF(l,t,r,b),rad,rad,stroke(border,1f))}
        fun fit(text:String,p:Paint,max:Float):String { if(p.measureText(text)<=max)return text; var x=text; while(x.length>1&&p.measureText("$x…")>max)x=x.dropLast(1); return x+"…" }

        var pageNo=0
        var page: PdfDocument.Page? = null
        var c: Canvas? = null
        fun newPage(){ pageNo++; page=doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(),H.toInt(),pageNo).create()); c=page!!.canvas }
        fun finishPage(){ page?.let{doc.finishPage(it)}; page=null;c=null }
        fun canvas():Canvas=c ?: error("no page")

        newPage(); var y=m
        val title="فاکتور اقساط"
        val headerH=82f
        rr(canvas(),m,y,W-m,y+headerH,14f,green)
        canvas().drawText(title,W/2,y+30,paint(23f,Color.WHITE))
        if(sellerName.isNotBlank()) canvas().drawText(fit(sellerName,paint(12f,Color.WHITE),W-2*m-20),W/2,y+55,paint(12f,Color.WHITE))
        y+=headerH+10
        rr(canvas(),m,y,W-m,y+36,7f,light,green)
        canvas().drawText("حساب: ${fit(notebookName,paint(11f,dark),180f)}",W-m-10,y+23,paint(11f,green,Paint.Align.RIGHT))
        canvas().drawText("تاریخ شروع: ${plan.startDate}",m+10,y+23,paint(10f,green,Paint.Align.LEFT)); y+=45
        val cardGap=10f; val cardW=(W-2*m-cardGap)/2; val cardH=62f
        fun card(x:Float,label:String,line1:String,line2:String){rr(canvas(),x,y,x+cardW,y+cardH,9f,light,green);rr(canvas(),x,y,x+cardW,y+20,9f,green);canvas().drawRect(x,y+10,x+cardW,y+20,fill(green));canvas().drawText(label,x+cardW/2,y+14,paint(9f,Color.WHITE));if(line1.isNotBlank())canvas().drawText(fit(line1,paint(9f,dark),cardW-12),x+cardW/2,y+38,paint(9f));if(line2.isNotBlank())canvas().drawText(fit(line2,paint(8.5f,dark),cardW-12),x+cardW/2,y+53,paint(8.5f))}
        card(m,"خریدار",notebookName,notebookPhone); card(m+cardW+cardGap,"فروشنده",sellerPhone,sellerAddress); y+=cardH+12

        val totalPayable=(plan.price-plan.prepay)+plan.totalInterest
        val sumW=(W-2*m-cardGap)/2; val sumH=46f
        fun summaryCard(x:Float,yy:Float,label:String,value:String){
            rr(canvas(),x,yy,x+sumW,yy+sumH,8f,light,green)
            rr(canvas(),x,yy,x+sumW,yy+16f,8f,green)
            canvas().drawRect(x,yy+8f,x+sumW,yy+16f,fill(green))
            canvas().drawText(label,x+sumW/2,yy+11.5f,paint(8f,Color.WHITE))
            canvas().drawText(fit(value,paint(11.5f,green),sumW-12),x+sumW/2,yy+33f,paint(11.5f,green))
        }
        summaryCard(m,y,"قیمت کالا","${"%,d".format(plan.price)} تومان")
        summaryCard(m+sumW+cardGap,y,"نام کالا",plan.description)
        y+=sumH+6f
        summaryCard(m,y,"پیش‌پرداخت","${"%,d".format(plan.prepay)} تومان")
        summaryCard(m+sumW+cardGap,y,"تعداد اقساط","${plan.installmentCount} قسط")
        y+=sumH+6f
        summaryCard(m,y,"مبلغ کل اقساط","${"%,d".format(totalPayable)} تومان")
        summaryCard(m+sumW+cardGap,y,"تاریخ تسویه کل",plan.settlementDate)
        y+=sumH+12f

        fun drawTableHeader(){val top=y;val xR=W-m;val xNo=xR-48;val xDate=xNo-125;val xAmt=m;canvas().drawRect(m,top,xR,top+28,fill(green));canvas().drawText("ردیف",(xNo+xR)/2,top+19,paint(9f,Color.WHITE));canvas().drawText("تاریخ سررسید",(xDate+xNo)/2,top+19,paint(9f,Color.WHITE));canvas().drawText("مبلغ قسط",(xAmt+xDate)/2,top+19,paint(9f,Color.WHITE));canvas().drawRect(m,top,xR,top+28,stroke(grid,1f));canvas().drawLine(xNo,top,xNo,top+28,stroke(grid,0.8f));canvas().drawLine(xDate,top,xDate,top+28,stroke(grid,0.8f));y+=28}
        drawTableHeader()
        items.forEachIndexed{idx,item->
            if(y>H-m-110){finishPage();newPage();y=m;rr(canvas(),m,y,W-m,y+55,10f,green);canvas().drawText("فاکتور اقساط — ادامه جدول",W/2,y+33,paint(15f,Color.WHITE));y+=70;drawTableHeader()}
            val top=y;val xR=W-m;val xNo=xR-48;val xDate=xNo-125;val xAmt=m
            canvas().drawRect(m,top,xR,top+27,fill(if(idx%2==0)Color.WHITE else Color.rgb(247,251,249)));canvas().drawText("${item.number}",(xNo+xR)/2,top+18,paint(8.5f));canvas().drawText(item.dueDate,(xDate+xNo)/2,top+18,paint(8.5f));canvas().drawText("%,d تومان".format(item.amount),(xAmt+xDate)/2,top+18,paint(8.5f));canvas().drawRect(m,top,xR,top+27,stroke(grid,0.7f));canvas().drawLine(xNo,top,xNo,top+27,stroke(grid,0.7f));canvas().drawLine(xDate,top,xDate,top+27,stroke(grid,0.7f));y+=27
        }
        val bottom=y;canvas().drawRect(m, if(bottom>H-m-95) H-m-70 else bottom, W-m, if(bottom>H-m-95) H-m-20 else bottom+45, fill(light))
        if(bottom<=H-m-95){canvas().drawText("تعداد اقساط: ${plan.installmentCount}",m+10,bottom+20,paint(9f,green,Paint.Align.LEFT));canvas().drawText("جمع اقساط: ${"%,d".format(items.sumOf{it.amount})} تومان",W-m-10,bottom+20,paint(10f,green,Paint.Align.RIGHT)); if(sellerSlogan.isNotBlank())canvas().drawText(sellerSlogan,W/2,bottom+40,paint(11f,green))}
        finishPage(); doc.writeTo(context.contentResolver.openOutputStream(uri) ?: error("Cannot open PDF output")); doc.close(); onDone(uri); true
    } catch(e:Exception){Toast.makeText(context,"خطا در ساخت فاکتور اقساط: ${e.message}",Toast.LENGTH_LONG).show();false}
}
