package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InvoiceActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1
    private var notebookName = ""
    private var notebookPhone = ""
    private val items = mutableListOf<InvoiceItem>()
    private lateinit var itemsContainer: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var remainText: TextView
    private lateinit var kindGroup: RadioGroup
    private lateinit var kindDebt: RadioButton
    private lateinit var kindCredit: RadioButton
    private lateinit var prepayField: EditText
    private lateinit var noteField: EditText
    private var prepayAmount: Long = 0L
    private var selectedDueDate: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""
        notebookPhone = intent.getStringExtra("notebook_phone") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(color(R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, ins ->
                val b = ins.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, b.top, 0, b.bottom); ins
            }
        }

        // ── Toolbar ──
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(color(R.color.surface))
            layoutParams = LinearLayout.LayoutParams(-1, dp(60))
            addView(MaterialButton(this@InvoiceActivity).apply {
                text = "×"; textSize = 22f; minWidth = 0; insetTop = 0; insetBottom = 0
                setPadding(dp(14), 0, dp(14), 0)
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(color(R.color.text))
                layoutParams = LinearLayout.LayoutParams(-2, -1)
                setOnClickListener { finish() }
            })
            addView(TextView(this@InvoiceActivity).apply {
                text = "فاکتور جدید — $notebookName"; textSize = 15f; gravity = Gravity.CENTER
                setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(View(this@InvoiceActivity), LinearLayout.LayoutParams(dp(52), dp(52)))
        })

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(80))
        }

        // ── اقلام فاکتور ──
        inner.addView(sectionLabel("اقلام فاکتور"))
        val itemsCard = card()
        itemsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        itemsCard.addView(itemsContainer)
        inner.addView(itemsCard)
        inner.addView(MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 13f; cornerRadius = dp(14)
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft))
            setTextColor(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) }
            setOnClickListener { showAddItemDialog() }
        })

        // ── جمع و مانده ──
        inner.addView(sectionLabel("خلاصه مبالغ"))
        val summaryCard = card()
        val summaryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        totalText = sumRow(summaryBox, "جمع کل فاکتور:", "۰ تومان", color(R.color.text))
        remainText = sumRow(summaryBox, "مانده پس از پیش‌پرداخت:", "۰ تومان", color(R.color.primary))
        summaryCard.addView(summaryBox); inner.addView(summaryCard)

        // ── نوع تراکنش ──
        inner.addView(sectionLabel("نوع ثبت در حساب"))
        val kindCard = card()
        val kindBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        kindGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        }
        kindDebt = RadioButton(this).apply {
            id = View.generateViewId()
            text = "↑ پرداختی (من طلبکارم)"; textSize = 13f
            layoutParams = RadioGroup.LayoutParams(0, RadioGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        kindCredit = RadioButton(this).apply {
            id = View.generateViewId()
            text = "↓ دریافتی (من بدهکارم)"; textSize = 13f
            layoutParams = RadioGroup.LayoutParams(0, RadioGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        kindGroup.addView(kindDebt); kindGroup.addView(kindCredit)
        kindGroup.check(kindDebt.id)
        kindBox.addView(kindGroup); kindCard.addView(kindBox); inner.addView(kindCard)

        // ── پیش‌پرداخت ──
        inner.addView(sectionLabel("پیش‌پرداخت (اختیاری)"))
        val prepayCard = card()
        prepayField = EditText(this).apply {
            hint = "مبلغ پیش‌پرداخت به تومان — مثال: 500,000"
            textSize = 14f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            inputType = InputType.TYPE_CLASS_PHONE; background = null
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addTextChangedListener(numWatcher { updateSummary() })
        }
        prepayCard.addView(prepayField); inner.addView(prepayCard)

        // ── توضیحات ──
        inner.addView(sectionLabel("توضیحات"))
        val noteCard = card()
        noteField = EditText(this).apply {
            hint = "توضیحات اختیاری فاکتور"
            textSize = 13f; gravity = Gravity.END or Gravity.TOP
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            background = null; minLines = 2
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        noteCard.addView(noteField); inner.addView(noteCard)

        // ── تاریخ سررسید ──
        inner.addView(sectionLabel("تاریخ سررسید (اختیاری)"))
        val dueDateCard = card()
        val dueDateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val dueDateText = TextView(this).apply {
            text = "انتخاب تاریخ سررسید"; textSize = 13f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val dueDateBtn = MaterialButton(this).apply {
            text = "📅 انتخاب"; textSize = 12f; cornerRadius = dp(12)
            insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft))
            setTextColor(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-2, dp(38))
            setOnClickListener {
                promptJalaliDate(this@InvoiceActivity, selectedDueDate) { date ->
                    selectedDueDate = date
                    dueDateText.text = date
                    dueDateText.setTextColor(color(R.color.text))
                }
            }
        }
        dueDateRow.addView(dueDateText); dueDateRow.addView(dueDateBtn)
        dueDateCard.addView(dueDateRow); inner.addView(dueDateCard)

        // ── دکمه‌های عمل ──
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        }
        btnRow.addView(MaterialButton(this).apply {
            text = "ثبت در حساب"; textSize = 13f; cornerRadius = dp(16)
            layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) }
            setOnClickListener { doSave() }
        })
        btnRow.addView(MaterialButton(this).apply {
            text = "PDF / ذخیره"; textSize = 13f; cornerRadius = dp(16)
            backgroundTintList = ColorStateList.valueOf(color(R.color.debt_soft))
            setTextColor(color(R.color.debt_text))
            layoutParams = LinearLayout.LayoutParams(0, dp(52), 0.6f).apply { marginStart = dp(6) }
            setOnClickListener { doPdf() }
        })
        inner.addView(btnRow)

        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshItems()
    }

    // ─────────── UI helpers ───────────

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f
        setTextColor(color(R.color.secondary))
        setPadding(dp(4), dp(14), dp(4), dp(2))
    }

    private fun sumRow(parent: LinearLayout, label: String, initial: String, valColor: Int): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
        }
        row.addView(TextView(this).apply {
            this.text = label; textSize = 13f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val valView = TextView(this).apply {
            this.text = initial; textSize = 14f
            setTextColor(valColor); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        row.addView(valView); parent.addView(row)
        return valView
    }

    private fun card() = MaterialCardView(this).apply {
        radius = dp(16).toFloat(); cardElevation = dp(1).toFloat()
        setCardBackgroundColor(color(R.color.surface))
        strokeWidth = dp(1); strokeColor = color(R.color.divider)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
    }

    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ─────────── Items ───────────

    private fun refreshItems() {
        itemsContainer.removeAllViews()

        // ── Header row ──
        itemsContainer.addView(tableRow(
            listOf("ردیف" to 0.08f, "نام کالا / خدمات" to 0.38f, "تعداد" to 0.15f, "فی (تومان)" to 0.22f, "جمع" to 0.17f),
            isHeader = true
        ))
        itemsContainer.addView(hline(thick = true))

        if (items.isEmpty()) {
            itemsContainer.addView(TextView(this).apply {
                text = "هنوز قلمی اضافه نشده"; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(color(R.color.secondary))
                setPadding(0, dp(12), 0, dp(12))
            })
        }

        items.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2)
            }
            // ردیف
            row.addView(cell("${idx + 1}", 0.08f, Gravity.CENTER))
            row.addView(vline())
            // نام کالا
            row.addView(cell(item.name, 0.38f, Gravity.END))
            row.addView(vline())
            // تعداد
            row.addView(cell("${item.qty}", 0.15f, Gravity.CENTER))
            row.addView(vline())
            // فی
            row.addView(cell("%,d".format(item.unitPrice), 0.22f, Gravity.START))
            row.addView(vline())
            // جمع + دکمه حذف
            val lastCell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 0.17f)
                setPadding(dp(4), 0, dp(4), 0)
            }
            lastCell.addView(TextView(this).apply {
                text = "%,d".format(item.total); textSize = 11f
                setTextColor(color(R.color.primary))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                gravity = Gravity.START
            })
            lastCell.addView(TextView(this).apply {
                text = "×"; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(color(R.color.debt_text))
                setPadding(dp(4), 0, dp(2), 0)
                setOnClickListener { items.removeAt(idx); refreshItems() }
            })
            row.addView(lastCell)
            itemsContainer.addView(row)
            itemsContainer.addView(hline())
        }

        // ── Total row ──
        if (items.isNotEmpty()) {
            val totalRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(color(R.color.primary_soft))
                layoutParams = LinearLayout.LayoutParams(-1, -2)
            }
            totalRow.addView(cell("جمع کل", 0.83f, Gravity.END, bold = true))
            totalRow.addView(vline())
            totalRow.addView(cell("%,d".format(items.sumOf { it.total }), 0.17f, Gravity.START, bold = true, textColor = R.color.primary))
            itemsContainer.addView(totalRow)
        }

        updateSummary()
    }

    private fun tableRow(cols: List<Pair<String, Float>>, isHeader: Boolean): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            if (isHeader) setBackgroundColor(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        }
        cols.forEachIndexed { i, (text, weight) ->
            if (i > 0) row.addView(vline(if (isHeader) android.graphics.Color.argb(60, 255, 255, 255) else -1))
            val align = when (i) { 0 -> Gravity.CENTER; 1 -> Gravity.END; else -> Gravity.CENTER }
            row.addView(cell(text, weight, align, bold = isHeader,
                textColorDirect = if (isHeader) android.graphics.Color.WHITE else -1,
                textColor = R.color.secondary))
        }
        return row
    }

    private fun cell(text: String, weight: Float, align: Int, bold: Boolean = false,
                     textColor: Int = R.color.text, textColorDirect: Int = -1) = TextView(this).apply {
        this.text = text; textSize = 11f; gravity = align
        setTextColor(if (textColorDirect != -1) textColorDirect else color(textColor))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(4), dp(8), dp(4), dp(8))
        layoutParams = LinearLayout.LayoutParams(0, -2, weight)
    }

    private fun hline(thick: Boolean = false) = View(this).apply {
        setBackgroundColor(color(R.color.divider))
        layoutParams = LinearLayout.LayoutParams(-1, if (thick) dp(1) else 1)
    }

    private fun vline(col: Int = -1) = View(this).apply {
        setBackgroundColor(if (col != -1) col else color(R.color.divider))
        layoutParams = LinearLayout.LayoutParams(1, -1).also {
            it.height = LinearLayout.LayoutParams.MATCH_PARENT
        }
    }

    private fun updateSummary() {
        val total = items.sumOf { it.total }
        val prepay = parseMoney(prepayField.text.toString())
        val remain = (total - prepay).coerceAtLeast(0L)
        totalText.text = "%,d تومان".format(total)
        remainText.text = "%,d تومان".format(remain)
    }

    // ─────────── Add item dialog ───────────

    private fun showAddItemDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        fun lbl(t: String) = TextView(this).apply {
            text = t; textSize = 11f; setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        }
        fun ef(hint: String, num: Boolean = false) = EditText(this).apply {
            this.hint = hint; textSize = 14f
            gravity = if (num) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            inputType = if (num) InputType.TYPE_CLASS_PHONE else InputType.TYPE_CLASS_TEXT
            background = ContextCompat.getDrawable(this@InvoiceActivity, R.drawable.bg_search_field)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) }
        }
        val nameF = ef("نام کالا یا خدمات")
        val qtyF = ef("تعداد", num = true).also { it.setText("1") }
        val priceF = ef("فی واحد (تومان)", num = true).also { it.addTextChangedListener(numWatcher()) }

        box.addView(lbl("نام کالا / خدمات")); box.addView(nameF)
        box.addView(lbl("تعداد")); box.addView(qtyF)
        box.addView(lbl("فی واحد (تومان)")); box.addView(priceF)

        MaterialAlertDialogBuilder(this)
            .setTitle("افزودن قلم فاکتور").setView(box)
            .setPositiveButton("افزودن") { _, _ ->
                val name = nameF.text.toString().trim()
                val qty = parseMoney(qtyF.text.toString()).also { if (it <= 0) return@setPositiveButton toast("تعداد را وارد کنید") }
                val price = parseMoney(priceF.text.toString()).also { if (it <= 0) return@setPositiveButton toast("فی را وارد کنید") }
                if (name.isBlank()) return@setPositiveButton toast("نام کالا را وارد کنید")
                items.add(InvoiceItem(name = name, qty = qty, unitPrice = price))
                refreshItems()
            }
            .setNegativeButton("انصراف", null).show()
    }

    // ─────────── Save / PDF ───────────

    private fun doSave() {
        if (items.isEmpty()) return toast("حداقل یک قلم اضافه کنید")
        val prepay = parseMoney(prepayField.text.toString())
        prepayAmount = prepay
        val kind = if (kindGroup.checkedRadioButtonId == kindDebt.id) "debt" else "credit"
        val id = db.saveInvoice(notebookId, kind, items, noteField.text.toString(), Jalali.now(), prepay, selectedDueDate)
        if (id != -1L) { toast("فاکتور ثبت شد"); setResult(RESULT_OK); finish() }
        else toast("خطا در ثبت فاکتور")
    }

    private fun doPdf() {
        if (items.isEmpty()) return toast("هیچ قلمی اضافه نشده")
        prepayAmount = parseMoney(prepayField.text.toString())
        val invNum = db.nextInvoiceNumber(notebookId)
        val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val file = java.io.File(java.io.File(dir, "hesabdar/hPdf").also { it.mkdirs() },
            "فاکتور-${notebookName.replace("/","-")}-شماره${invNum}.pdf")
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        InvoicePdfExporter.export(
            context = this, uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file), invoiceNumber = invNum,
            buyerName = notebookName, buyerPhone = notebookPhone,
            sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: "",
            sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "",
            sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "",
            sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: "",
            items = items, date = Jalali.now(), prepay = prepayAmount, dueDate = selectedDueDate
        ) {
            val shareUri = try { androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file) }
                           catch (e: Exception) { androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file) }
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "ارسال فاکتور PDF"))
            toast("ذخیره در Downloads/hesabdar/hPdf")
        }
    }

    // ─────────── Helpers ───────────

    private fun parseMoney(s: String): Long {
        val normalized = s.map {
            when (it) {
                in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
                in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
                else -> it
            }
        }.joinToString("").filter(Char::isDigit)
        return normalized.toLongOrNull() ?: 0L
    }

    private fun numWatcher(extra: (() -> Unit)? = null) = object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val digits = e?.toString().orEmpty().map {
                when (it) {
                    in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
                    in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
                    else -> it
                }
            }.joinToString("").filter(Char::isDigit).trimStart('0').ifEmpty { "" }
            val formatted = if (digits.isEmpty()) "" else {
                val sb = StringBuilder()
                for ((i, c) in digits.reversed().withIndex()) { if (i > 0 && i % 3 == 0) sb.append(','); sb.append(c) }
                sb.reverse().toString()
            }
            if (e?.toString() != formatted) { busy = true; (e as? Editable)?.also { it.replace(0, it.length, formatted) }; busy = false }
            extra?.invoke()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
