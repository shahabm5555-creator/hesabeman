package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InvoiceActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId = -1L
    private var notebookName = ""
    private val items = mutableListOf<InvoiceItem>()
    private lateinit var itemsContainer: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var remainText: TextView
    private lateinit var itemStatsText: TextView
    private lateinit var kindGroup: RadioGroup
    private lateinit var kindDebt: RadioButton
    private lateinit var prepayField: EditText
    private lateinit var noteField: EditText
    private var selectedDueDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(color(R.color.background))
        }

        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(color(R.color.surface))
            layoutParams = LinearLayout.LayoutParams(-1, dp(60))
            addView(closeButton(this@InvoiceActivity, 22f, color(R.color.text), 44) { finish() }.apply {
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            })
            addView(TextView(this@InvoiceActivity).apply {
                text = "صدور فاکتور — $notebookName"; textSize = 15f; gravity = Gravity.CENTER
                setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(Space(this@InvoiceActivity), LinearLayout.LayoutParams(dp(52), dp(52)))
        })

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(70))
        }

        inner.addView(sectionLabel("اقلام فاکتور"))
        val itemsCard = card()
        itemsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        itemsCard.addView(itemsContainer)
        itemStatsText = TextView(this).apply {
            text = "تعداد کل: ۰  •  جمع: ۰ تومان"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(color(R.color.primary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        itemsCard.addView(itemStatsText)
        inner.addView(itemsCard)
        inner.addView(MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 13f; cornerRadius = dp(14)
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft))
            setTextColor(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) }
            setOnClickListener { showItemDialog(null, -1) }
        })

        inner.addView(sectionLabel("خلاصه مبالغ"))
        val summaryCard = card()
        val summaryBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        totalText = sumRow(summaryBox, "جمع کل فاکتور:", "۰ تومان", R.color.text)
        remainText = sumRow(summaryBox, "مانده پس از پیش‌پرداخت:", "۰ تومان", R.color.primary)
        summaryCard.addView(summaryBox); inner.addView(summaryCard)

        inner.addView(sectionLabel("نوع ثبت در حساب"))
        val kindCard = card()
        kindGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        kindDebt = RadioButton(this).apply { id = View.generateViewId(); text = "↑ پرداختی"; layoutParams = RadioGroup.LayoutParams(0, -2, 1f) }
        val kindCredit = RadioButton(this).apply { id = View.generateViewId(); text = "↓ دریافتی"; layoutParams = RadioGroup.LayoutParams(0, -2, 1f) }
        kindGroup.addView(kindDebt); kindGroup.addView(kindCredit); kindGroup.check(kindDebt.id)
        kindCard.addView(kindGroup); inner.addView(kindCard)

        inner.addView(sectionLabel("پیش‌پرداخت (اختیاری)"))
        val prepayCard = card()
        prepayField = moneyField("مبلغ پیش‌پرداخت به تومان")
        prepayField.addTextChangedListener(numWatcher { updateSummary() })
        prepayCard.addView(prepayField); inner.addView(prepayCard)

        inner.addView(sectionLabel("توضیحات فاکتور"))
        val noteCard = card()
        noteField = EditText(this).apply {
            hint = "توضیحات اختیاری"; textSize = 13f; gravity = Gravity.RIGHT or Gravity.TOP
            textDirection = View.TEXT_DIRECTION_RTL
            textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            background = null; minLines = 2; setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        noteCard.addView(noteField); inner.addView(noteCard)

        inner.addView(sectionLabel("تاریخ سررسید (اختیاری)"))
        val dueCard = card()
        val dueRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val dueText = TextView(this).apply { text = "انتخاب تاریخ سررسید"; textSize = 13f; setTextColor(color(R.color.secondary)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        dueRow.addView(dueText)
        dueRow.addView(MaterialButton(this).apply {
            text = "📅 انتخاب"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft)); setTextColor(color(R.color.primary))
            setOnClickListener {
                promptJalaliDate(this@InvoiceActivity, selectedDueDate) { d -> selectedDueDate = d; dueText.text = d; dueText.setTextColor(color(R.color.text)) }
            }
        })
        dueCard.addView(dueRow); inner.addView(dueCard)

        inner.addView(MaterialButton(this).apply {
            text = "ذخیره فاکتور"; textSize = 14f; cornerRadius = dp(16)
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) }
            setOnClickListener { doSave() }
        })

        scroll.addView(inner); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshItems()
    }

    private fun showItemDialog(existing: InvoiceItem?, index: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(4), dp(18), dp(4))
        }
        fun field(hint: String, numeric: Boolean = false, value: String = "") = EditText(this).apply {
            this.hint = hint
            textSize = 13f
            setText(if (numeric && value.isNotBlank()) groupDigits(parseMoney(value).toString()) else value)
            // The whole screen is RTL, but the content inside an input follows the
            // requested visual rule: numbers are on the absolute LEFT, Persian text
            // is on the absolute RIGHT. Do this explicitly here because these dialog
            // fields are created programmatically and are the most sensitive to the
            // parent RTL direction.
            inputType = if (numeric) InputType.TYPE_CLASS_PHONE else InputType.TYPE_CLASS_TEXT
            if (numeric) {
                gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
                textDirection = View.TEXT_DIRECTION_LTR
                textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            } else {
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                textDirection = View.TEXT_DIRECTION_RTL
                textAlignment = View.TEXT_ALIGNMENT_TEXT_END
            }
            background = ContextCompat.getDrawable(this@InvoiceActivity, R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
            if (!numeric) {
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                    override fun afterTextChanged(s: Editable?) {
                        if (!s.isNullOrBlank() && s.any { it.isLetter() }) {
                            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                            textDirection = View.TEXT_DIRECTION_RTL
                            textAlignment = View.TEXT_ALIGNMENT_TEXT_END
                        }
                    }
                })
            }
            if (numeric) addTextChangedListener(numWatcher())
        }
        val name = field("نام کالا", false, existing?.name.orEmpty())
        val description = field("توضیحات", false, existing?.description.orEmpty())
        val qty = field("تعداد", true, existing?.qty?.toString() ?: "1")
        val price = field("فی (تومان)", true, existing?.unitPrice?.toString().orEmpty())
        box.addView(name); box.addView(description); box.addView(qty); box.addView(price)

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "افزودن قلم" else "ویرایش قلم")
            .setView(box)
            .setPositiveButton(if (existing == null) "افزودن" else "ذخیره") { _, _ ->
                val n = name.text.toString().trim()
                val d = description.text.toString().trim()
                val q = parseMoney(qty.text.toString())
                val p = parseMoney(price.text.toString())
                if (n.isBlank() || q <= 0 || p <= 0) { toast("نام کالا، تعداد و فی را کامل وارد کنید"); return@setPositiveButton }
                val item = InvoiceItem(name = n, description = d, qty = q, unitPrice = p)
                if (existing == null) items.add(item) else items[index] = item
                refreshItems()
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun refreshItems() {
        itemsContainer.removeAllViews()
        itemsContainer.addView(tableRow(listOf("ردیف" to .08f, "نام کالا" to .28f, "توضیحات" to .28f, "تعداد" to .12f, "فی" to .17f, "×" to .07f), true))
        if (items.isEmpty()) itemsContainer.addView(TextView(this).apply {
            text = "هنوز قلمی اضافه نشده"; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(color(R.color.secondary)); setPadding(0, dp(14), 0, dp(14))
        })
        items.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setOnClickListener { showItemDialog(item, i) }
            }
            row.addView(cell("${i+1}", .08f, Gravity.CENTER))
            row.addView(cell(item.name, .28f, Gravity.RIGHT))
            row.addView(cell(item.description.ifBlank { "—" }, .28f, Gravity.RIGHT))
            row.addView(cell(item.qty.toString(), .12f, Gravity.LEFT))
            row.addView(cell("%,d".format(item.unitPrice), .17f, Gravity.LEFT))
            row.addView(TextView(this).apply {
                text = "×"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(color(R.color.debt_text))
                layoutParams = LinearLayout.LayoutParams(0, -2, .07f); setPadding(dp(2), dp(8), dp(2), dp(8))
                setOnClickListener { items.removeAt(i); refreshItems() }
            })
            itemsContainer.addView(row); itemsContainer.addView(hline())
        }
        updateSummary()
        val total = items.sumOf { it.total }
        val totalQty = items.sumOf { it.qty }
        itemStatsText.text = "تعداد کل: $totalQty  •  جمع: ${"%,d".format(total)} تومان"
    }

    private fun tableRow(cols: List<Pair<String, Float>>, header: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setBackgroundColor(if (header) color(R.color.primary) else color(R.color.surface))
        cols.forEach { (t,w) -> addView(cell(t,w,Gravity.CENTER,header,if(header) R.color.surface else R.color.text)) }
    }
    private fun cell(text:String, weight:Float, gravity:Int, bold:Boolean=false, textColor:Int=R.color.text)=TextView(this).apply{
        this.text=text; this.gravity=gravity; textSize=10f; setTextColor(color(textColor))
        if(bold)setTypeface(typeface,android.graphics.Typeface.BOLD)
        setPadding(dp(3),dp(8),dp(3),dp(8)); layoutParams=LinearLayout.LayoutParams(0,-2,weight)
    }
    private fun hline()=View(this).apply{setBackgroundColor(color(R.color.divider));layoutParams=LinearLayout.LayoutParams(-1,1)}
    private fun sectionLabel(t:String)=TextView(this).apply{ text=t;textSize=12f;setTextColor(color(R.color.secondary));setPadding(dp(4),dp(14),dp(4),dp(2))}
    private fun card()=MaterialCardView(this).apply{radius=dp(16).toFloat();cardElevation=dp(1).toFloat();setCardBackgroundColor(color(R.color.surface));strokeWidth=dp(1);strokeColor=color(R.color.divider);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4)}}
    private fun sumRow(parent:LinearLayout,label:String,initial:String,col:Int):TextView{val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};r.addView(TextView(this).apply{text=label;textSize=13f;setTextColor(color(R.color.secondary));layoutParams=LinearLayout.LayoutParams(0,-2,1f)});val v=TextView(this).apply{text=initial;textSize=14f;setTextColor(color(col));setTypeface(typeface,android.graphics.Typeface.BOLD)};r.addView(v);parent.addView(r);return v}
    private fun moneyField(h:String)=EditText(this).apply{hint=h;textSize=14f;gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL;textDirection=View.TEXT_DIRECTION_LTR;textAlignment=View.TEXT_ALIGNMENT_TEXT_START;inputType=InputType.TYPE_CLASS_PHONE;background=null;setTextColor(color(R.color.text));setHintTextColor(color(R.color.secondary));setPadding(dp(14),dp(12),dp(14),dp(12))}
    private fun groupDigits(value:String):String { val d=parseMoney(value).toString(); return d.reversed().chunked(3).joinToString(",").reversed() }
    private fun updateSummary(){val total=items.sumOf{it.total};val remain=(total-parseMoney(prepayField.text.toString())).coerceAtLeast(0);totalText.text="%,d تومان".format(total);remainText.text="%,d تومان".format(remain)}
    private fun doSave(){
        if(items.isEmpty()){toast("حداقل یک قلم اضافه کنید");return}
        val prepay=parseMoney(prepayField.text.toString())
        val kind=if(kindGroup.checkedRadioButtonId==kindDebt.id)"debt" else "credit"
        val id=db.saveInvoice(notebookId,kind,items,noteField.text.toString(),Jalali.now(),prepay,selectedDueDate)
        if(id!=-1L){toast("فاکتور ذخیره شد");setResult(RESULT_OK);finish()}else toast("خطا در ذخیره فاکتور")
    }
    private fun parseMoney(s:String):Long=s.map{when(it){in '۰'..'۹'->('0'.code+(it.code-'۰'.code)).toChar();in '٠'..'٩'->('0'.code+(it.code-'٠'.code)).toChar();else->it}}.joinToString("").filter(Char::isDigit).toLongOrNull()?:0
    private fun numWatcher(extra:(()->Unit)?=null)=object:TextWatcher{
        private var busy=false
        override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
        override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){}
        override fun afterTextChanged(e:Editable?){if(busy)return;val d=e?.toString().orEmpty().map{when(it){in '۰'..'۹'->('0'.code+(it.code-'۰'.code)).toChar();in '٠'..'٩'->('0'.code+(it.code-'٠'.code)).toChar();else->it}}.joinToString("").filter(Char::isDigit).trimStart('0');val f=if(d.isEmpty())"" else d.reversed().chunked(3).joinToString(",").reversed();if(e?.toString()!=f){busy=true;e?.replace(0,e.length,f);busy=false};extra?.invoke()}
    }
    private fun color(id:Int)=ContextCompat.getColor(this,id)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(m:String)=Toast.makeText(this,m,Toast.LENGTH_SHORT).show()
}
