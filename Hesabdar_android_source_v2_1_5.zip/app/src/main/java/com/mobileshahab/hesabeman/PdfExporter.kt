package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

/** Compact RTL account statement PDF. The rows are printed in the exact order supplied by the transaction list. */
object PdfExporter {
    fun export(
        context: Context,
        uri: Uri,
        notebookName: String,
        records: List<TxRecord>,
        balance: Long,
        sellerName: String = "",
        sellerPhone: String = "",
        sellerSlogan: String = ""
    ): Boolean = try {
        val W=595; val H=842; val m=26f
        val green=Color.rgb(0,112,96); val light=Color.rgb(232,244,239); val dark=Color.rgb(42,49,47); val grid=Color.rgb(165,190,182)
        val debtRed=Color.rgb(170,65,65)
        val doc=PdfDocument(); var pageNo=0; var page:PdfDocument.Page?=null; var c:Canvas?=null; var y=0f
        val totalDebt=records.filter{it.kind=="debt"}.sumOf{it.amount}; val totalCredit=records.filter{it.kind=="credit"}.sumOf{it.amount}
        fun p(size:Float,color:Int=dark,align:Paint.Align=Paint.Align.CENTER)=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=size;typeface=Typeface.DEFAULT_BOLD;this.color=color;textAlign=align}
        fun fill(color:Int)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color}
        fun stroke(color:Int,w:Float=.7f)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;strokeWidth=w;style=Paint.Style.STROKE}
        fun fit(s:String,paint:Paint,max:Float):String{if(paint.measureText(s)<=max)return s;var x=s;while(x.length>1&&paint.measureText("$x…")>max)x=x.dropLast(1);return x+"…"}
        fun startPage(){pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(W,H,pageNo).create());c=page!!.canvas;y=m}
        fun finishPage(){page?.let{doc.finishPage(it)};page=null;c=null}
        fun marker(value:Long):String=when{value>0->"بس";value<0->"بد";else->""}
        fun amountWithMarker(value:Long):String { val a="%,d".format(kotlin.math.abs(value)); val mk=marker(value); return if(mk.isBlank())a else "$a $mk" }
        fun header(){
            // My details are placed at the upper-left, while account and issue details remain on the right.
            if (sellerName.isNotBlank()) c!!.drawText(fit(sellerName,p(9.5f,dark,Paint.Align.LEFT),205f),m,y+13,p(9.5f,dark,Paint.Align.LEFT))
            if (sellerPhone.isNotBlank()) c!!.drawText(fit(sellerPhone,p(8.5f,Color.rgb(90,105,101),Paint.Align.LEFT),205f),m,y+29,p(8.5f,Color.rgb(90,105,101),Paint.Align.LEFT))
            c!!.drawText("صورتحساب",W/2f,y+23,p(20f,green)); c!!.drawText("حساب: ${fit(notebookName,p(10f,dark),W-2*m)}",W/2f,y+43,p(10f,dark));
            val now=Jalali.now(); c!!.drawText("تاریخ و ساعت صدور: $now",W-m,y+43,p(8.5f,Color.rgb(90,105,101),Paint.Align.RIGHT)); y+=58
            c!!.drawRect(m,y,W-m,y+1,fill(green)); y+=10
        }
        val xR=W-m; val widths=floatArrayOf(42f,78f,86f,86f,108f,0f)
        val xNo=xR-widths[0]; val xDate=xNo-widths[1]; val xDebt=xDate-widths[2]; val xCredit=xDebt-widths[3]; val xBal=xCredit-widths[4]; val xDesc=m
        fun tableHeader(){
            c!!.drawRect(m,y,xR,y+25,fill(green))
            val cells=listOf("ردیف" to Pair(xNo,xR),"تاریخ" to Pair(xDate,xNo),"بدهکار" to Pair(xDebt,xDate),"بستانکار" to Pair(xCredit,xDebt),"باقی‌مانده" to Pair(xBal,xCredit),"شرح" to Pair(xDesc,xBal))
            cells.forEach{(t,lr)->c!!.drawText(t,(lr.first+lr.second)/2,y+17,p(8.2f,Color.WHITE))}
            c!!.drawRect(m,y,xR,y+25,stroke(grid,0.8f)); listOf(xNo,xDate,xDebt,xCredit,xBal).forEach{c!!.drawLine(it,y,it,y+25,stroke(grid,.6f))}; y+=25
        }
        startPage(); header(); tableHeader()
        var running=0L
        // Do not sort here: records are already in the same newest-first order as the detail list.
        records.forEachIndexed{idx,r->
            val rowH=28f
            if(y>H-m-rowH-105){finishPage();startPage();header();tableHeader()}
            val top=y; running += if(r.kind=="credit")r.amount else -r.amount
            c!!.drawRect(m,top,xR,top+rowH,fill(if(idx%2==0)Color.WHITE else Color.rgb(248,251,250)))
            fun txt(text:String,l:Float,rgt:Float,size:Float=7.7f,align:Paint.Align=Paint.Align.CENTER,color:Int=dark){val pp=p(size,color,align);c!!.save();c!!.clipRect(l+3,top+2,rgt-3,top+rowH-2);val xx=when(align){Paint.Align.LEFT->l+5;Paint.Align.RIGHT->rgt-5;else->(l+rgt)/2};c!!.drawText(fit(text,pp,rgt-l-8),xx,top+18,pp);c!!.restore()}
            txt("${idx+1}",xNo,xR)
            txt(r.createdAt.substringBefore(" - "),xDate,xNo,7.2f)
            txt(if(r.kind=="debt")"%,d".format(r.amount) else "—",xDebt,xDate,7.5f)
            txt(if(r.kind=="credit")"%,d".format(r.amount) else "—",xCredit,xDebt,7.5f)
            txt(amountWithMarker(running),xBal,xCredit,7.2f,Paint.Align.CENTER,if(running<0)debtRed else if(running>0)green else dark)
            txt(if(r.note.isBlank())"—" else r.note,xDesc,xBal,7.1f,Paint.Align.RIGHT)
            c!!.drawRect(m,top,xR,top+rowH,stroke(grid,.55f)); listOf(xNo,xDate,xDebt,xCredit,xBal).forEach{c!!.drawLine(it,top,it,top+rowH,stroke(grid,.55f))}; y+=rowH
        }
        if(records.isEmpty()) c!!.drawText("تراکنشی ثبت نشده است.",W/2f,y+22,p(10f,dark))
        else {
            if(y>H-m-115){finishPage();startPage();header();y+=4}
            y+=8
            val finalLabel=amountWithMarker(balance)
            val q1=m; val q2=m+(W-2*m)/4f; val q3=m+(W-2*m)/2f; val q4=m+3f*(W-2*m)/4f; val q5=xR
            // Summary labels requested by the user, kept compact with minimal spacing.
            c!!.drawRect(m,y,xR,y+32,fill(light)); c!!.drawRect(m,y,xR,y+32,stroke(green,0.8f))
            val totalCells=listOf(
                "تعداد تراکنش: ${records.size}" to Pair(q4,q5),
                "کل بدهکاری: ${"%,d".format(totalDebt)}" to Pair(q3,q4),
                "کل بستانکاری: ${"%,d".format(totalCredit)}" to Pair(q2,q3),
                "مانده حساب: $finalLabel" to Pair(q1,q2)
            )
            totalCells.forEachIndexed{ i,entry->
                val cc=if(i==3&&balance<0)debtRed else green
                c!!.drawText(entry.first,(entry.second.first+entry.second.second)/2,y+21,p(7.2f,cc))
            }
            c!!.drawRect(m,y,xR,y+32,stroke(grid,.6f)); listOf(q2,q3,q4).forEach{c!!.drawLine(it,y,it,y+32,stroke(grid,.6f))}; y+=45
            c!!.drawText("مانده نهایی: $finalLabel",W/2f,y,p(8f,if(balance<0)debtRed else green))
            y+=22
            if(sellerSlogan.isNotBlank()) c!!.drawText(fit(sellerSlogan,p(8f,green),W-2*m),W/2f,y,p(8f,green))
        }
        finishPage(); context.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("Cannot open PDF output");doc.close();Toast.makeText(context,"فایل PDF صورتحساب ذخیره شد.",Toast.LENGTH_LONG).show();true
    }catch(e:Exception){Toast.makeText(context,"خطا در ساخت PDF صورتحساب: ${e.message}",Toast.LENGTH_LONG).show();false}
}
