package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

/** Account statement PDF with a clean RTL table and running balance. */
object PdfExporter {
    fun export(context: Context, uri: Uri, notebookName: String, records: List<TxRecord>, balance: Long): Boolean = try {
        val W=595; val H=842; val m=30f
        val green=Color.rgb(0,112,96); val light=Color.rgb(228,242,235); val dark=Color.rgb(42,49,47); val grid=Color.rgb(155,190,178)
        val doc=PdfDocument(); var pageNo=0; var page:PdfDocument.Page?=null; var c:Canvas?=null; var y=0f
        fun p(size:Float,color:Int=dark,align:Paint.Align=Paint.Align.CENTER)=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=size;typeface=Typeface.DEFAULT_BOLD;this.color=color;textAlign=align}
        fun fill(color:Int)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color}
        fun stroke(color:Int,w:Float=.8f)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;strokeWidth=w;style=Paint.Style.STROKE}
        fun rr(l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int,border:Int?=null){c!!.drawRoundRect(RectF(l,t,r,b),rad,rad,fill(color));if(border!=null)c!!.drawRoundRect(RectF(l,t,r,b),rad,rad,stroke(border,1f))}
        fun fit(s:String,paint:Paint,max:Float):String{if(paint.measureText(s)<=max)return s;var x=s;while(x.length>1&&paint.measureText("$x…")>max)x=x.dropLast(1);return x+"…"}
        fun startPage(){pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(W,H,pageNo).create());c=page!!.canvas;y=m}
        fun finishPage(){page?.let{doc.finishPage(it)};page=null;c=null}
        fun header(){
            rr(m,y,W-m,y+72,12f,green)
            c!!.drawText("صورت حساب",W/2f,y+27,p(22f,Color.WHITE))
            c!!.drawText("حساب: ${fit(notebookName,p(11f,Color.WHITE),W-2*m-24)}",W/2f,y+51,p(11f,Color.WHITE))
            y+=84
            rr(m,y,W-m,y+34,7f,light,green)
            val type=if(balance<0)"بدهکار" else if(balance>0)"بستانکار" else "تسویه"
            c!!.drawText("مانده نهایی: ${"%,d".format(kotlin.math.abs(balance))} تومان — $type",W-m-10,y+22,p(10f,green,Paint.Align.RIGHT))
            y+=45
        }
        fun tableHeader(){
            val xR=W-m; val xNo=xR-38; val xDate=xNo-82; val xKind=xDate-78; val xAmt=xKind-132; val xBal=m
            c!!.drawRect(m,y,xR,y+27,fill(green))
            c!!.drawText("ردیف",(xNo+xR)/2,y+18,p(8.5f,Color.WHITE))
            c!!.drawText("تاریخ",(xDate+xNo)/2,y+18,p(8.5f,Color.WHITE))
            c!!.drawText("نوع",(xKind+xDate)/2,y+18,p(8.5f,Color.WHITE))
            c!!.drawText("مبلغ",(xAmt+xKind)/2,y+18,p(8.5f,Color.WHITE))
            c!!.drawText("شرح / مانده",(xBal+xAmt)/2,y+18,p(8.5f,Color.WHITE))
            c!!.drawRect(m,y,xR,y+27,stroke(grid,1f));listOf(xNo,xDate,xKind,xAmt).forEach{c!!.drawLine(it,y,it,y+27,stroke(grid,.7f))};y+=27
        }
        startPage();header();tableHeader()
        var running=0L
        records.forEachIndexed{idx,r->
            if(y>H-m-55){finishPage();startPage();header();tableHeader()}
            val top=y;val rowH=36f;val xR=W-m;val xNo=xR-38;val xDate=xNo-82;val xKind=xDate-78;val xAmt=xKind-132;val xBal=m
            running += if(r.kind=="credit") r.amount else -r.amount
            c!!.drawRect(m,top,xR,top+rowH,fill(if(idx%2==0)Color.WHITE else Color.rgb(247,251,249)))
            fun cell(text:String,l:Float,rgt:Float,align:Paint.Align=Paint.Align.CENTER){val pp=p(8f);c!!.save();c!!.clipRect(l+3,top+2,rgt-3,top+rowH-2);val xx=when(align){Paint.Align.LEFT->l+5;Paint.Align.RIGHT->rgt-5;else->(l+rgt)/2};c!!.drawText(fit(text,pp,rgt-l-8),xx,top+16,pp);c!!.restore()}
            cell("${idx+1}",xNo,xR);cell(r.createdAt,xDate,xNo);cell(if(r.kind=="debt")"پرداختی" else "دریافتی",xKind,xDate)
            cell("${"%,d".format(r.amount)}",xAmt,xKind,Paint.Align.RIGHT)
            val note=if(r.note.isBlank())"—" else r.note
            val pp=p(7.7f,dark,Paint.Align.RIGHT);c!!.save();c!!.clipRect(xBal+4,top+2,xAmt-4,top+rowH-2);c!!.drawText(fit(note,pp,xAmt-xBal-8),xAmt-6,top+15,pp);c!!.restore()
            val balP=p(7.5f,green,Paint.Align.RIGHT);c!!.drawText("مانده: ${"%,d".format(kotlin.math.abs(running))}",xAmt-6,top+29,balP)
            c!!.drawRect(m,top,xR,top+rowH,stroke(grid,.65f));listOf(xNo,xDate,xKind,xAmt).forEach{c!!.drawLine(it,top,it,top+rowH,stroke(grid,.65f))};y+=rowH
        }
        if(records.isEmpty()) c!!.drawText("تراکنشی ثبت نشده است.",W/2f,y+22,p(11f,dark))
        else {y+=10;rr(m,y,W-m,y+44,8f,light,green);c!!.drawText("تعداد تراکنش‌ها: ${records.size}",m+10,y+27,p(9f,green,Paint.Align.LEFT));c!!.drawText("مانده نهایی: ${"%,d".format(kotlin.math.abs(balance))} تومان",W-m-10,y+27,p(10f,green,Paint.Align.RIGHT))}
        finishPage();context.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("Cannot open PDF output");doc.close();Toast.makeText(context,"فایل PDF حساب ذخیره شد.",Toast.LENGTH_LONG).show();true
    }catch(e:Exception){Toast.makeText(context,"خطا در ساخت PDF حساب: ${e.message}",Toast.LENGTH_LONG).show();false}
}
