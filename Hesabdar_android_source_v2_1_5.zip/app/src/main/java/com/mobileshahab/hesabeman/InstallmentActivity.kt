package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.round

class InstallmentActivity : BaseActivity() {
    private lateinit var db: DbHelper
    private var notebookId=-1L; private var notebookName=""
    private lateinit var startText:TextView; private lateinit var desc:EditText; private lateinit var price:EditText; private lateinit var prepay:EditText
    private lateinit var percent:EditText; private lateinit var count:EditText; private lateinit var interval:EditText
    private lateinit var settlement:TextView; private lateinit var preview:TextView
    private var pendingPlanId=-1L
    private var pendingPdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if(uri!=null && pendingPlanId>0){ val plan=db.installmentPlan(pendingPlanId); if(plan!=null) InstallmentPdfExporter.export(this,uri,notebookName,db.notebookInfo(notebookId).phone,sellerName(),sellerAddress(),sellerPhone(),sellerSlogan(),plan,db.installmentItems(plan.id)) {} }
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);db=DbHelper(this);notebookId=intent.getLongExtra("notebook_id",-1);notebookName=intent.getStringExtra("notebook_name")?:"حساب";buildUi()}
    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setBackgroundColor(color(R.color.background))}
        val toolbar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(color(R.color.surface));layoutParams=LinearLayout.LayoutParams(-1,dp(62))}
        val close=MaterialButton(this).apply{text="×";textSize=22f;minWidth=0;insetTop=0;insetBottom=0;backgroundTintList=ColorStateList.valueOf(android.graphics.Color.TRANSPARENT);setTextColor(color(R.color.text));setOnClickListener{finish()}}
        toolbar.addView(close,LinearLayout.LayoutParams(dp(52),-1));toolbar.addView(TextView(this).apply{text="محاسبه اقساط — $notebookName";textSize=16f;gravity=Gravity.CENTER;setTypeface(typeface,android.graphics.Typeface.BOLD);setTextColor(color(R.color.text));layoutParams=LinearLayout.LayoutParams(0,-2,1f)});toolbar.addView(View(this),LinearLayout.LayoutParams(dp(52),dp(52)));root.addView(toolbar)
        val scroll=ScrollView(this);val inner=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(24))};scroll.addView(inner);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        inner.addView(section("مشخصات اقساط"))
        startText=selectField("تاریخ شروع قسط",Jalali.now().substringBefore(" - ")){promptJalaliDate(this,startText.text.toString()){startText.text=it;calculate()}};inner.addView(card(startText))
        desc=field("توضیحات: مثال نام کالا");inner.addView(card(desc))
        price=moneyField("قیمت / مبلغ کالا");prepay=moneyField("پیش پرداخت");percent=plainField("درصد سود ماهانه");count=plainField("تعداد قسط");interval=plainField("تعداد روز فاصله اقساط")
        listOf(price,prepay,percent,count,interval).forEach{inner.addView(card(it))}
        settlement=TextView(this).apply{text="تاریخ تسویه کل: —";textSize=13f;setTextColor(color(R.color.primary));setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(dp(12),dp(12),dp(12),dp(12))};inner.addView(card(settlement))
        preview=TextView(this).apply{text="محاسبه پس از تکمیل اطلاعات نمایش داده می‌شود.";textSize=12f;setTextColor(color(R.color.secondary));gravity=Gravity.CENTER;setPadding(dp(14),dp(14),dp(14),dp(14))};inner.addView(card(preview))
        val save=MaterialButton(this).apply{text="ثبت اقساط";textSize=14f;cornerRadius=dp(15);layoutParams=LinearLayout.LayoutParams(-1,dp(54)).apply{topMargin=dp(16)}};inner.addView(save)
        val savePdf=MaterialButton(this).apply{text="ثبت اقساط و ذخیره فاکتور PDF";textSize=14f;cornerRadius=dp(15);backgroundTintList=ColorStateList.valueOf(color(R.color.primary));setTextColor(android.graphics.Color.WHITE);layoutParams=LinearLayout.LayoutParams(-1,dp(54)).apply{topMargin=dp(8)}};inner.addView(savePdf)
        val w=watcher();listOf(price,prepay,percent,count,interval).forEach{it.addTextChangedListener(w)}
        save.setOnClickListener{createPlan(false)};savePdf.setOnClickListener{createPlan(true)};calculate()
        setContentView(root)
    }
    private fun createPlan(pdf:Boolean){
        val start=startText.text.toString();val d=desc.text.toString().trim();val p=parseMoney(price.text.toString());val pp=parseMoney(prepay.text.toString());val pr=normalize(percent.text.toString()).replace(",","").toDoubleOrNull()?:0.0;val n=normalize(count.text.toString()).toIntOrNull()?:0;val gap=normalize(interval.text.toString()).toIntOrNull()?:0
        if(!Jalali.isValidDate(start)||d.isBlank()||p<=0||pp<0||pp>=p||pr<0||n<=0||gap<=0){toast("اطلاعات اقساط را کامل و صحیح وارد کنید");return}
        val id=db.createInstallmentPlan(notebookId,start,d,p,pp,pr,n,gap);if(id<=0){toast("ثبت اقساط انجام نشد");return};pendingPlanId=id
        if(pdf){pendingPdfLauncher.launch("فاکتور اقساط-${notebookName.replace("/","-")}.pdf")}else{toast("برنامه اقساط و سررسیدها ثبت شد");setResult(RESULT_OK);finish()}
    }
    private fun calculate(){
        val p=parseMoney(price.text.toString());val pp=parseMoney(prepay.text.toString());val pr=normalize(percent.text.toString()).replace(",","").toDoubleOrNull()?:0.0;val n=normalize(count.text.toString()).toIntOrNull()?:0;val gap=normalize(interval.text.toString()).toIntOrNull()?:0
        if(p<=0||pp<0||pp>=p||n<=0||gap<=0){settlement.text="تاریخ تسویه کل: —";preview.text="قیمت، پیش‌پرداخت، سود، تعداد و فاصله اقساط را وارد کنید.";return}
        val principal=p-pp;val interest=round(principal*pr/100.0*n).toLong();val total=principal+interest;val each=total/n;val rem=total%n;val end=try{Jalali.addDays(startText.text.toString(),gap*n)}catch(_:Exception){"—"};settlement.text="تاریخ تسویه کل: $end";preview.text="مبلغ باقی‌مانده: ${"%,d".format(principal)} تومان\nسود کل: ${"%,d".format(interest)} تومان\nجمع اقساط: ${"%,d".format(total)} تومان\nهر قسط: ${"%,d".format(each)} تومان${if(rem>0)"\nقسط آخر: ${"%,d".format(each+rem)} تومان" else ""}"
    }
    private fun watcher()=object:TextWatcher{var busy=false;override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val v=e?.toString().orEmpty();val field=e;val normalized=if(e==price.text||e==prepay.text)groupDigits(v) else normalize(v);if(v!=normalized){busy=true;field?.replace(0,field.length,normalized);busy=false};calculate()}}
    private fun sellerName()=AppPrefs.prefs(this).getString(AppPrefs.SELLER_NAME,"")?:"";private fun sellerAddress()=AppPrefs.prefs(this).getString(AppPrefs.SELLER_ADDRESS,"")?:"";private fun sellerPhone()=AppPrefs.prefs(this).getString(AppPrefs.SELLER_PHONE,"")?:"";private fun sellerSlogan()=AppPrefs.prefs(this).getString(AppPrefs.SELLER_SLOGAN,"با تشکر از خرید شما")?:"با تشکر از خرید شما"
    private fun card(v:View)=MaterialCardView(this).apply{radius=dp(15).toFloat();cardElevation=dp(1).toFloat();setCardBackgroundColor(color(R.color.surface));strokeWidth=dp(1);strokeColor=color(R.color.divider);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)}}.also{it.addView(v)}
    private fun field(h:String)=plainField(h).apply{inputType=InputType.TYPE_CLASS_TEXT;gravity=Gravity.END}
    private fun plainField(h:String)=EditText(this).apply{hint=h;textSize=14f;gravity=Gravity.CENTER_VERTICAL or Gravity.END;inputType=InputType.TYPE_CLASS_PHONE;background=null;setTextColor(color(R.color.text));setHintTextColor(color(R.color.secondary));setPadding(dp(14),dp(12),dp(14),dp(12));layoutParams=LinearLayout.LayoutParams(-1,dp(52))}
    private fun moneyField(h:String)=plainField(h).apply{inputType=InputType.TYPE_CLASS_PHONE}
    private fun selectField(h:String,value:String,click:()->Unit)=TextView(this).apply{text="$h: $value";textSize=14f;gravity=Gravity.CENTER_VERTICAL or Gravity.END;setTextColor(color(R.color.text));setPadding(dp(14),dp(12),dp(14),dp(12));isClickable=true;setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(52))}
    private fun section(t:String)=TextView(this).apply{text=t;textSize=12f;setTextColor(color(R.color.secondary));setPadding(dp(4),dp(14),dp(4),dp(2))}
    private fun normalize(s:String)=s.map{when(it){in '۰'..'۹'->('0'.code+(it.code-'۰'.code)).toChar();in '٠'..'٩'->('0'.code+(it.code-'٠'.code)).toChar();else->it}}.joinToString("")
    private fun parseMoney(s:String)=normalize(s).replace(",","").filter{it.isDigit()}.toLongOrNull()?:0L
    private fun groupDigits(s:String):String{val d=normalize(s).filter{it.isDigit()}.trimStart('0');if(d.isEmpty())return "";return d.reversed().chunked(3).joinToString(",").reversed()}
    private fun color(id:Int)=ContextCompat.getColor(this,id);private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt();private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
