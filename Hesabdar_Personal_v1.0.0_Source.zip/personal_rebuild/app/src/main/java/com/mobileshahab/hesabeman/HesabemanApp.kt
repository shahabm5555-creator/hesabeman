package com.mobileshahab.hesabeman

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class HesabemanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // The live DB is private to the app. Only an app-private recovery snapshot
        // may be used automatically, and only when the live DB is missing/corrupt.
        // External backups are never imported during startup.
        DatabaseManager.initialize(this)
    }
}
