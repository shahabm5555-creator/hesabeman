plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mobileshahab.hesabeman"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mobileshahab.hesabeman"
        minSdk = 24
        targetSdk = 35
        versionCode = 108
        versionName = "1.0.8"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("test-signing.jks")
            storePassword = "hesabeman105"
            keyAlias = "hesabeman"
            keyPassword = "hesabeman105"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.biometric:biometric:1.1.0")
}
