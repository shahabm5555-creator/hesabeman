package com.mobileshahab.hesabeman

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import com.mobileshahab.hesabeman.databinding.ActivityAboutBinding

class AboutActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityAboutBinding.inflate(layoutInflater); setContentView(b.root)
        b.instagram.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/mobile.shahab_/")))
        }
        b.phone.setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:09359405555")))
        }
    }
}
