package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {
    fun backup(context: Context) {
        try {
            val helper = DbHelper(context)
            helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { }
            helper.close()
            val src = context.getDatabasePath(DbHelper.DB_NAME)
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val name = "hesabeman_backup_$stamp.db"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/hesabeman")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Cannot create backup file")
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(src).use { it.copyTo(out) }
                } ?: error("Cannot open backup output")
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "hesabeman")
                if (!dir.exists()) dir.mkdirs()
                FileInputStream(src).use { input ->
                    FileOutputStream(File(dir, name)).use { output -> input.copyTo(output) }
                }
            }
            Toast.makeText(context, "بکاپ در Download/hesabeman ذخیره شد.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در بکاپ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun restore(context: Context, uri: Uri): Boolean {
        val dbFile = context.getDatabasePath(DbHelper.DB_NAME)
        val tmp = File(context.cacheDir, "restore_candidate.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output) }
            } ?: error("فایل قابل خواندن نیست")

            val check = android.database.sqlite.SQLiteDatabase.openDatabase(
                tmp.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
            )
            val valid = check.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('folders','notebooks','tx')", null).use {
                var count = 0
                while (it.moveToNext()) count++
                count == 3
            }
            check.close()
            if (!valid) error("این فایل بکاپ معتبر حسابدار من نیست")

            DbHelper(context).close()
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            dbFile.parentFile?.mkdirs()
            FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { output -> input.copyTo(output) } }
            tmp.delete()
            true
        } catch (e: Exception) {
            tmp.delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
