package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: SimpleAdapter

    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("بازیابی بکاپ")
                .setMessage("اطلاعات فعلی برنامه با اطلاعات این بکاپ جایگزین شود؟")
                .setPositiveButton("بازیابی") { _, _ ->
                    db.close()
                    if (BackupManager.restore(this, uri)) {
                        Toast.makeText(this, "بازیابی با موفقیت انجام شد.", Toast.LENGTH_LONG).show()
                        db = DbHelper(this)
                        refresh()
                    } else {
                        db = DbHelper(this)
                    }
                }
                .setNegativeButton("انصراف", null)
                .show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        adapter = SimpleAdapter(emptyList()) {
            startActivity(Intent(this, FolderActivity::class.java)
                .putExtra("folder_id", it.id).putExtra("folder_name", it.title))
        }
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter
        b.add.setOnClickListener {
            if (db.countFolders(null) >= 10) {
                Toast.makeText(this, "حداکثر ۱۰ پوشه اصلی مجاز است.", Toast.LENGTH_LONG).show()
            } else {
                promptText(this, "پوشه جدید", "نام پوشه") { name ->
                    if (db.addFolder(null, name)) refresh()
                }
            }
        }
        b.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.search -> startActivity(Intent(this, SearchActivity::class.java))
                R.id.backup -> BackupManager.backup(this)
                R.id.restore -> restorePicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "*/*"))
                R.id.settings -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.about -> startActivity(Intent(this, AboutActivity::class.java))
            }
            true
        }
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        val items = db.folders(null)
        adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
