package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RowItem(val id: Long, val title: String)
data class SearchHit(val id: Long, val type: String, val title: String, val targetName: String)
data class TxRecord(val id: Long, val kind: String, val amount: Long, val note: String, val createdAt: String)

class DbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 1) {
    companion object { const val DB_NAME = "hesabeman.db" }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE folders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER,
            name TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE notebooks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            name TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notebook_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addFolder(parentId: Long?, name: String): Boolean {
        if (parentId == null && countFolders(null) >= 10) return false
        if (parentId != null) {
            if (parentId(parentId) != null) return false
            if (countFolders(parentId) >= 1) return false
        }
        return writableDatabase.insert("folders", null, ContentValues().apply {
            if (parentId == null) putNull("parent_id") else put("parent_id", parentId)
            put("name", name)
        }) != -1L
    }

    fun folders(parentId: Long?): List<RowItem> {
        val out = mutableListOf<RowItem>()
        val sql = if (parentId == null)
            "SELECT id,name FROM folders WHERE parent_id IS NULL ORDER BY id DESC"
        else "SELECT id,name FROM folders WHERE parent_id=? ORDER BY id DESC"
        val args = if (parentId == null) null else arrayOf(parentId.toString())
        readableDatabase.rawQuery(sql, args).use {
            while (it.moveToNext()) out += RowItem(it.getLong(0), it.getString(1))
        }
        return out
    }

    fun countFolders(parentId: Long?): Int {
        val sql = if (parentId == null) "SELECT COUNT(*) FROM folders WHERE parent_id IS NULL" else "SELECT COUNT(*) FROM folders WHERE parent_id=?"
        val args = if (parentId == null) null else arrayOf(parentId.toString())
        readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst()) return it.getInt(0) }
        return 0
    }

    fun parentId(folderId: Long): Long? {
        readableDatabase.rawQuery("SELECT parent_id FROM folders WHERE id=?", arrayOf(folderId.toString())).use {
            if (it.moveToFirst()) return if (it.isNull(0)) null else it.getLong(0)
        }
        return null
    }

    fun addNotebook(folderId: Long, name: String): Boolean {
        if (countNotebooks(folderId) >= 30) return false
        return writableDatabase.insert("notebooks", null, ContentValues().apply {
            put("folder_id", folderId); put("name", name)
        }) != -1L
    }

    fun countNotebooks(folderId: Long): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notebooks WHERE folder_id=?", arrayOf(folderId.toString())).use {
            if (it.moveToFirst()) return it.getInt(0)
        }
        return 0
    }

    fun notebooks(folderId: Long): List<RowItem> {
        val out = mutableListOf<RowItem>()
        readableDatabase.rawQuery(
            "SELECT id,name FROM notebooks WHERE folder_id=? ORDER BY id DESC",
            arrayOf(folderId.toString())
        ).use { while (it.moveToNext()) out += RowItem(it.getLong(0), it.getString(1)) }
        return out
    }

    fun notebookName(notebookId: Long): String {
        readableDatabase.rawQuery("SELECT name FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return "دفترچه حساب"
    }

    fun addTx(notebookId: Long, kind: String, amount: Long, note: String, date: String) {
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("notebook_id", notebookId); put("kind", kind); put("amount", amount)
            put("note", note); put("created_at", date)
        })
    }

    fun txRecords(notebookId: Long): List<TxRecord> {
        val out = mutableListOf<TxRecord>()
        readableDatabase.rawQuery(
            "SELECT id,kind,amount,note,created_at FROM tx WHERE notebook_id=? ORDER BY id DESC",
            arrayOf(notebookId.toString())
        ).use {
            while (it.moveToNext()) out += TxRecord(
                it.getLong(0), it.getString(1), it.getLong(2), it.getString(3).orEmpty(), it.getString(4)
            )
        }
        return out
    }

    fun tx(notebookId: Long): List<RowItem> = txRecords(notebookId).map {
        val kind = if (it.kind == "debt") "بدهکار" else "بستانکار"
        RowItem(it.id, "$kind — ${"%,d".format(it.amount)} تومان\n${it.note}\n${it.createdAt}")
    }

    fun balance(notebookId: Long): Long {
        readableDatabase.rawQuery(
            """SELECT COALESCE(SUM(CASE WHEN kind='credit' THEN amount ELSE -amount END),0)
               FROM tx WHERE notebook_id=?""",
            arrayOf(notebookId.toString())
        ).use { if (it.moveToFirst()) return it.getLong(0) }
        return 0
    }

    fun search(q: String): List<SearchHit> {
        val x = "%$q%"
        val out = mutableListOf<SearchHit>()
        readableDatabase.rawQuery("SELECT id,name FROM folders WHERE name LIKE ? LIMIT 20", arrayOf(x)).use {
            while (it.moveToNext()) out += SearchHit(it.getLong(0), "folder", "پوشه: ${it.getString(1)}", it.getString(1))
        }
        readableDatabase.rawQuery("SELECT id,name FROM notebooks WHERE name LIKE ? LIMIT 30", arrayOf(x)).use {
            while (it.moveToNext()) out += SearchHit(it.getLong(0), "notebook", "دفترچه: ${it.getString(1)}", it.getString(1))
        }
        readableDatabase.rawQuery(
            """SELECT t.notebook_id,n.name,t.kind,t.amount,t.note,t.created_at
               FROM tx t JOIN notebooks n ON n.id=t.notebook_id
               WHERE t.note LIKE ? OR CAST(t.amount AS TEXT) LIKE ? LIMIT 30""",
            arrayOf(x, x)
        ).use {
            while (it.moveToNext()) {
                val kind = if (it.getString(2) == "debt") "بدهکار" else "بستانکار"
                val display = "${it.getString(1)} — $kind — ${"%,d".format(it.getLong(3))} تومان\n${it.getString(4).orEmpty()} | ${it.getString(5)}"
                out += SearchHit(it.getLong(0), "notebook", display, it.getString(1))
            }
        }
        return out
    }
}
