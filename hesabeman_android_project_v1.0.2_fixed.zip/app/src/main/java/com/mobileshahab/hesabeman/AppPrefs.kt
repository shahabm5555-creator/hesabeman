package com.mobileshahab.hesabeman

import android.content.Context
import java.security.MessageDigest

object AppPrefs {
    const val FILE = "hesabeman_prefs"
    const val TEXT_SIZE = "text_size"
    const val LOCK_MODE = "lock_mode"
    const val PIN_HASH = "pin_hash"

    fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(("hesabeman:$pin").toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
