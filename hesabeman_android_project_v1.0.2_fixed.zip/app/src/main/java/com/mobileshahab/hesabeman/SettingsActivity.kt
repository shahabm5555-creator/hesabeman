package com.mobileshahab.hesabeman

import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.biometric.BiometricManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivitySettingsBinding

class SettingsActivity : BaseActivity() {
    private lateinit var b: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater); setContentView(b.root)
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }

        val prefs = AppPrefs.prefs(this)
        when (prefs.getString(AppPrefs.TEXT_SIZE, "normal")) {
            "medium" -> b.textMedium.isChecked = true
            "large" -> b.textLarge.isChecked = true
            else -> b.textNormal.isChecked = true
        }
        when (prefs.getString(AppPrefs.LOCK_MODE, "off")) {
            "pin" -> b.lockPin.isChecked = true
            "biometric" -> b.lockBiometric.isChecked = true
            else -> b.lockOff.isChecked = true
        }

        b.textGroup.setOnCheckedChangeListener { _, id ->
            val value = when (id) {
                R.id.textMedium -> "medium"
                R.id.textLarge -> "large"
                else -> "normal"
            }
            prefs.edit().putString(AppPrefs.TEXT_SIZE, value).apply()
            recreate()
        }

        b.lockGroup.setOnCheckedChangeListener { _, id ->
            when (id) {
                R.id.lockOff -> prefs.edit().putString(AppPrefs.LOCK_MODE, "off").apply()
                R.id.lockPin -> requestPin()
                R.id.lockBiometric -> enableBiometric()
            }
        }
    }

    private fun requestPin() {
        val input = EditText(this).apply {
            hint = "رمز ۴ رقمی"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            maxLines = 1
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("تنظیم رمز برنامه")
            .setMessage("یک رمز ۴ رقمی وارد کنید.")
            .setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                val pin = input.text.toString()
                if (pin.length == 4 && pin.all { it.isDigit() }) {
                    AppPrefs.prefs(this).edit()
                        .putString(AppPrefs.PIN_HASH, AppPrefs.hashPin(pin))
                        .putString(AppPrefs.LOCK_MODE, "pin")
                        .apply()
                    Toast.makeText(this, "قفل با رمز فعال شد.", Toast.LENGTH_SHORT).show()
                } else {
                    b.lockOff.isChecked = true
                    Toast.makeText(this, "رمز باید دقیقاً ۴ رقم باشد.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف") { _, _ -> b.lockOff.isChecked = true }
            .setOnCancelListener { b.lockOff.isChecked = true }
            .show()
    }

    private fun enableBiometric() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) {
            AppPrefs.prefs(this).edit().putString(AppPrefs.LOCK_MODE, "biometric").apply()
            Toast.makeText(this, "قفل اثر انگشت فعال شد.", Toast.LENGTH_SHORT).show()
        } else {
            b.lockOff.isChecked = true
            Toast.makeText(this, "اثر انگشت در این دستگاه آماده نیست.", Toast.LENGTH_LONG).show()
        }
    }
}
