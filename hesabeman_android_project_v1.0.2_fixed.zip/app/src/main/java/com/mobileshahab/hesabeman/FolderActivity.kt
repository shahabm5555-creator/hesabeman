package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivityFolderBinding

class FolderActivity : BaseActivity() {
    private lateinit var b: ActivityFolderBinding
    private lateinit var db: DbHelper
    private lateinit var folderAdapter: SimpleAdapter
    private lateinit var notebookAdapter: SimpleAdapter
    private var folderId = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFolderBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        folderId = intent.getLongExtra("folder_id", 0)
        b.toolbar.title = intent.getStringExtra("folder_name") ?: "پوشه"
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }

        folderAdapter = SimpleAdapter(emptyList()) {
            startActivity(Intent(this, FolderActivity::class.java)
                .putExtra("folder_id", it.id).putExtra("folder_name", it.title))
        }
        notebookAdapter = SimpleAdapter(emptyList()) {
            startActivity(Intent(this, NotebookActivity::class.java)
                .putExtra("notebook_id", it.id).putExtra("notebook_name", it.title))
        }
        b.folders.layoutManager = LinearLayoutManager(this); b.folders.adapter = folderAdapter
        b.notebooks.layoutManager = LinearLayoutManager(this); b.notebooks.adapter = notebookAdapter

        val isSubfolder = db.parentId(folderId) != null
        if (isSubfolder) {
            b.addFolder.visibility = View.GONE
            b.subfolderTitle.visibility = View.GONE
            b.folders.visibility = View.GONE
        }

        b.addFolder.setOnClickListener {
            if (db.countFolders(folderId) >= 1) {
                Toast.makeText(this, "برای هر پوشه فقط یک زیرپوشه مجاز است.", Toast.LENGTH_LONG).show()
            } else {
                promptText(this, "زیرپوشه جدید", "نام زیرپوشه") {
                    if (db.addFolder(folderId, it)) refresh()
                }
            }
        }
        b.addNotebook.setOnClickListener {
            if (db.countNotebooks(folderId) >= 30) {
                Toast.makeText(this, "در هر پوشه حداکثر ۳۰ دفترچه مجاز است.", Toast.LENGTH_LONG).show()
            } else {
                promptText(this, "دفترچه حساب جدید", "نام دفترچه") {
                    if (db.addNotebook(folderId, it)) refresh()
                }
            }
        }
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        folderAdapter.submit(db.folders(folderId))
        notebookAdapter.submit(db.notebooks(folderId))
    }
}
