package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

object PdfExporter {
    fun export(context: Context, uri: Uri, notebookName: String, records: List<TxRecord>, balance: Long): Boolean {
        return try {
            val doc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 42f
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 20f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT
            }
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 13f; textAlign = Paint.Align.RIGHT
            }
            val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 11f; textAlign = Paint.Align.RIGHT
            }
            var pageNumber = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas = page.canvas
            var y = 60f

            fun header() {
                canvas.drawText("حسابدار من", pageWidth - margin, y, titlePaint); y += 34f
                canvas.drawText("دفترچه: $notebookName", pageWidth - margin, y, textPaint); y += 26f
                val type = if (balance >= 0) "بستانکار" else "بدهکار"
                canvas.drawText("مانده: ${"%,d".format(kotlin.math.abs(balance))} تومان $type", pageWidth - margin, y, textPaint); y += 34f
            }
            fun newPage() {
                doc.finishPage(page)
                pageNumber++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = 60f
                header()
            }

            header()
            if (records.isEmpty()) {
                canvas.drawText("تراکنشی ثبت نشده است.", pageWidth - margin, y, textPaint)
            } else {
                records.forEachIndexed { index, r ->
                    if (y > 760f) newPage()
                    val kind = if (r.kind == "debt") "بدهکار" else "بستانکار"
                    canvas.drawText("${index + 1}. $kind — ${"%,d".format(r.amount)} تومان", pageWidth - margin, y, textPaint); y += 20f
                    canvas.drawText(r.createdAt, pageWidth - margin, y, smallPaint); y += 18f
                    if (r.note.isNotBlank()) {
                        val note = if (r.note.length > 65) r.note.take(65) + "…" else r.note
                        canvas.drawText("توضیحات: $note", pageWidth - margin, y, smallPaint); y += 18f
                    }
                    y += 10f
                }
            }
            doc.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Cannot open PDF output")
            doc.close()
            Toast.makeText(context, "فایل PDF ذخیره شد.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ساخت PDF: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
