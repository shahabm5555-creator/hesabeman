package com.mobileshahab.hesabeman

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivityNotebookBinding

class NotebookActivity : BaseActivity() {
    private lateinit var b: ActivityNotebookBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: SimpleAdapter
    private var notebookId = 0L
    private var notebookName = "دفترچه حساب"

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) PdfExporter.export(this, uri, notebookName, db.txRecords(notebookId), db.balance(notebookId))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNotebookBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", 0)
        notebookName = intent.getStringExtra("notebook_name") ?: db.notebookName(notebookId)
        b.toolbar.title = notebookName
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_notebook)
        b.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.exportPdf) {
                pdfPicker.launch("${notebookName.replace("/", "-")}.pdf")
                true
            } else false
        }

        adapter = SimpleAdapter(emptyList()) {}
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter

        b.addDebt.setOnClickListener { add("debt", "ثبت بدهکار") }
        b.addCredit.setOnClickListener { add("credit", "ثبت بستانکار") }
    }

    private fun add(kind: String, title: String) {
        promptTransaction(this, title) { amount, note ->
            db.addTx(notebookId, kind, amount, note, Jalali.now())
            refresh()
        }
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        adapter.submit(db.tx(notebookId))
        val x = db.balance(notebookId)
        b.balance.text = "${"%,d".format(kotlin.math.abs(x))} تومان ${if (x >= 0) "بستانکار" else "بدهکار"}"
        b.balance.setTextColor(getColor(if (x >= 0) R.color.credit_text else R.color.debt_text))
    }
}
