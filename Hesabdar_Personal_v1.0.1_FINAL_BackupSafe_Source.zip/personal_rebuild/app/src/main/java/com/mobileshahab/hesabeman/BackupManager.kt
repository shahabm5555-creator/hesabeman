package com.mobileshahab.hesabeman

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Durable backup layer. The SQLite journal/WAL files are never backed up. */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    const val LEGACY_NAME = "hesabdar_database"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val HISTORY_PREFIX = "hesabdar_history_"
    private const val HISTORY_LIMIT = 7

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean = try {
        val snapshot = createConsistentSnapshot(context)
        try {
            validateDatabase(snapshot)
            publish(context, snapshot)
        } finally { snapshot.delete() }
        if (!silent) Toast.makeText(context, "پشتیبان معتبر در Download/Hesabdarman ذخیره شد.", Toast.LENGTH_LONG).show()
        true
    } catch (e: Exception) {
        if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}", Toast.LENGTH_LONG).show()
        false
    }

    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return queryPublicBackups(context).firstOrNull { isValidUri(context, it) }
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman")
        return dir.listFiles()?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.firstOrNull { it.name == CANONICAL_NAME || it.name == PREVIOUS_NAME || it.name.startsWith(HISTORY_PREFIX) }
            ?.takeIf { runCatching { validateDatabase(it); true }.getOrDefault(false) }
            ?.let(Uri::fromFile)
    }

    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val candidate = File(context.cacheDir, "restore_candidate.db")
        return try {
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)
            DbHelper.closeAll()
            val target = DbHelper.databaseFile(context)
            target.parentFile?.mkdirs()
            File(target.path + "-wal").delete(); File(target.path + "-shm").delete(); File(target.path + "-journal").delete()
            val replacement = File(target.parentFile, "${target.name}.restore.tmp")
            copyFile(candidate, replacement)
            validateDatabase(replacement)
            if (target.exists() && !target.delete()) error("پایگاه داده فعلی قابل جایگزینی نیست")
            if (!replacement.renameTo(target)) {
                copyFile(candidate, target)
                replacement.delete()
            }
            validateDatabase(target)
            candidate.delete()
            true
        } catch (e: Exception) {
            candidate.delete()
            File(DbHelper.databaseFile(context).parentFile, "${DbHelper.databaseFile(context).name}.restore.tmp").delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}", Toast.LENGTH_LONG).show()
            false
        }
    }

    /** Consistent snapshot of SQLite, independent of -wal/-shm/-journal side files. */
    private fun createConsistentSnapshot(context: Context): File {
        val helper = DbHelper(context)
        val snapshot = File(context.cacheDir, "hesabdar_snapshot_${System.nanoTime()}.db")
        return try {
            val db = helper.writableDatabase
            db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            val escaped = snapshot.absolutePath.replace("'", "''")
            db.execSQL("VACUUM INTO '$escaped'")
            helper.close()
            if (!snapshot.exists() || snapshot.length() < 4096L) error("اسنپ‌شات دیتابیس ساخته نشد")
            snapshot
        } catch (e: Exception) {
            runCatching { helper.close() }; snapshot.delete(); throw e
        }
    }

    private fun publish(context: Context, source: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val primary = findMediaStoreFile(context, CANONICAL_NAME)
            if (primary != null && isValidUri(context, primary)) {
                val previous = File(context.cacheDir, "previous_${System.nanoTime()}.db")
                copyUriToFile(context.contentResolver, primary, previous)
                try {
                    validateDatabase(previous)
                    publishNewMediaFile(context, PREVIOUS_NAME, previous)
                    publishNewMediaFile(context, HISTORY_PREFIX + timestamp() + ".db", previous)
                } finally { previous.delete() }
            }
            publishNewMediaFile(context, CANONICAL_NAME, source)
            pruneHistory(context)
        } else rotateLegacy(source)
    }

    private fun publishNewMediaFile(context: Context, name: String, source: File) {
        validateDatabase(source)
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val tempName = ".${name}.${System.nanoTime()}.tmp"
        val uri = resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, tempName)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
            put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")
        try {
            resolver.openOutputStream(uri, "wt")?.use { out -> FileInputStream(source).use { it.copyTo(out) } }
                ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")
            val probe = File(context.cacheDir, "media_probe_${System.nanoTime()}.db")
            try { copyUriToFile(resolver, uri, probe); validateDatabase(probe) } finally { probe.delete() }
            // Publish the validated new item before deleting the old same-name item.
            // If publishing fails, the previous valid backup remains untouched.
            val published = resolver.update(uri, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)
            if (published != 1) error("امکان نهایی‌کردن فایل پشتیبان وجود ندارد")
            findMediaStoreFile(context, name)?.let { old ->
                // The query can return the newly published item. Delete only older
                // duplicates, keeping the newest valid item.
                val oldId = old.lastPathSegment?.toLongOrNull()
                if (oldId != uri.lastPathSegment?.toLongOrNull()) resolver.delete(old, null, null)
            }
        } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
    }

    private fun queryPublicBackups(context: Context): List<Uri> {
        val resolver = context.contentResolver; val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val rows = mutableListOf<Pair<Long, Uri>>()
        resolver.query(collection, arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_MODIFIED),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0", arrayOf(RELATIVE_PATH),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID); val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME); val date = c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
            while (c.moveToNext()) if (c.getString(name) == CANONICAL_NAME || c.getString(name) == PREVIOUS_NAME || c.getString(name).startsWith(HISTORY_PREFIX))
                rows += c.getLong(date) to Uri.withAppendedPath(collection, c.getLong(id).toString())
        }
        return rows.sortedByDescending { it.first }.map { it.second }
    }

    private fun pruneHistory(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver; val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val rows = mutableListOf<Pair<Long, Uri>>()
        resolver.query(collection, arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_MODIFIED),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0", arrayOf(RELATIVE_PATH),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID); val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME); val date = c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
            while (c.moveToNext()) if (c.getString(name).startsWith(HISTORY_PREFIX)) rows += c.getLong(date) to Uri.withAppendedPath(collection, c.getLong(id).toString())
        }
        rows.sortedByDescending { it.first }.drop(HISTORY_LIMIT).forEach { resolver.delete(it.second, null, null) }
    }

    private fun findMediaStoreFile(context: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver; val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        resolver.query(collection, arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0", arrayOf(RELATIVE_PATH, name),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC")?.use { c -> if (c.moveToFirst()) return Uri.withAppendedPath(collection, c.getLong(0).toString()) }
        return null
    }

    private fun rotateLegacy(source: File) {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman")
        if (!dir.exists() && !dir.mkdirs()) error("پوشه پشتیبان قابل ساخت نیست")
        val primary = File(dir, CANONICAL_NAME); val previous = File(dir, PREVIOUS_NAME)
        if (primary.exists() && runCatching { validateDatabase(primary); true }.getOrDefault(false)) {
            primary.copyTo(previous, overwrite = true); primary.copyTo(File(dir, HISTORY_PREFIX + timestamp() + ".db"), overwrite = false)
        }
        source.copyTo(primary, overwrite = true); source.copyTo(File(dir, LEGACY_NAME), overwrite = true)
        dir.listFiles()?.filter { it.name.startsWith(HISTORY_PREFIX) }?.sortedByDescending { it.lastModified() }?.drop(HISTORY_LIMIT)?.forEach { it.delete() }
    }

    private fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        resolver.openInputStream(uri)?.use { input -> FileOutputStream(target, false).use { input.copyTo(it) } } ?: error("فایل قابل خواندن نیست")
    }
    private fun copyFile(source: File, target: File) { target.parentFile?.mkdirs(); FileInputStream(source).use { i -> FileOutputStream(target, false).use { i.copyTo(it) } } }
    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val probe = File(context.cacheDir, "probe_${System.nanoTime()}.db")
        return try {
            copyUriToFile(context.contentResolver, uri, probe)
            validateDatabase(probe)
            true
        } catch (_: Exception) {
            false
        } finally {
            probe.delete()
        }
    }
    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf("folders", "notebooks", "tx", "invoices", "invoice_items", "installment_plans", "installment_items", "checks")
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c -> while (c.moveToNext()) found += c.getString(0) }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")
            val ok = db.rawQuery("PRAGMA integrity_check", null).use { c -> c.moveToFirst() && c.getString(0).equals("ok", true) }
            if (!ok) error("فایل پشتیبان آسیب‌دیده است")
            val version = db.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        } finally { db.close() }
    }
    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
}
