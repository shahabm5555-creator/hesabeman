package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Central data-safety layer.
 *
 * Live DB:
 *   app-private/Hesabdarman/Database/hesabdar_v22.db
 *
 * External user backup (single canonical file):
 *   Download/Hesabdarman/hesabdar_database.db
 *
 * Private recovery keeps two validated snapshots. It is used only when the live
 * DB disappears while the application is still installed. External backups are
 * never imported automatically at startup.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    private const val CANONICAL_RELATIVE_PATH = "Download/Hesabdarman/"
    private const val RECOVERY_DIR = "Hesabdarman/Recovery"
    private const val RECOVERY_LATEST = "recovery_latest.db"
    private const val RECOVERY_PREVIOUS = "recovery_previous.db"

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val appContext = context.applicationContext
            val src = checkpointAndGetDatabase(appContext)
            validateDatabase(src)
            writePrivateRecovery(appContext, src)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                writeCanonicalMediaStore(appContext, src)
            } else {
                writeCanonicalLegacy(src)
            }

            if (!silent) {
                Toast.makeText(
                    context,
                    "پشتیبان اصلی در Download/Hesabdarman/$CANONICAL_NAME ذخیره شد.",
                    Toast.LENGTH_LONG
                ).show()
            }
            true
        } catch (e: Exception) {
            if (!silent) {
                Toast.makeText(
                    context,
                    "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}",
                    Toast.LENGTH_LONG
                ).show()
            }
            false
        }
    }

    /** External automatic restore is deliberately disabled for financial-data safety. */
    @Deprecated("Automatic external restore is disabled. Use explicit Restore from Settings.")
    fun restoreCanonicalIfPresent(context: Context): Boolean = false

    fun maybeAutoBackup(context: Context) {
        if (AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) {
            backup(context, true)
        }
    }

    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val appContext = context.applicationContext
        val dbFile = DbHelper.databaseFile(appContext)
        val tmp = File(appContext.cacheDir, "restore_candidate.db.tmp")
        return try {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
            } ?: error("فایل قابل خواندن نیست")

            validateDatabase(tmp)
            dbFile.parentFile?.mkdirs()

            // Do not leave stale WAL/SHM beside a replaced main database.
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()

            val replacement = File(dbFile.parentFile, "${dbFile.name}.restore.tmp")
            replacement.delete()
            FileInputStream(tmp).use { input ->
                FileOutputStream(replacement, false).use { output -> input.copyTo(output) }
            }
            validateDatabase(replacement)

            if (!replacement.renameTo(dbFile)) {
                dbFile.delete()
                if (!replacement.renameTo(dbFile)) error("امکان جایگزینی امن پایگاه داده وجود ندارد")
            }
            tmp.delete()

            DbHelper.notifyDatabaseReplaced()
            writePrivateRecovery(appContext, dbFile)
            backup(appContext, true)
            true
        } catch (e: Exception) {
            tmp.delete()
            File(dbFile.parentFile, "${dbFile.name}.restore.tmp").delete()
            Toast.makeText(
                context,
                "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }

    private fun checkpointAndGetDatabase(context: Context): File {
        val dbFile = DbHelper.ensureDatabaseFile(context)
        val helper = DbHelper(context)
        try {
            helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
        } finally {
            helper.close()
        }
        if (!dbFile.exists() || dbFile.length() < 4096L) {
            error("پایگاه داده هنوز آماده پشتیبان‌گیری نیست")
        }
        return dbFile
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(
            file.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
        )
        try {
            val required = setOf(
                "folders", "notebooks", "tx", "invoices", "invoice_items",
                "installment_plans", "installment_items", "checks"
            )
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) found += c.getString(0)
            }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار من نیست")

            val version = db.rawQuery("PRAGMA user_version", null).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (version != DbHelper.DATABASE_VERSION) {
                error("نسخه پایگاه داده پشتیبان با نسخه ${DbHelper.DATABASE_VERSION} سازگار نیست")
            }

            val ok = db.rawQuery("PRAGMA quick_check", null).use {
                it.moveToFirst() && it.getString(0).equals("ok", true)
            }
            if (!ok) error("فایل پشتیبان آسیب‌دیده است")
        } finally {
            db.close()
        }
    }

    private fun writePrivateRecovery(context: Context, src: File) {
        val dir = File(context.filesDir, RECOVERY_DIR)
        if (!dir.exists() && !dir.mkdirs()) error("امکان ایجاد Recovery وجود ندارد")

        val latest = File(dir, RECOVERY_LATEST)
        val previous = File(dir, RECOVERY_PREVIOUS)
        val temp = File(dir, "recovery_write.tmp")

        temp.delete()
        FileInputStream(src).use { input ->
            FileOutputStream(temp, false).use { output -> input.copyTo(output) }
        }
        validateDatabase(temp)

        if (latest.exists()) {
            previous.delete()
            if (!latest.renameTo(previous)) {
                // Keeping the latest is safer than destroying it when rotation fails.
                temp.delete()
                return
            }
        }
        if (!temp.renameTo(latest)) {
            // Restore the previous snapshot if rotation was already performed.
            if (!latest.exists() && previous.exists()) previous.renameTo(latest)
            temp.delete()
            error("امکان ثبت Recovery وجود ندارد")
        }

        // Never keep an invalid recovery copy.
        if (!isValidRecovery(latest)) error("Recovery پس از ذخیره معتبر نیست")
    }

    private fun isValidRecovery(file: File): Boolean = runCatching {
        validateDatabase(file)
        true
    }.getOrDefault(false)

    private fun findCanonical(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            resolver.query(
                collection,
                arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
                arrayOf(CANONICAL_NAME, CANONICAL_RELATIVE_PATH),
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                if (c.moveToFirst()) return Uri.withAppendedPath(collection, c.getLong(0).toString())
            }
            return null
        }
        val file = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "Hesabdarman/$CANONICAL_NAME"
        )
        return if (file.exists()) Uri.fromFile(file) else null
    }

    private fun writeCanonicalMediaStore(context: Context, src: File) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        cleanupDuplicateCanonicalEntries(context)

        // Write a temporary pending item first so an interrupted write never becomes
        // a visible backup. Only after validation do we replace the canonical item.
        val tempName = "${CANONICAL_NAME}.tmp"
        val tempUri = resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, tempName)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
            put(MediaStore.Downloads.RELATIVE_PATH, CANONICAL_RELATIVE_PATH)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }) ?: error("امکان ایجاد فایل موقت پشتیبان وجود ندارد")

        try {
            resolver.openOutputStream(tempUri, "wt")?.use { out ->
                FileInputStream(src).use { input -> input.copyTo(out) }
            } ?: error("امکان نوشتن فایل موقت پشتیبان وجود ندارد")

            resolver.update(tempUri, ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)

            val old = findCanonical(context)
            if (old != null) resolver.delete(old, null, null)

            resolver.update(tempUri, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, CANONICAL_NAME)
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)
        } catch (e: Exception) {
            resolver.delete(tempUri, null, null)
            throw e
        }
        cleanupDuplicateCanonicalEntries(context)
    }

    private fun cleanupDuplicateCanonicalEntries(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val rows = mutableListOf<Triple<Long, String, Int>>()
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
            arrayOf(CANONICAL_RELATIVE_PATH, "$CANONICAL_NAME%"),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            while (c.moveToNext()) rows += Triple(c.getLong(0), c.getString(1), c.getInt(2))
        }

        var keptExact = false
        for ((id, name, pending) in rows) {
            val uri = Uri.withAppendedPath(collection, id.toString())
            val keep = name == CANONICAL_NAME && pending == 0 && !keptExact
            if (keep) keptExact = true else resolver.delete(uri, null, null)
        }
    }

    private fun writeCanonicalLegacy(src: File) {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "Hesabdarman"
        )
        if (!dir.exists() && !dir.mkdirs()) error("امکان ایجاد پوشه پشتیبان وجود ندارد")
        dir.listFiles()?.filter { it.name.startsWith(CANONICAL_NAME) && it.name != CANONICAL_NAME }
            ?.forEach { it.delete() }

        val target = File(dir, CANONICAL_NAME)
        val tmp = File(dir, "$CANONICAL_NAME.tmp")
        FileInputStream(src).use { input ->
            FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
        }
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) error("امکان ثبت فایل پشتیبان وجود ندارد")
        }
    }
}
