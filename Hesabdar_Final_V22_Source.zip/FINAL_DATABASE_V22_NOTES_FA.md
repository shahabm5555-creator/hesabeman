# حسابدار من — Final V22 Database Safety

## مسیر دیتابیس زنده
`Internal app storage/Hesabdarman/Database/hesabdar_v22.db`

این فایل دیتابیس اصلی است و در حافظه خصوصی برنامه قرار دارد. برنامه به READ/WRITE_EXTERNAL_STORAGE برای کار روزمره دیتابیس نیاز ندارد.

## بازیابی داخلی در صورت حذف تصادفی فایل DB
برنامه دو Snapshot معتبر خصوصی نگه می‌دارد:

- `Internal app storage/Hesabdarman/Recovery/recovery_latest.db`
- `Internal app storage/Hesabdarman/Recovery/recovery_previous.db`

اگر `hesabdar_v22.db` حذف شود و برنامه هنوز نصب باشد، قبل از ساخت دیتابیس خالی، Snapshot معتبر بازیابی می‌شود.

## پشتیبان خارجی
فقط یک فایل اصلی ساخته می‌شود:

`Download/Hesabdarman/hesabdar_database.db`

در Android 10 و بالاتر از MediaStore استفاده می‌شود و نیازی به مجوز ذخیره‌سازی عمومی برای نسخه‌های جدید Android ندارد.

## Restore
بازیابی خارجی فقط با اقدام صریح کاربر از Settings انجام می‌شود. فایل قبل از Restore با موارد زیر بررسی می‌شود:

- جدول‌های اصلی برنامه
- `PRAGMA user_version` و تطبیق دقیق با V22
- `PRAGMA quick_check`
- حداقل اندازه فایل

پس از تأیید، فایل ابتدا به‌صورت موقت آماده و دوباره اعتبارسنجی می‌شود و سپس جایگزین دیتابیس زنده می‌گردد.

## سطل زباله
سطل زباله ۵ روزه حذف نشده است. حذف حساب، تراکنش، چک، فاکتور و اقساط همچنان Soft Delete است و پس از ۵ روز پاک‌سازی دائمی می‌شود.

## جلوگیری از Restore قدیمی Android
`android:allowBackup="false"` فعال شده تا Android نتواند دیتابیس قدیمی برنامه را خارج از سیستم Backup/Restore اختصاصی این نسخه به‌صورت خودکار برگرداند.

## نکته مهم
دیتابیس زنده منبع اصلی اطلاعات است. Backup خارجی برای انتقال/بازیابی و Recovery خصوصی برای محافظت در برابر حذف یا خرابی فایل دیتابیس در زمان نصب بودن برنامه است.
