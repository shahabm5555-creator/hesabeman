package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CheckActivity : AppCompatActivity() {
    private lateinit var db: DbHelper
    private var notebookId = -1L
    private var notebookName = "حساب"
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1L)
        notebookName = intent.getStringExtra("notebook_name") ?: "حساب"
        buildUi()
        load()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; setBackgroundColor(color(R.color.background)) }
        val toolbar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(color(R.color.surface)); layoutParams=LinearLayout.LayoutParams(-1, dp(60)) }
        toolbar.addView(closeButton(this,22f,color(R.color.text),44){finish()})
        toolbar.addView(TextView(this).apply { text="چک‌های $notebookName"; textSize=15f; gravity=Gravity.CENTER; setTypeface(typeface,android.graphics.Typeface.BOLD); setTextColor(color(R.color.text)); layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        toolbar.addView(Space(this), LinearLayout.LayoutParams(dp(52),dp(52)))
        root.addView(toolbar)
        val scroll=ScrollView(this)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(18))}
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(10))
            addView(MaterialButton(this@CheckActivity).apply {
                text = "صدور چک"; textSize = 14f; cornerRadius = dp(15); insetTop = 0; insetBottom = 0
                backgroundTintList = ColorStateList.valueOf(color(R.color.primary)); setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(-1, dp(52))
                setOnClickListener { showCheckDialog(null) }
            })
        })
        setContentView(root)
    }

    private fun load() {
        list.removeAllViews()
        val checks=db.checks(notebookId)
        if(checks.isEmpty()) { list.addView(TextView(this).apply{text="هنوز چکی ثبت نشده است";textSize=14f;gravity=Gravity.CENTER;setTextColor(color(R.color.secondary));setPadding(0,dp(50),0,0)});return }
        checks.forEach{list.addView(buildCard(it))}
    }

    private fun buildCard(x: CheckRecord): View {
        val card=MaterialCardView(this).apply{radius=dp(18).toFloat();cardElevation=dp(1).toFloat();setCardBackgroundColor(color(R.color.surface));strokeWidth=dp(1);strokeColor=color(R.color.divider);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text=if(x.kind=="debt")"چک پرداختی" else "چک دریافتی";textSize=13f;setTextColor(color(if(x.kind=="debt")R.color.debt_text else R.color.credit_text));setTypeface(typeface,android.graphics.Typeface.BOLD);layoutParams=LinearLayout.LayoutParams(0,-2,1f)})
        top.addView(TextView(this).apply{text="${format(x.amount)} تومان";textSize=14f;setTextColor(color(R.color.primary));setTypeface(typeface,android.graphics.Typeface.BOLD)})
        box.addView(top)
        box.addView(line("صاحب حساب",x.accountHolder,"بانک",x.bankName))
        box.addView(line("تاریخ دریافت",x.receivedDate,"سررسید",x.dueDate))
        box.addView(line("شماره چک",x.checkNumber.ifBlank{"—"},"شناسه ۱۶ رقمی",x.checkId16))
        if(x.note.isNotBlank()) box.addView(TextView(this).apply{text="توضیحات: ${x.note}";textSize=11f;setTextColor(color(R.color.secondary));setPadding(0,dp(6),0,dp(2));gravity=Gravity.RIGHT})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_LTR;gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)}}
        actions.addView(MaterialButton(this).apply{text="ویرایش";textSize=10.5f;cornerRadius=dp(11);insetTop=0;insetBottom=0;backgroundTintList=ColorStateList.valueOf(color(R.color.primary_soft));setTextColor(color(R.color.primary));layoutParams=LinearLayout.LayoutParams(0,dp(38),1f).apply{marginEnd=dp(4)};setOnClickListener{showCheckDialog(x)}})
        actions.addView(MaterialButton(this).apply{text="حذف";textSize=10.5f;cornerRadius=dp(11);insetTop=0;insetBottom=0;backgroundTintList=ColorStateList.valueOf(color(R.color.debt_soft));setTextColor(color(R.color.debt_text));layoutParams=LinearLayout.LayoutParams(0,dp(38),1f);setOnClickListener{confirmDelete(x)}})
        box.addView(actions); card.addView(box); return card
    }

    private fun line(l1:String,v1:String,l2:String,v2:String)=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4)}
        addView(TextView(this@CheckActivity).apply{text="$l1: $v1";textSize=10.5f;setTextColor(color(R.color.text));gravity=Gravity.RIGHT;layoutParams=LinearLayout.LayoutParams(0,-2,1f)})
        addView(TextView(this@CheckActivity).apply{text="$l2: $v2";textSize=10.5f;setTextColor(color(R.color.text));gravity=Gravity.RIGHT;layoutParams=LinearLayout.LayoutParams(0,-2,1f)})
    }

    private fun showCheckDialog(old: CheckRecord?) {
        var receivedDate=old?.receivedDate ?: Jalali.now().substringBefore(" - ")
        var dueDate=old?.dueDate ?: Jalali.addDays(receivedDate,30)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(16),dp(4),dp(16),dp(2))}
        val kind=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val paid=RadioButton(this).apply{id=View.generateViewId();text="پرداخت چک";layoutParams=RadioGroup.LayoutParams(0,-2,1f)}
        val got=RadioButton(this).apply{id=View.generateViewId();text="دریافت چک";layoutParams=RadioGroup.LayoutParams(0,-2,1f)}
        kind.addView(got);kind.addView(paid);kind.check(if(old?.kind=="debt")paid.id else got.id)
        box.addView(TextView(this).apply{text="نوع چک";textSize=11f;setTextColor(color(R.color.secondary));setPadding(0,0,0,dp(2))});box.addView(kind)
        fun f(h:String,v:String="",numeric:Boolean=false):EditText=EditText(this).apply{
            hint=h;setText(v);textSize=13f;inputType=if(numeric)InputType.TYPE_CLASS_PHONE else InputType.TYPE_CLASS_TEXT
            if(numeric){gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL;textDirection=View.TEXT_DIRECTION_LTR;textAlignment=View.TEXT_ALIGNMENT_GRAVITY}else{gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;textDirection=View.TEXT_DIRECTION_RTL;textAlignment=View.TEXT_ALIGNMENT_GRAVITY}
            background=ContextCompat.getDrawable(this@CheckActivity,R.drawable.bg_search_field);setTextColor(color(R.color.text));setHintTextColor(color(R.color.secondary));setPadding(dp(14),dp(10),dp(14),dp(10));layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(6)}
        }
        val amount=f("مبلغ چک به تومان",old?.amount?.let{group(it.toString())} ?: "",true);amount.addTextChangedListener(moneyWatcher());box.addView(amount)
        val holder=f("نام صاحب حساب چک",old?.accountHolder.orEmpty());box.addView(holder)
        val bank=f("نام بانک",old?.bankName.orEmpty());box.addView(bank)
        val number=f("شماره چک",old?.checkNumber.orEmpty(),true);box.addView(number)
        val id16=f("شناسه ۱۶ رقمی چک",old?.checkId16.orEmpty(),true);id16.filters=arrayOf(android.text.InputFilter.LengthFilter(16));box.addView(id16)
        val dates=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)}}
        val receivedLabel=TextView(this).apply{text="تاریخ دریافت: $receivedDate";textSize=11f;setTextColor(color(R.color.text));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(0,dp(42),1f)}
        val dueLabel=TextView(this).apply{text="سررسید: $dueDate";textSize=11f;setTextColor(color(R.color.text));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(0,dp(42),1f)}
        dates.addView(MaterialButton(this).apply{text="تاریخ دریافت";textSize=9.5f;cornerRadius=dp(10);insetTop=0;insetBottom=0;backgroundTintList=ColorStateList.valueOf(color(R.color.primary_soft));setTextColor(color(R.color.primary));setOnClickListener{promptJalaliDate(this@CheckActivity,receivedDate,"انتخاب تاریخ دریافت"){d->receivedDate=d;receivedLabel.text="تاریخ دریافت: $d"}}})
        dates.addView(receivedLabel);dates.addView(MaterialButton(this).apply{text="سررسید";textSize=9.5f;cornerRadius=dp(10);insetTop=0;insetBottom=0;backgroundTintList=ColorStateList.valueOf(color(R.color.primary_soft));setTextColor(color(R.color.primary));setOnClickListener{promptJalaliDate(this@CheckActivity,dueDate,"انتخاب تاریخ سررسید"){d->dueDate=d;dueLabel.text="سررسید: $d"}}});dates.addView(dueLabel)
        box.addView(dates)
        val note=f("توضیحات",old?.note.orEmpty());box.addView(note)
        MaterialAlertDialogBuilder(this).setTitle(if(old==null)"ثبت چک" else "ویرایش چک").setView(box)
            .setPositiveButton(if(old==null)"ثبت چک" else "ذخیره") { _, _ ->
                val amountValue=normalizeDigits(amount.text.toString()).filter(Char::isDigit).toLongOrNull()?:0L
                val digits=normalizeDigits(id16.text.toString()).filter(Char::isDigit)
                val k=if(kind.checkedRadioButtonId==paid.id)"debt" else "credit"
                if(old==null){if(db.createCheck(notebookId,k,receivedDate,amountValue,holder.text.toString(),bank.text.toString(),dueDate,number.text.toString(),digits,note.text.toString())>0)load() else toast("اطلاعات چک را کامل و صحیح وارد کنید")}
                else if(db.updateCheck(old.id,notebookId,k,receivedDate,amountValue,holder.text.toString(),bank.text.toString(),dueDate,number.text.toString(),digits,note.text.toString(),old.txId))load() else toast("اطلاعات چک را کامل و صحیح وارد کنید")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun confirmDelete(x:CheckRecord){MaterialAlertDialogBuilder(this).setTitle("حذف چک").setMessage("این چک و تراکنش مربوط به آن حذف شود؟").setPositiveButton("حذف"){_,_->if(db.deleteCheck(x.id))load()}.setNegativeButton("انصراف",null).show()}
    private fun moneyWatcher()=object:TextWatcher{var busy=false;override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val d=e?.toString().orEmpty().map{when(it){in '۰'..'۹'->('0'.code+(it.code-'۰'.code)).toChar();in '٠'..'٩'->('0'.code+(it.code-'٠'.code)).toChar();else->it}}.joinToString("").filter(Char::isDigit).trimStart('0');val f=if(d.isEmpty())"" else group(d);if(e?.toString()!=f){busy=true;e?.replace(0,e.length,f);busy=false}}}
    private fun group(v:String):String{val d=v.filter(Char::isDigit).trimStart('0');if(d.isEmpty())return "";return d.reversed().chunked(3).joinToString(",").reversed()}
    private fun normalizeDigits(v:String)=v.map{when(it){in '۰'..'۹'->('0'.code+(it.code-'۰'.code)).toChar();in '٠'..'٩'->('0'.code+(it.code-'٠'.code)).toChar();else->it}}.joinToString("")
    private fun format(v:Long)="%,d".format(v)
    private fun color(id:Int)=ContextCompat.getColor(this,id)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
