package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import android.database.sqlite.SQLiteDatabase

/** Safe, explicit backup/restore manager. The live database never lives in public storage. */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val APP_ID = "hesabdar_personal"

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val src = DbHelper.databaseFile(context)
            if (!src.exists()) {
                DbHelper(context).writableDatabase.close()
            }
            if (!src.exists()) error("پایگاه داده هنوز ساخته نشده است")
            checkpoint(context)
            if (!validateDatabase(src)) error("پایگاه داده فعلی سالم نیست")
            DatabaseManager.createRecoverySnapshot(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) writeMediaStore(context, src) else writeLegacy(src)
            if (!silent) Toast.makeText(context, "پشتیبان در Download/Hesabdarman/$CANONICAL_NAME ذخیره شد.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message ?: "نامشخص"}", Toast.LENGTH_LONG).show()
            false
        }
    }

    /** Called automatically when an app screen stops. Never restores automatically. */
    fun autoBackupIfEnabled(context: Context) {
        if (AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) backup(context, true)
    }

    fun restore(context: Context, uri: Uri): Boolean {
        val tmp = File(context.cacheDir, "restore_candidate_${System.currentTimeMillis()}.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
            } ?: error("فایل قابل خواندن نیست")
            if (!validateDatabase(tmp)) error("این فایل یک پشتیبان معتبر حسابدار شخصی نیست")

            DbHelper.closeAll()
            val target = DbHelper.databaseFile(context)
            target.parentFile?.mkdirs()
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            val candidate = File(target.parentFile, "restore_candidate_live.tmp")
            copy(tmp, candidate)
            if (!validateDatabase(candidate)) error("فایل بازیابی پس از کپی معتبر نیست")
            if (target.exists() && !target.delete()) error("دیتابیس فعلی بسته نشد")
            if (!candidate.renameTo(target)) {
                copy(candidate, target)
                candidate.delete()
            }
            if (!validateDatabase(target)) error("دیتابیس بازیابی‌شده سالم نیست")
            tmp.delete()
            // Refresh private recovery and canonical external backup.
            DatabaseManager.createRecoverySnapshot(context)
            backup(context, true)
            true
        } catch (e: Exception) {
            tmp.delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message ?: "فایل نامعتبر است"}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun checkpoint(context: Context) {
        val helper = DbHelper(context)
        try { helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { } }
        finally { helper.close() }
    }

    private fun validateDatabase(file: File): Boolean {
        if (!file.exists() || file.length() < 4096L) return false
        return try {
            val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val quick = db.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0).equals("ok", true) }
                if (!quick) return false
                val version = db.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
                if (version > DbHelper.DATABASE_VERSION) return false
                // Validate the complete V1 schema rather than a filename or old-version marker.
                val required = setOf("folders","notebooks","tx","invoices","invoice_items","installment_plans","installment_items","checks")
                val found = mutableSetOf<String>()
                db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'", null).use { while (it.moveToNext()) found += it.getString(0) }
                found.containsAll(required)
            } finally { db.close() }
        } catch (_: Exception) { false }
    }

    private fun writeMediaStore(context: Context, src: File) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val uri = findCanonical(context) ?: resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, CANONICAL_NAME)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
            put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")
        try {
            resolver.openOutputStream(uri, "wt")?.use { out -> FileInputStream(src).use { it.copyTo(out) } }
                ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        cleanupDuplicates(context)
    }

    private fun findCanonical(context: Context): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        val c = resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(CANONICAL_NAME, RELATIVE_PATH), "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")
        c?.use { if (it.moveToFirst()) return Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, it.getLong(0).toString()) }
        return null
    }

    private fun cleanupDuplicates(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val c = resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
            arrayOf(RELATIVE_PATH, "$CANONICAL_NAME%"), null)
        val rows = mutableListOf<Pair<Long,String>>()
        c?.use { while (it.moveToNext()) rows += it.getLong(0) to it.getString(1) }
        var kept = false
        for ((id,name) in rows) {
            val uri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.toString())
            if (name == CANONICAL_NAME && !kept) kept = true else resolver.delete(uri, null, null)
        }
    }

    private fun writeLegacy(src: File) {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman")
        if (!dir.exists()) dir.mkdirs()
        File(dir, CANONICAL_NAME).outputStream().use { out -> FileInputStream(src).use { it.copyTo(out) } }
    }

    private fun copy(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input -> FileOutputStream(target, false).use { output -> input.copyTo(output) } }
    }
}
