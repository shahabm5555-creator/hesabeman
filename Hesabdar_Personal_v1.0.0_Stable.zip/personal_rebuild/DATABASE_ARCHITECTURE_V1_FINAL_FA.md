# معماری نهایی دیتابیس حسابدار شخصی V1

- دیتابیس زنده در Android private storage است: `personal_hesabdar.db`.
- Backup کاربر در `Download/Hesabdarman/hesabdar_database.db` ذخیره می‌شود.
- برنامه در Startup هیچ Backup خارجی را خودکار Restore نمی‌کند.
- با توقف Activity، اگر Auto Backup روشن باشد، Backup امن ایجاد/به‌روزرسانی می‌شود.
- Restore ابتدا فایل را در cache بررسی می‌کند و با `PRAGMA quick_check` و schema کامل V1 اعتبارسنجی می‌کند.
- سطل بازیافت ۵ روزه حفظ شده است.
