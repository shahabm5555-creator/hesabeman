package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.Gravity
import android.graphics.Color
import android.content.res.ColorStateList
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter
    private var dueShown = false
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable { override fun run() { updateClock(); clockHandler.postDelayed(this, 1000L) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        db = DbHelper(this)

        b.digitalClock.typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)

        adapter = FolderGridAdapter(
            emptyList(),
            onClick = { startActivity(Intent(this, FolderActivity::class.java).putExtra("folder_id", it.id).putExtra("folder_name", it.name)) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.list.adapter = adapter

        b.add.setOnClickListener { createFolder() }
        b.menuButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.searchButton.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.createUserCard.setOnClickListener { createUser() }

        b.invoiceQuick.setOnClickListener { chooseNotebook("فاکتور جدید") { openInvoice(it) } }
        b.installmentQuick.setOnClickListener { chooseNotebook("ثبت قسط") { openInstallment(it) } }
        b.paymentQuick.setOnClickListener { chooseNotebook("پرداخت به حساب") { addTransaction(it, "debt", "پرداخت به حساب") } }
        b.receiveQuick.setOnClickListener { chooseNotebook("دریافت از حساب") { addTransaction(it, "credit", "دریافت از حساب") } }

        b.checkCard.setOnClickListener { showDateWindowDialog("چک‌های سررسید", db.upcomingChecksInWindow()) }
        b.installmentCard.setOnClickListener { showDateWindowDialog("اقساط سررسید", db.upcomingInstallmentsInWindow()) }
        b.debtorCard.setOnClickListener { showPeopleDialog(true) }
        b.creditorCard.setOnClickListener { showPeopleDialog(false) }
        b.debtorLink.setOnClickListener { showPeopleDialog(true) }
        b.creditorLink.setOnClickListener { showPeopleDialog(false) }
        b.recentAll.setOnClickListener { showRecentDialog() }
    }

    private fun createFolder() {
        if (db.countFolders(null) >= DbHelper.MAX_FOLDERS) {
            Toast.makeText(this, "حداکثر ۳۰ پوشه مجاز است.", Toast.LENGTH_LONG).show()
            return
        }
        promptText(this, "پوشه جدید", "نام پوشه") { name -> if (db.addFolder(null, name)) refresh() }
    }

    private fun createUser() {
        val folders = db.folderItems()
        if (folders.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("ابتدا یک پوشه بسازید")
                .setMessage("برای ساخت کاربر، ابتدا حداقل یک پوشه مانند مشتری یا همکار ایجاد کنید.")
                .setPositiveButton("ساخت پوشه") { _, _ -> createFolder() }
                .setNegativeButton("انصراف", null)
                .show()
            return
        }
        val names = folders.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("انتخاب پوشه کاربر")
            .setItems(names) { _, which ->
                val folder = folders[which]
                promptNotebook(this) { name, phone ->
                    if (db.addNotebook(folder.id, name, phone)) Toast.makeText(this, "کاربر «$name» در پوشه ${folder.name} ساخته شد.", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "ساخت کاربر انجام نشد؛ ظرفیت پوشه را بررسی کنید.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun chooseNotebook(action: String, done: (NotebookListItem) -> Unit) {
        val users = db.allNotebooks()
        if (users.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("کاربری وجود ندارد")
                .setMessage("برای $action ابتدا یک کاربر بسازید.")
                .setPositiveButton("ایجاد کاربر") { _, _ -> createUser() }
                .setNegativeButton("انصراف", null)
                .show()
            return
        }
        val labels = users.map { it.name + if (it.phone.isBlank()) "" else " — ${it.phone}" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("انتخاب کاربر برای $action")
            .setItems(labels) { _, which -> done(users[which]) }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun openInvoice(user: NotebookListItem) {
        val info = db.notebookInfo(user.id)
        startActivity(Intent(this, InvoiceActivity::class.java).apply {
            putExtra("notebook_id", user.id); putExtra("notebook_name", user.name); putExtra("notebook_phone", info.phone)
        })
    }

    private fun openInstallment(user: NotebookListItem) {
        startActivity(Intent(this, InstallmentActivity::class.java).apply {
            putExtra("notebook_id", user.id); putExtra("notebook_name", user.name)
        })
    }

    private fun addTransaction(user: NotebookListItem, kind: String, title: String) {
        promptTransaction(this, title, kind) { selectedKind, amount, note, dateTime ->
            if (db.addTx(user.id, selectedKind, amount, note, dateTime) > 0L) refresh()
            else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ", "تغییر ردیف", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
                2 -> changeFolderRow(item)
                3 -> MaterialAlertDialogBuilder(this)
                    .setTitle("حذف پوشه")
                    .setMessage("پوشه و حساب‌های داخل آن تا ۵ روز در سطل زباله قابل بازیابی هستند.")
                    .setPositiveButton("حذف") { _, _ -> db.trashFolder(item.id); refresh() }
                    .setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        val names = arrayOf("سبز ملایم", "آبی ملایم", "کرم", "بنفش ملایم", "صورتی ملایم", "خاکستری روشن")
        val colors = arrayOf("#B8DEC8", "#B9D7EA", "#E7D7AE", "#D8C5E7", "#E8BCC9", "#C8D1D3")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which ->
            db.setFolderColor(item.id, colors[which]); refresh()
        }.show()
    }

    private fun changeFolderRow(item: FolderItem) {
        val max = db.countFolders(null).coerceAtLeast(1)
        promptOrder(this, "تغییر ردیف پوشه", item.sortOrder, max) { newRow ->
            db.setFolderOrder(item.id, newRow)
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        db.purgeExpiredTrash()
        refresh()
        updateClock()
        clockHandler.removeCallbacks(clockTick)
        clockHandler.post(clockTick)
        if (!dueShown) { dueShown = true; showDueReminder() }
    }

    override fun onPause() {
        clockHandler.removeCallbacks(clockTick)
        super.onPause()
    }

    private fun updateClock() {
        val now = java.util.Calendar.getInstance()
        b.digitalClock.text = String.format(java.util.Locale.US, "%02d:%02d:%02d", now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), now.get(java.util.Calendar.SECOND))
        val jalali = Jalali.now()
        b.jalaliToday.text = jalali.substringBefore(" - ")
        b.todayWeekday.text = when (now.get(java.util.Calendar.DAY_OF_WEEK)) {
            java.util.Calendar.SATURDAY -> "شنبه"
            java.util.Calendar.SUNDAY -> "یکشنبه"
            java.util.Calendar.MONDAY -> "دوشنبه"
            java.util.Calendar.TUESDAY -> "سه‌شنبه"
            java.util.Calendar.WEDNESDAY -> "چهارشنبه"
            java.util.Calendar.THURSDAY -> "پنجشنبه"
            else -> "جمعه"
        }
        b.gregorianToday.text = String.format(java.util.Locale.US, "%04d/%02d/%02d", now.get(java.util.Calendar.YEAR), now.get(java.util.Calendar.MONTH) + 1, now.get(java.util.Calendar.DAY_OF_MONTH))
    }

    private fun showDueReminder() {
        val today = Jalali.now().substringBefore(" - ")
        val due = db.dueNotebooks(today)
        if (due.isEmpty()) return
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val checks = mutableMapOf<Long, android.widget.CheckBox>()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        due.forEachIndexed { idx, n ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(12), dp(10), dp(12), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.rgb(255, 248, 235))
                    cornerRadius = dp(12).toFloat()
                }
            }
            row.addView(android.widget.TextView(this).apply {
                text = "${n.name} — ${"%,d".format(kotlin.math.abs(n.balance))} تومان\nسررسید: ${n.dueDate}"
                textSize = 13f; setTextColor(android.graphics.Color.rgb(42, 49, 47))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            val check = android.widget.CheckBox(this).apply {
                text = "دیگر برای سررسید همین تاریخ این حساب نمایش نده"
                textSize = 11f; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(2), dp(6), dp(2), 0)
            }
            checks[n.id] = check
            row.addView(check)
            box.addView(row)
            if (idx != due.lastIndex) box.addView(android.widget.Space(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(-1, dp(8))
            })
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(box)
            layoutParams = android.view.ViewGroup.LayoutParams(-1, if (due.size > 4) dp(360) else android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("یادآوری سررسید بدهی (${due.size} حساب)")
            .setView(scroll)
            .setPositiveButton("بررسی شد") { _, _ ->
                checks.forEach { (id, cb) -> if (cb.isChecked) db.ackDueReminder(id) }
            }.show()
    }

    private fun refresh() {
        val items = db.folderItems()
        adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val s = db.accountSummary()
        b.debtorCount.text = "${s.debtors} نفر"
        b.creditorCount.text = "${s.creditors} نفر"
        b.checkCount.text = "${db.pendingCheckCount()} چک"
        b.installmentCount.text = "${db.upcomingInstallmentCount()} قسط"
        renderRecent()
    }

    private fun renderRecent() {
        b.recentContainer.removeAllViews()
        val items = db.recentTransactions(4)
        b.recentEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEachIndexed { index, item ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(4), dp(8), dp(4), dp(8))
                isClickable = true
                setOnClickListener { openUser(item.notebookId) }
            }
            val icon = android.widget.ImageView(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(dp(36), dp(36))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setImageResource(when (item.kind) {
                    "credit" -> R.drawable.ic_receive
                    else -> if (item.sourceType == "invoice") R.drawable.ic_invoice else if (item.sourceType == "installment") R.drawable.ic_installment_percent_circle else R.drawable.ic_payment
                })
                imageTintList = ColorStateList.valueOf(color(when (item.kind) {
                    "credit" -> R.color.credit_text
                    else -> when (item.sourceType) { "invoice" -> R.color.orange; "installment" -> R.color.purple; else -> R.color.debt_text }
                }))
            }
            val center = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                layoutParams = android.widget.LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(dp(8), 0, dp(8), 0)
            }
            val title = android.widget.TextView(this).apply {
                text = when (item.sourceType) { "invoice" -> "ثبت فاکتور"; "installment" -> "ثبت قسط"; else -> if (item.kind == "credit") "دریافت از حساب" else "پرداخت به حساب" }
                textSize = 12.5f; setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.RIGHT
            }
            val sub = android.widget.TextView(this).apply {
                text = item.notebookName; textSize = 9.5f; setTextColor(color(R.color.secondary)); gravity = Gravity.RIGHT
            }
            center.addView(title); center.addView(sub)
            val amount = android.widget.TextView(this).apply {
                text = (if (item.kind == "credit") "+" else "-") + formatMoney(item.amount)
                textSize = 13f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(color(if (item.kind == "credit") R.color.credit_text else R.color.debt_text)); gravity = Gravity.LEFT
                layoutParams = android.widget.LinearLayout.LayoutParams(dp(120), -2)
            }
            row.addView(icon); row.addView(center); row.addView(amount)
            b.recentContainer.addView(row)
            if (index != items.lastIndex) b.recentContainer.addView(View(this).apply { setBackgroundColor(color(R.color.divider)); layoutParams = android.widget.LinearLayout.LayoutParams(-1, 1) })
        }
    }

    private fun openUser(notebookId: Long) { startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", notebookId)) }

    private fun showRecentDialog() {
        val items = db.recentTransactions(20)
        if (items.isEmpty()) {
            Toast.makeText(this, "هنوز فعالیتی ثبت نشده است.", Toast.LENGTH_SHORT).show(); return
        }
        val labels = items.map { item ->
            val title = when (item.sourceType) { "invoice" -> "ثبت فاکتور"; "installment" -> "ثبت قسط"; else -> if (item.kind == "credit") "دریافت از حساب" else "پرداخت به حساب" }
            "$title — ${item.notebookName} — ${if (item.kind == "credit") "+" else "-"}${formatMoney(item.amount)} تومان\n${item.createdAt}"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle("فعالیت‌های اخیر").setItems(labels) { _, which -> openUser(items[which].notebookId) }.setNegativeButton("بستن", null).show()
    }

    private fun showDateWindowDialog(title: String, items: List<String>) {
        val message = if (items.isEmpty()) "در بازه ۳ روز قبل تا ۵ روز بعد موردی وجود ندارد." else items.joinToString("\n\n")
        MaterialAlertDialogBuilder(this).setTitle(title).setMessage(message).setPositiveButton("باشه", null).show()
    }

    private fun showPeopleDialog(debtors: Boolean) {
        val users = db.allNotebooks().filter { if (debtors) it.balance < 0 else it.balance > 0 }
        val labels = users.map { "${it.name}  —  ${if (it.balance < 0) "بدهکار" else "بستانکار"}: ${formatMoney(kotlin.math.abs(it.balance))} تومان" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(if (debtors) "افراد بدهکار (${users.size})" else "افراد بستانکار (${users.size})")
            .setItems(labels) { _, which -> openUser(users[which].id) }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun formatMoney(value: Long) = "%,d".format(value)
    private fun color(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
}
