package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FolderGridAdapter(
    private var items: List<FolderItem>,
    private val onClick: (FolderItem) -> Unit,
    private val onLongClick: (FolderItem) -> Unit
) : RecyclerView.Adapter<FolderGridAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.folderCard)
        val accent: View = view.findViewById(R.id.folderAccent)
        val icon: ImageView = view.findViewById(R.id.folderIcon)
        val name: TextView = view.findViewById(R.id.folderName)
        val count: TextView = view.findViewById(R.id.folderCount)
        val order: TextView = view.findViewById(R.id.folderOrder)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder_grid, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.name.text = item.name
        holder.count.text = "${item.notebookCount} حساب"
        holder.order.text = "ردیف ${item.sortOrder}"

        val parsed = try { Color.parseColor(item.color) } catch (_: Exception) { Color.parseColor("#4C9B82") }
        val surface = ContextCompat.getColor(holder.itemView.context, R.color.surface)
        val cardColor = ColorUtils.blendARGB(parsed, surface, 0.72f)
        val border = ColorUtils.blendARGB(parsed, surface, 0.48f)
        val iconColor = ColorUtils.blendARGB(parsed, surface, 0.12f)

        holder.accent.setBackgroundColor(parsed)
        holder.card.setCardBackgroundColor(cardColor)
        holder.card.strokeColor = border
        holder.icon.imageTintList = ColorStateList.valueOf(iconColor)
        holder.name.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text))

        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size
    fun submit(newItems: List<FolderItem>) { items = newItems; notifyDataSetChanged() }
}
