# حسابدار من 2.0.1

نسخه بازطراحی‌شده رابط کاربری بر پایه هسته داده و قابلیت‌های نسخه‌های قبلی.

## قابلیت‌ها
- پوشه و حساب
- دریافت و پرداخت و ویرایش تراکنش
- مانده و گزارش حساب
- سررسید، تماس، پیامک و PDF
- جستجو، آرشیو و سطل زباله
- پشتیبان‌گیری و بازیابی
- قفل PIN و بیومتریک
- گزارش ماهانه
- رابط کاربری RTL بازطراحی‌شده

## Build
در محیطی که Android SDK و Gradle نصب است:

`gradle :app:assembleDebug`

برای GitHub Actions، workflow داخل `.github/workflows/android-debug.yml` از Gradle 8.9 و JDK 17 استفاده می‌کند.

> برای حفظ سازگاری داده، نام دیتابیس و schema اصلی برنامه حفظ شده‌اند و UI از نو طراحی شده است.


## Version 2.0.1
Visual refinement: stronger transaction borders, tighter transaction fields, aligned account name/phone header, bold black transaction text, halo FAB, gear settings icon, and equal soft-color home buttons.
