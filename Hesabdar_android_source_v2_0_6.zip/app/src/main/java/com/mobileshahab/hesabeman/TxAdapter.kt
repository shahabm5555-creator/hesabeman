package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TxAdapter(
    private var items: List<TxRecord>,
    private val onEdit: (TxRecord) -> Unit,
    private val onDelete: (TxRecord) -> Unit
) : RecyclerView.Adapter<TxAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: com.google.android.material.card.MaterialCardView = view.findViewById(R.id.txCard)
        val kind: TextView = view.findViewById(R.id.txKind)
        val amountText: TextView = view.findViewById(R.id.txAmount)
        val rowNo: TextView = view.findViewById(R.id.txRowNo)
        val note: TextView = view.findViewById(R.id.txNote)
        val date: TextView = view.findViewById(R.id.txDate)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
    )
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val x = items[position]; val isDebt = x.kind == "debt"; val ctx = holder.itemView.context
        holder.card.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_soft else R.color.credit_soft))
        holder.kind.text = if (isDebt) "↑ پرداختی" else "↓ دریافتی"
        holder.kind.setTextColor(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_text else R.color.credit_text))
        holder.kind.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_soft else R.color.credit_soft))
        holder.amountText.text = "${"%,d".format(x.amount)} تومان"
        holder.rowNo.text = "ردیف ${items.size - position}"
        holder.note.text = if (x.note.isBlank()) "بدون توضیحات" else x.note
        holder.date.text = x.createdAt.replace(" - ", "\n")
        holder.itemView.setOnClickListener { onEdit(x) }
        holder.itemView.setOnLongClickListener { onDelete(x); true }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<TxRecord>) { items = newItems; notifyDataSetChanged() }
}
