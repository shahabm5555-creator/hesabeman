package com.mobileshahab.hesabeman

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter
    private var dueShown = false
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() { updateClock(); clockHandler.postDelayed(this, 1000L) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        db = DbHelper(this)

        adapter = FolderGridAdapter(emptyList(),
            onClick = { openFolder(it) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.list.adapter = adapter

        b.add.setOnClickListener { addFolder() }
        b.createUserCard.setOnClickListener { createUser() }
        b.searchButton.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.recentMore.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }

        b.installmentSummaryCard.setOnClickListener { showDueList(db.installmentDueInRange(), "اقساط | ۳ روز قبل تا ۵ روز آینده") }
        b.checkSummaryCard.setOnClickListener { showDueList(db.checkDueInRange(), "چک‌ها | ۳ روز قبل تا ۵ روز آینده") }
        b.debtorSummaryCard.setOnClickListener { showPeople(db.peopleByBalance(true), "افراد بدهکار") }
        b.creditorSummaryCard.setOnClickListener { showPeople(db.peopleByBalance(false), "افراد بستانکار") }
    }

    private fun openFolder(item: FolderItem) {
        startActivity(Intent(this, FolderActivity::class.java).apply {
            putExtra("folder_id", item.id); putExtra("folder_name", item.name)
        })
    }

    private fun addFolder() {
        if (db.countFolders(null) >= DbHelper.MAX_FOLDERS) {
            toast("حداکثر ۳۰ پوشه مجاز است.")
            return
        }
        promptText(this, "پوشه جدید", "نام پوشه") { name ->
            if (db.addFolder(null, name)) refresh() else toast("ساخت پوشه انجام نشد")
        }
    }

    private fun createUser() {
        val folders = db.folderItems()
        if (folders.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("ساخت اولین کاربر")
                .setMessage("ابتدا یک پوشه بسازید تا کاربر داخل آن قرار بگیرد.")
                .setPositiveButton("ساخت پوشه") { _, _ -> addFolder() }
                .setNegativeButton("انصراف", null).show()
            return
        }
        promptNotebook(this) { name, phone ->
            val labels = folders.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(this)
                .setTitle("انتخاب پوشه برای $name")
                .setItems(labels) { _, which ->
                    if (db.addNotebook(folders[which].id, name, phone)) {
                        refresh()
                        toast("کاربر «$name» ساخته شد")
                    } else toast("ساخت کاربر انجام نشد")
                }
                .setNegativeButton("انصراف", null).show()
        }
    }

    private fun chooseUserAndRun(action: String, run: (Long, String) -> Unit) {
        val users = db.activeNotebooks()
        if (users.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle(action)
                .setMessage("هنوز کاربری ثبت نشده است. ابتدا یک کاربر جدید بسازید.")
                .setPositiveButton("ایجاد کاربر") { _, _ -> createUser() }
                .setNegativeButton("انصراف", null).show()
            return
        }
        val labels = users.map { "${it.name}  •  ${if (it.phone.isBlank()) "حساب" else it.phone}" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("انتخاب کاربر برای $action")
            .setItems(labels) { _, which -> run(users[which].id, users[which].name) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ", "تغییر ردیف", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
                2 -> changeFolderRow(item)
                3 -> MaterialAlertDialogBuilder(this)
                    .setTitle("حذف پوشه")
                    .setMessage("پوشه و حساب‌های داخل آن تا ۵ روز در سطل زباله قابل بازیابی هستند.")
                    .setPositiveButton("حذف") { _, _ -> db.trashFolder(item.id); refresh() }
                    .setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        val names = arrayOf("سبز ملایم", "آبی ملایم", "کرم", "بنفش ملایم", "صورتی ملایم", "خاکستری روشن")
        val colors = arrayOf("#B8DEC8", "#B9D7EA", "#E7D7AE", "#D8C5E7", "#E8BCC9", "#C8D1D3")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which ->
            db.setFolderColor(item.id, colors[which]); refresh()
        }.show()
    }

    private fun changeFolderRow(item: FolderItem) {
        val max = db.countFolders(null).coerceAtLeast(1)
        promptOrder(this, "تغییر ردیف پوشه", item.sortOrder, max) { newRow ->
            db.setFolderOrder(item.id, newRow); refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        db.purgeExpiredTrash()
        refresh()
        updateClock()
        clockHandler.removeCallbacks(clockTick)
        clockHandler.post(clockTick)
        if (!dueShown) { dueShown = true; showDueReminder() }
    }

    override fun onPause() {
        clockHandler.removeCallbacks(clockTick)
        super.onPause()
    }

    private fun updateClock() {
        val now = java.util.Calendar.getInstance()
        b.digitalClock.text = String.format(java.util.Locale.US, "%02d:%02d:%02d", now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), now.get(java.util.Calendar.SECOND))
        val jalali = Jalali.now()
        b.jalaliToday.text = jalali.substringBefore(" - ")
        b.todayWeekday.text = when (now.get(java.util.Calendar.DAY_OF_WEEK)) {
            java.util.Calendar.SATURDAY -> "شنبه"
            java.util.Calendar.SUNDAY -> "یکشنبه"
            java.util.Calendar.MONDAY -> "دوشنبه"
            java.util.Calendar.TUESDAY -> "سه‌شنبه"
            java.util.Calendar.WEDNESDAY -> "چهارشنبه"
            java.util.Calendar.THURSDAY -> "پنجشنبه"
            else -> "جمعه"
        }
        val gregorian = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.US).format(now.time)
        b.gregorianToday.text = gregorian
    }

    private fun refresh() {
        val items = db.folderItems()
        adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        b.installmentCount.text = db.installmentDueInRange().size.toString()
        b.checkCount.text = db.checkDueInRange().size.toString()
        b.debtorCount.text = "${db.peopleByBalance(true).size} نفر"
        b.creditorCount.text = "${db.peopleByBalance(false).size} نفر"
        refreshRecent()
    }

    private fun refreshRecent() {
        b.recentContainer.removeAllViews()
        val rows = db.recentTransactions(4)
        b.recentEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        rows.forEachIndexed { index, tx ->
            b.recentContainer.addView(recentRow(tx))
            if (index != rows.lastIndex) b.recentContainer.addView(View(this).apply {
                setBackgroundColor(color(R.color.divider)); layoutParams = LinearLayout.LayoutParams(-1, 1)
            })
        }
    }

    private fun recentRow(tx: RecentTx): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, NotebookActivity::class.java).putExtra("notebook_id", tx.notebookId)) }
        }
        val icon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setImageResource(when (tx.sourceType) {
                "invoice" -> R.drawable.ic_receipt_orange
                "installment" -> R.drawable.ic_installment_purple
                "check" -> R.drawable.ic_check_blue
                else -> if (tx.kind == "credit") R.drawable.ic_receive_green else R.drawable.ic_pay_red
            })
        }
        row.addView(icon)
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setPadding(dp(8),0,dp(8),0) }
        center.addView(TextView(this).apply { text = when (tx.sourceType) { "invoice" -> "ثبت فاکتور فروش"; "installment" -> "سررسید قسط"; "check" -> "ثبت چک"; else -> if (tx.kind == "credit") "دریافت از حساب" else "پرداخت به حساب" }; textSize=12f; setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity=Gravity.RIGHT })
        center.addView(TextView(this).apply { text = "${tx.notebookName}  •  ${tx.folderName}"; textSize=9f; setTextColor(color(R.color.secondary)); gravity=Gravity.RIGHT })
        row.addView(center)
        val amount = TextView(this).apply { text = "${if(tx.kind=="credit") "+" else "-"}${formatMoney(tx.amount)}"; textSize=12f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(color(if(tx.kind=="credit") R.color.credit_text else R.color.debt_text)); gravity=Gravity.LEFT; layoutParams=LinearLayout.LayoutParams(dp(115),-2) }
        row.addView(amount)
        return row
    }

    private fun showDueList(items: List<DueEntry>, title: String) {
        if (items.isEmpty()) {
            MaterialAlertDialogBuilder(this).setTitle(title).setMessage("موردی در بازه ۳ روز قبل تا ۵ روز آینده پیدا نشد.").setPositiveButton("باشه", null).show()
            return
        }
        val labels = items.map { "${it.notebookName}  •  ${it.dueDate}\n${formatMoney(it.amount)} تومان" }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle(title).setItems(labels) { _, which ->
            startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", items[which].notebookId))
        }.setNegativeButton("بستن", null).show()
    }

    private fun showPeople(items: List<NotebookListItem>, title: String) {
        if (items.isEmpty()) {
            MaterialAlertDialogBuilder(this).setTitle(title).setMessage("موردی وجود ندارد.").setPositiveButton("باشه", null).show()
            return
        }
        val labels = items.map { "${it.name}\n${formatMoney(kotlin.math.abs(it.balance))} تومان" }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle(title).setItems(labels) { _, which ->
            startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", items[which].id))
        }.setNegativeButton("بستن", null).show()
    }

    private fun showDueReminder() {
        val today = Jalali.now().substringBefore(" - ")
        val due = db.dueNotebooks(today)
        if (due.isEmpty()) return
        val checks = mutableMapOf<Long, android.widget.CheckBox>()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(6), dp(4), dp(6), dp(4)) }
        due.forEachIndexed { idx, n ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(12), dp(10), dp(12), dp(8)) }
            row.background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(255,248,235)); cornerRadius = dp(12).toFloat() }
            row.addView(TextView(this).apply { text = "${n.name} — ${formatMoney(kotlin.math.abs(n.balance))} تومان\nسررسید: ${n.dueDate}"; textSize=13f; setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD) })
            val check = android.widget.CheckBox(this).apply { text = "دیگر برای همین تاریخ نمایش نده"; textSize=11f; layoutDirection=View.LAYOUT_DIRECTION_RTL }
            checks[n.id] = check; row.addView(check); box.addView(row)
            if (idx != due.lastIndex) box.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(8)) })
        }
        val scroll = android.widget.ScrollView(this).apply { addView(box); layoutParams = android.view.ViewGroup.LayoutParams(-1, if (due.size > 4) dp(360) else android.view.ViewGroup.LayoutParams.WRAP_CONTENT) }
        MaterialAlertDialogBuilder(this).setTitle("یادآوری سررسید بدهی (${due.size} حساب)").setView(scroll).setPositiveButton("بررسی شد") { _, _ -> checks.forEach { (id, cb) -> if (cb.isChecked) db.ackDueReminder(id) } }.show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun formatMoney(value: Long) = "%,d".format(value)
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
