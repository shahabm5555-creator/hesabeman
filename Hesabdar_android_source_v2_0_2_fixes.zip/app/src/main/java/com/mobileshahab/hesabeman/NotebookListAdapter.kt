package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class NotebookListAdapter(
    private var items: List<NotebookListItem>,
    private val onClick: (NotebookListItem) -> Unit,
    private val onLongClick: (NotebookListItem) -> Unit
) : RecyclerView.Adapter<NotebookListAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val row: TextView = view.findViewById(R.id.accountRow)
        val name: TextView = view.findViewById(R.id.notebookName)
        val phone: TextView = view.findViewById(R.id.notebookPhone)
        val balance: TextView = view.findViewById(R.id.notebookBalance)
        val status: TextView = view.findViewById(R.id.notebookStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_notebook, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]; val ctx = holder.itemView.context
        holder.row.text = "${item.sortOrder}"
        holder.name.text = item.name
        holder.phone.text = buildString {
            append(if (item.phone.isBlank()) "بدون شماره تماس" else item.phone)
            if (item.dueDate.isNotBlank()) append("  •  سررسید: ${item.dueDate}")
        }
        holder.balance.text = "${String.format(java.util.Locale.US, "%,d", kotlin.math.abs(item.balance))} تومان"
        val (label, color) = when {
            item.balance < 0 -> "بدهکار" to R.color.debt_text
            item.balance > 0 -> "بستانکار" to R.color.credit_text
            else -> "تسویه" to R.color.neutral_text
        }
        val c = ContextCompat.getColor(ctx, color)
        holder.balance.setTextColor(c); holder.status.setTextColor(c)
        holder.status.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(ctx, when {
                item.balance < 0 -> R.color.debt_soft
                item.balance > 0 -> R.color.credit_soft
                else -> R.color.neutral_soft
            })
        )
        holder.status.text = label
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size
    fun submit(newItems: List<NotebookListItem>) { items = newItems; notifyDataSetChanged() }
}
