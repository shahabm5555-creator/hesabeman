package com.mobileshahab.hesabeman

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityNotebookBinding

class NotebookActivity : BaseActivity() {
    private lateinit var b: ActivityNotebookBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: SimpleAdapter
    private var notebookId = 0L
    private var notebookName = "دفترچه حساب"
    private var phone = ""

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) PdfExporter.export(this, uri, notebookName, db.txRecords(notebookId), db.balance(notebookId))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNotebookBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", 0)
        loadNotebookInfo()

        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_notebook)
        b.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.exportPdf) {
                pdfPicker.launch("${notebookName.replace("/", "-")}.pdf")
                true
            } else false
        }

        adapter = SimpleAdapter(emptyList()) {}
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter

        b.addDebt.setOnClickListener { add("debt", "ثبت بدهکار") }
        b.addCredit.setOnClickListener { add("credit", "ثبت بستانکار") }
        b.call.setOnClickListener { callPerson() }
        b.sms.setOnClickListener { sendBalanceSms() }
        b.phoneText.setOnClickListener { if (phone.isBlank()) editPhone() else callPerson() }
        b.editPhone.setOnClickListener { editPhone() }
    }

    private fun loadNotebookInfo() {
        val info = db.notebookInfo(notebookId)
        notebookName = info.name
        phone = info.phone
        b.toolbar.title = notebookName
        b.personName.text = notebookName
        b.avatar.text = notebookName.trim().firstOrNull()?.toString() ?: "ح"
        b.phoneText.text = if (phone.isBlank()) "شماره موبایل ثبت نشده" else phone
    }

    private fun add(kind: String, title: String) {
        promptTransaction(this, title) { amount, note ->
            db.addTx(notebookId, kind, amount, note, Jalali.now())
            refresh()
        }
    }

    private fun editPhone() {
        promptText(this, "شماره موبایل", "مثال: 09123456789") { value ->
            db.updateNotebookPhone(notebookId, value)
            loadNotebookInfo()
        }
    }

    private fun callPerson() {
        if (phone.isBlank()) {
            Toast.makeText(this, "ابتدا شماره موبایل را برای این دفترچه ثبت کنید.", Toast.LENGTH_LONG).show()
            editPhone()
            return
        }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    }

    private fun sendBalanceSms() {
        if (phone.isBlank()) {
            Toast.makeText(this, "ابتدا شماره موبایل را برای این دفترچه ثبت کنید.", Toast.LENGTH_LONG).show()
            editPhone()
            return
        }
        val credit = db.totalCredit(notebookId)
        val debt = db.totalDebt(notebookId)
        val balance = db.balance(notebookId)
        val status = when {
            balance > 0 -> "بستانکار"
            balance < 0 -> "بدهکار"
            else -> "تسویه"
        }
        val message = buildString {
            append("سلام $notebookName\n")
            append("گزارش مانده حساب شما:\n")
            append("کل بستانکاری: ${formatMoney(credit)} تومان\n")
            append("کل بدهکاری: ${formatMoney(debt)} تومان\n")
            append("مانده: ${formatMoney(kotlin.math.abs(balance))} تومان ($status)\n")
            append("تاریخ: ${Jalali.now()}\n")
            append("حسابدار من")
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("ارسال مانده حساب")
            .setMessage(message)
            .setPositiveButton("ارسال پیامک") { _, _ ->
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))
                intent.putExtra("sms_body", message)
                startActivity(intent)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        loadNotebookInfo()
        adapter.submit(db.tx(notebookId))
        val credit = db.totalCredit(notebookId)
        val debt = db.totalDebt(notebookId)
        val x = credit - debt
        b.totalCredit.text = "${formatMoney(credit)} تومان"
        b.totalDebt.text = "${formatMoney(debt)} تومان"
        b.balance.text = "${formatMoney(kotlin.math.abs(x))} تومان ${when { x > 0 -> "بستانکار"; x < 0 -> "بدهکار"; else -> "تسویه" }}"
        b.balance.setTextColor(getColor(if (x >= 0) R.color.credit_text else R.color.debt_text))
    }

    private fun formatMoney(value: Long) = "%,d".format(value)
}
