package com.mobileshahab.hesabeman

import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint
        textDirection = android.view.View.TEXT_DIRECTION_RTL
        textSize = 18f
        setPadding(36, 28, 36, 28)
    }
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setView(input)
        .setPositiveButton("ثبت") { _, _ ->
            val s = input.text.toString().trim()
            if (s.isNotEmpty()) done(s)
        }
        .setNegativeButton("انصراف", null)
        .show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 16, 48, 8)
    }
    val name = EditText(context).apply {
        hint = "نام شخص / دفترچه"
        textSize = 18f
        minHeight = 60
    }
    val phone = EditText(context).apply {
        hint = "شماره موبایل (اختیاری)"
        inputType = InputType.TYPE_CLASS_PHONE
        textSize = 18f
        minHeight = 60
    }
    box.addView(name); box.addView(phone)
    MaterialAlertDialogBuilder(context)
        .setTitle("دفترچه حساب جدید")
        .setMessage("شماره موبایل برای تماس و ارسال مانده حساب استفاده می‌شود.")
        .setView(box)
        .setPositiveButton("ثبت") { _, _ ->
            val n = name.text.toString().trim()
            if (n.isNotEmpty()) done(n, phone.text.toString().trim())
        }
        .setNegativeButton("انصراف", null)
        .show()
}

fun promptTransaction(context: Context, title: String, done: (Long, String) -> Unit) {
    val box = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 16, 48, 8)
    }
    val amount = EditText(context).apply {
        hint = "مبلغ به تومان"
        inputType = InputType.TYPE_CLASS_NUMBER
        textSize = 18f
        minHeight = 60
    }
    val note = EditText(context).apply {
        hint = "توضیحات"
        textSize = 18f
        minHeight = 60
    }
    box.addView(amount); box.addView(note)
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setMessage("تاریخ و ساعت شمسی هنگام ثبت به‌صورت خودکار ذخیره می‌شود.")
        .setView(box)
        .setPositiveButton("ثبت") { _, _ ->
            val a = amount.text.toString().toLongOrNull()
            if (a != null && a > 0) done(a, note.text.toString().trim())
        }
        .setNegativeButton("انصراف", null)
        .show()
}
