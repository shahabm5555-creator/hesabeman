package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.util.Collections

// ───────── Data models ─────────
data class BankItem(
    val id: Long,
    val name: String,
    val accountNumber: String,
    val cardNumber: String,
    val iban: String,
    val description: String,
    val balance: Long,
    val createdAt: String,
    val updatedAt: String
)

data class BankTxItem(
    val id: Long,
    val bankId: Long,
    val title: String,
    val amount: Long,
    val transactionType: String, // "deposit" or "withdraw"
    val description: String,
    val date: String,   // Jalali yyyy/MM/dd
    val time: String,   // HH:mm
    val createdAt: String
)

data class NoteItem(
    val id: Long,
    val title: String,
    val content: String,
    val createdAt: String,
    val updatedAt: String,
    val reminderDate: String,   // Jalali yyyy/MM/dd, blank if none
    val reminderTime: String,   // HH:mm, blank if none
    val reminderEnabled: Boolean
)

/**
 * Separate database dedicated to Banks / Bank transactions / Notes / Note reminders.
 * Intentionally kept apart from personal_hesabdar.db (DbHelper) so the existing
 * accounting data, structure and migrations are never touched by this feature set.
 *
 * Follows the same SQLiteOpenHelper style as DbHelper.kt (no Room), since that is
 * the architecture already used by this project.
 */
class ExtraDbHelper(private val contextRef: Context) :
    SQLiteOpenHelper(contextRef, DB_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DB_NAME = "hesabdar_extra.db"
        const val DATABASE_VERSION = 1

        const val TYPE_DEPOSIT = "deposit"
        const val TYPE_WITHDRAW = "withdraw"

        fun databaseFile(context: Context): File = context.getDatabasePath(DB_NAME)

        private val instances = Collections.synchronizedSet(mutableSetOf<ExtraDbHelper>())

        fun closeAll() {
            synchronized(instances) {
                instances.toList().forEach { runCatching { it.close() } }
                instances.clear()
            }
        }
    }

    init {
        instances += this
        setWriteAheadLoggingEnabled(true)
    }

    override fun close() {
        instances.remove(this)
        super.close()
    }

    /** Mirrors DbHelper's markChanged(): any write here also triggers a debounced full backup. */
    private fun markChanged() { BackupScheduler.request(contextRef) }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE banks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            account_number TEXT NOT NULL DEFAULT '',
            card_number TEXT NOT NULL DEFAULT '',
            iban TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '',
            deleted_at INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE bank_tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bank_id INTEGER NOT NULL REFERENCES banks(id) ON DELETE CASCADE,
            title TEXT NOT NULL DEFAULT '',
            amount INTEGER NOT NULL,
            transaction_type TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            deleted_at INTEGER,
            created_at TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL DEFAULT '',
            content TEXT NOT NULL DEFAULT '',
            deleted_at INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            reminder_date TEXT NOT NULL DEFAULT '',
            reminder_time TEXT NOT NULL DEFAULT '',
            reminder_enabled INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_banks_active ON banks(deleted_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bank_tx_bank_active ON bank_tx(bank_id, deleted_at, date, time)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notes_active_created ON notes(deleted_at, created_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notes_reminder ON notes(reminder_enabled, reminder_date, reminder_time)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // No migrations yet — DATABASE_VERSION starts at 1. Future schema changes for
        // banks/notes must add an `if (oldVersion < N) { ... }` step here, mirroring
        // DbHelper's migration pattern, so existing bank/note data is never dropped.
    }

    // ───────── Banks ─────────

    fun addBank(name: String, accountNumber: String, cardNumber: String, iban: String, description: String): Long {
        if (name.isBlank()) return -1L
        val now = Jalali.now()
        val id = writableDatabase.insert("banks", null, ContentValues().apply {
            put("name", name.trim())
            put("account_number", accountNumber.trim())
            put("card_number", cardNumber.trim())
            put("iban", iban.trim())
            put("description", description.trim())
            put("created_at", now)
            put("updated_at", now)
        })
        if (id != -1L) markChanged()
        return id
    }

    fun updateBank(id: Long, name: String, accountNumber: String, cardNumber: String, iban: String, description: String): Boolean {
        if (name.isBlank()) return false
        val ok = writableDatabase.update("banks", ContentValues().apply {
            put("name", name.trim())
            put("account_number", accountNumber.trim())
            put("card_number", cardNumber.trim())
            put("iban", iban.trim())
            put("description", description.trim())
            put("updated_at", Jalali.now())
        }, "id=? AND deleted_at IS NULL", arrayOf(id.toString())) > 0
        if (ok) markChanged()
        return ok
    }

    /** Deletes the bank and its transactions (cascades). */
    fun deleteBank(id: Long): Boolean {
        val d = writableDatabase
        d.beginTransaction()
        return try {
            val now = System.currentTimeMillis()
            val ok = d.update("banks", ContentValues().apply { put("deleted_at", now) }, "id=?", arrayOf(id.toString())) > 0
            if (ok) d.update("bank_tx", ContentValues().apply { put("deleted_at", now) }, "bank_id=?", arrayOf(id.toString()))
            d.setTransactionSuccessful()
            if (ok) markChanged()
            ok
        } finally { d.endTransaction() }
    }

    fun bank(id: Long): BankItem? {
        readableDatabase.rawQuery(
            """SELECT b.id,b.name,b.account_number,b.card_number,b.iban,b.description,b.created_at,b.updated_at,
                IFNULL((SELECT SUM(CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END)
                        FROM bank_tx WHERE bank_id=b.id AND deleted_at IS NULL),0)
               FROM banks b WHERE b.id=? AND b.deleted_at IS NULL""",
            arrayOf(id.toString())
        ).use {
            if (!it.moveToFirst()) return null
            return BankItem(
                it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4),
                it.getString(5), it.getLong(8), it.getString(6), it.getString(7)
            )
        }
    }

    fun banks(): List<BankItem> {
        val out = mutableListOf<BankItem>()
        readableDatabase.rawQuery(
            """SELECT b.id,b.name,b.account_number,b.card_number,b.iban,b.description,b.created_at,b.updated_at,
                IFNULL((SELECT SUM(CASE WHEN transaction_type='deposit' THEN amount ELSE -amount END)
                        FROM bank_tx WHERE bank_id=b.id AND deleted_at IS NULL),0)
               FROM banks b WHERE b.deleted_at IS NULL ORDER BY b.id DESC""", null
        ).use { c ->
            while (c.moveToNext()) {
                out += BankItem(
                    c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4),
                    c.getString(5), c.getLong(8), c.getString(6), c.getString(7)
                )
            }
        }
        return out
    }

    // ───────── Bank transactions ─────────

    fun addBankTx(bankId: Long, title: String, amount: Long, type: String, description: String, date: String, time: String): Long {
        if (type !in setOf(TYPE_DEPOSIT, TYPE_WITHDRAW) || amount <= 0L || !Jalali.isValidDate(date) || !Jalali.isValidTime(time)) return -1L
        val exists = readableDatabase.rawQuery("SELECT COUNT(*) FROM banks WHERE id=? AND deleted_at IS NULL", arrayOf(bankId.toString())).use { it.moveToFirst() && it.getInt(0) > 0 }
        if (!exists) return -1L
        val id = writableDatabase.insert("bank_tx", null, ContentValues().apply {
            put("bank_id", bankId); put("title", title.trim()); put("amount", amount)
            put("transaction_type", type); put("description", description.trim())
            put("date", date.trim()); put("time", time.trim()); put("created_at", Jalali.now())
        })
        if (id != -1L) markChanged()
        return id
    }

    fun updateBankTx(id: Long, title: String, amount: Long, type: String, description: String, date: String, time: String): Boolean {
        if (type !in setOf(TYPE_DEPOSIT, TYPE_WITHDRAW) || amount <= 0L || !Jalali.isValidDate(date) || !Jalali.isValidTime(time)) return false
        val ok = writableDatabase.update("bank_tx", ContentValues().apply {
            put("title", title.trim()); put("amount", amount); put("transaction_type", type)
            put("description", description.trim()); put("date", date.trim()); put("time", time.trim())
        }, "id=? AND deleted_at IS NULL", arrayOf(id.toString())) > 0
        if (ok) markChanged()
        return ok
    }

    fun deleteBankTx(id: Long): Boolean {
        val ok = writableDatabase.update("bank_tx", ContentValues().apply { put("deleted_at", System.currentTimeMillis()) }, "id=?", arrayOf(id.toString())) > 0
        if (ok) markChanged()
        return ok
    }

    /** [query] filters by title/description (blank = no filter); [type] is "all"/"deposit"/"withdraw". */
    fun bankTransactions(bankId: Long, query: String = "", type: String = "all"): List<BankTxItem> {
        val where = StringBuilder("bank_id=? AND deleted_at IS NULL")
        val args = mutableListOf(bankId.toString())
        if (query.isNotBlank()) {
            where.append(" AND (title LIKE ? OR description LIKE ?)")
            val q = "%${query.trim()}%"; args += q; args += q
        }
        if (type == TYPE_DEPOSIT || type == TYPE_WITHDRAW) {
            where.append(" AND transaction_type=?"); args += type
        }
        val out = mutableListOf<BankTxItem>()
        readableDatabase.rawQuery(
            """SELECT id,bank_id,title,amount,transaction_type,description,date,time,created_at
               FROM bank_tx WHERE $where ORDER BY date DESC, time DESC, id DESC""", args.toTypedArray()
        ).use { c ->
            while (c.moveToNext()) {
                out += BankTxItem(
                    c.getLong(0), c.getLong(1), c.getString(2), c.getLong(3), c.getString(4),
                    c.getString(5), c.getString(6), c.getString(7), c.getString(8)
                )
            }
        }
        return out
    }

    // ───────── Notes ─────────

    fun addNote(title: String, content: String, reminderDate: String = "", reminderTime: String = "", reminderEnabled: Boolean = false): Long {
        if (title.isBlank() && content.isBlank()) return -1L
        if (reminderEnabled && (!Jalali.isValidDate(reminderDate) || !Jalali.isValidTime(reminderTime))) return -1L
        val now = Jalali.now()
        val id = writableDatabase.insert("notes", null, ContentValues().apply {
            put("title", title.trim()); put("content", content.trim())
            put("created_at", now); put("updated_at", now)
            put("reminder_date", reminderDate.trim()); put("reminder_time", reminderTime.trim())
            put("reminder_enabled", if (reminderEnabled) 1 else 0)
        })
        if (id != -1L) markChanged()
        return id
    }

    fun updateNote(id: Long, title: String, content: String, reminderDate: String, reminderTime: String, reminderEnabled: Boolean): Boolean {
        if (title.isBlank() && content.isBlank()) return false
        if (reminderEnabled && (!Jalali.isValidDate(reminderDate) || !Jalali.isValidTime(reminderTime))) return false
        val ok = writableDatabase.update("notes", ContentValues().apply {
            put("title", title.trim()); put("content", content.trim()); put("updated_at", Jalali.now())
            put("reminder_date", reminderDate.trim()); put("reminder_time", reminderTime.trim())
            put("reminder_enabled", if (reminderEnabled) 1 else 0)
        }, "id=? AND deleted_at IS NULL", arrayOf(id.toString())) > 0
        if (ok) markChanged()
        return ok
    }

    fun deleteNote(id: Long): Boolean {
        val ok = writableDatabase.update("notes", ContentValues().apply { put("deleted_at", System.currentTimeMillis()) }, "id=?", arrayOf(id.toString())) > 0
        if (ok) markChanged()
        return ok
    }

    fun note(id: Long): NoteItem? {
        readableDatabase.rawQuery(
            "SELECT id,title,content,created_at,updated_at,reminder_date,reminder_time,reminder_enabled FROM notes WHERE id=? AND deleted_at IS NULL",
            arrayOf(id.toString())
        ).use {
            if (!it.moveToFirst()) return null
            return NoteItem(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4), it.getString(5), it.getString(6), it.getInt(7) == 1)
        }
    }

    /** Newest first, per spec section 4 (sorted by creation date/time descending). */
    fun notes(): List<NoteItem> {
        val out = mutableListOf<NoteItem>()
        readableDatabase.rawQuery(
            "SELECT id,title,content,created_at,updated_at,reminder_date,reminder_time,reminder_enabled FROM notes WHERE deleted_at IS NULL ORDER BY id DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out += NoteItem(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getInt(7) == 1)
            }
        }
        return out
    }

    /** All notes with an active, enabled reminder — used to re-register alarms after boot/app restart. */
    fun notesWithActiveReminders(): List<NoteItem> {
        val out = mutableListOf<NoteItem>()
        readableDatabase.rawQuery(
            """SELECT id,title,content,created_at,updated_at,reminder_date,reminder_time,reminder_enabled
               FROM notes WHERE deleted_at IS NULL AND reminder_enabled=1 AND reminder_date!='' AND reminder_time!=''""",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out += NoteItem(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getInt(7) == 1)
            }
        }
        return out
    }
}
