package com.mobileshahab.hesabeman

import android.content.Context
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TimePicker
import android.widget.RadioButton
import android.widget.RadioGroup
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

private fun normalizeDigits(value: String): String = value.map {
    when (it) {
        in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
        else -> it
    }
}.joinToString("")

private fun formatAmountInput(value: String): String {
    val digits = normalizeDigits(value).filter(Char::isDigit).trimStart('0').ifEmpty { "0" }
    return try { "%,d".format(digits.toLong()) } catch (_: Exception) { digits }
}

private fun attachDateFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(8)
            val formatted = buildString {
                raw.forEachIndexed { i, ch ->
                    if (i == 4 || i == 6) append('/')
                    append(ch)
                }
            }
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

private fun attachTimeFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(4)
            val formatted = if (raw.length > 2) raw.substring(0, 2) + ":" + raw.substring(2) else raw
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint; textDirection = View.TEXT_DIRECTION_RTL; textSize = 18f; setPadding(36, 28, 36, 28)
    }
    MaterialAlertDialogBuilder(context).setTitle(title).setView(input)
        .setPositiveButton("ثبت") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
    val name = EditText(context).apply { hint = "نام شخص / حساب"; textSize = 18f; minHeight = 60 }
    val phone = EditText(context).apply { hint = "شماره موبایل (اختیاری)"; inputType = InputType.TYPE_CLASS_PHONE; textSize = 18f; minHeight = 60 }
    box.addView(name); box.addView(phone)
    MaterialAlertDialogBuilder(context).setTitle("حساب جدید").setMessage("شماره موبایل برای تماس و ارسال مانده حساب استفاده می‌شود.").setView(box)
        .setPositiveButton("ثبت") { _, _ -> name.text.toString().trim().takeIf { it.isNotEmpty() }?.let { done(it, normalizeDigits(phone.text.toString().trim())) } }
        .setNegativeButton("انصراف", null).show()
}

fun promptOrder(context: Context, title: String, current: Int, max: Int, done: (Int) -> Unit) {
    val input = EditText(context).apply {
        hint = "شماره ردیف از ۱ تا $max"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 18f; minHeight = 60
        setText(current.toString()); selectAll()
    }
    MaterialAlertDialogBuilder(context).setTitle(title)
        .setMessage("ردیف جدید را وارد کنید؛ موارد دیگر خودکار جابه‌جا می‌شوند.")
        .setView(input)
        .setPositiveButton("انتقال") { _, _ -> input.text.toString().toIntOrNull()?.takeIf { it in 1..max }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptTransaction(
    context: Context,
    title: String,
    initialKind: String = "debt",
    initialAmount: Long? = null,
    initialNote: String = "",
    initialDateTime: String = Jalali.now(),
    done: (String, Long, String, String) -> Unit
) {
    fun rounded(fill: Int, stroke: Int? = null, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            if (stroke != null) setStroke(2, stroke)
        }

    fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
    fun gap(h: Int) = View(context).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    val box = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(2), dp(16), dp(6))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        alpha = 0f
        translationY = dp(12).toFloat()
    }

    val typeGroup = RadioGroup(context).apply {
        orientation = RadioGroup.HORIZONTAL
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    val debtRadio = RadioButton(context).apply {
        id = View.generateViewId()
        text = "پرداخت کردم  ↑"
        textSize = 14f
        minHeight = dp(50)
        includeFontPadding = false
        maxLines = 1
        gravity = Gravity.CENTER
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        setPadding(dp(4), 0, dp(4), 0)
        buttonTintList = ColorStateList.valueOf(Color.rgb(211, 86, 86))
        background = rounded(Color.rgb(255, 248, 248), Color.rgb(239, 208, 208), 16f)
    }
    val creditRadio = RadioButton(context).apply {
        id = View.generateViewId()
        text = "دریافت کردم  ↓"
        textSize = 14f
        minHeight = dp(50)
        includeFontPadding = false
        maxLines = 1
        gravity = Gravity.CENTER
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        setPadding(dp(4), 0, dp(4), 0)
        buttonTintList = ColorStateList.valueOf(Color.rgb(56, 157, 103))
        background = rounded(Color.rgb(248, 253, 249), Color.rgb(209, 235, 219), 16f)
    }
    typeGroup.addView(debtRadio, RadioGroup.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(4) })
    typeGroup.addView(creditRadio, RadioGroup.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(4) })

    fun updateTypeVisual(animate: Boolean = false) {
        debtRadio.background = if (debtRadio.isChecked)
            rounded(Color.rgb(255, 231, 231), Color.rgb(224, 103, 103), 16f)
        else rounded(Color.rgb(255, 250, 250), Color.rgb(235, 224, 224), 16f)
        creditRadio.background = if (creditRadio.isChecked)
            rounded(Color.rgb(226, 246, 234), Color.rgb(87, 184, 126), 16f)
        else rounded(Color.rgb(250, 255, 251), Color.rgb(224, 238, 228), 16f)
        if (animate) {
            val selected = if (creditRadio.isChecked) creditRadio else debtRadio
            selected.animate().scaleX(1.025f).scaleY(1.025f).setDuration(100).withEndAction {
                selected.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
        }
    }
    typeGroup.check(if (initialKind == "credit") creditRadio.id else debtRadio.id)
    typeGroup.setOnCheckedChangeListener { _, _ -> updateTypeVisual(true) }
    updateTypeVisual()

    fun field(fill: Int = Color.WHITE, stroke: Int = Color.rgb(226, 235, 232)) = rounded(fill, stroke, 16f)
    fun sectionLabel(text: String, color: Int = Color.rgb(95, 107, 107)): TextView = TextView(context).apply {
        this.text = text
        textSize = 11f
        setTextColor(color)
        gravity = Gravity.END
        includeFontPadding = false
        setPadding(dp(4), 0, dp(4), dp(3))
    }

    val amount = EditText(context).apply {
        hint = "مبلغ به تومان"
        inputType = InputType.TYPE_CLASS_NUMBER
        textSize = 17f
        minHeight = dp(58)
        includeFontPadding = false
        gravity = Gravity.CENTER_VERTICAL or Gravity.END
        background = field()
        setPadding(dp(16), 0, dp(16), 0)
        setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_edit, 0)
        setCompoundDrawableTintList(ColorStateList.valueOf(Color.rgb(76, 126, 122)))
        setCompoundDrawablePadding(dp(8))
        filters = arrayOf(InputFilter.LengthFilter(18))
        setText(initialAmount?.let { "%,d".format(it) } ?: "")
        setSelection(text.length)
        addTextChangedListener(object : TextWatcher {
            private var busy = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                val formatted = formatAmountInput(e?.toString().orEmpty())
                if (e?.toString() != formatted) {
                    busy = true
                    setText(formatted)
                    setSelection(text.length)
                    busy = false
                }
            }
        })
    }

    val note = EditText(context).apply {
        hint = "توضیحات (اختیاری)"
        textSize = 14f
        minHeight = dp(54)
        includeFontPadding = false
        gravity = Gravity.CENTER_VERTICAL or Gravity.END
        setSingleLine(true)
        setText(initialNote)
        background = field()
        setPadding(dp(16), 0, dp(16), 0)
        setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_edit, 0)
        setCompoundDrawableTintList(ColorStateList.valueOf(Color.rgb(126, 109, 206)))
        setCompoundDrawablePadding(dp(8))
    }

    val parts = initialDateTime.split(" - ")
    val date = EditText(context).apply {
        hint = "تاریخ"
        textSize = 13f
        minHeight = dp(58)
        includeFontPadding = false
        gravity = Gravity.CENTER_VERTICAL or Gravity.END
        isFocusable = false
        isClickable = true
        setText(parts.getOrNull(0).orEmpty())
        background = field()
        setPadding(dp(10), 0, dp(10), 0)
        setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_calendar_color, 0)
        setCompoundDrawableTintList(null)
        setCompoundDrawablePadding(dp(6))
        setOnClickListener {
            animate().scaleX(0.98f).scaleY(0.98f).setDuration(70).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start()
            showJalaliDatePicker(context, text.toString()) { setText(it) }
        }
    }

    val time = EditText(context).apply {
        hint = "ساعت"
        textSize = 13f
        minHeight = dp(58)
        includeFontPadding = false
        gravity = Gravity.CENTER_VERTICAL or Gravity.END
        isFocusable = false
        isClickable = true
        setText(parts.getOrNull(1).orEmpty())
        background = field()
        setPadding(dp(10), 0, dp(10), 0)
        setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_clock_color, 0)
        setCompoundDrawableTintList(null)
        setCompoundDrawablePadding(dp(6))
        setOnClickListener {
            animate().scaleX(0.98f).scaleY(0.98f).setDuration(70).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start()
            showTimePicker(context, text.toString()) { setText(it) }
        }
    }

    val dateTimeRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    dateTimeRow.addView(date, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(4) })
    dateTimeRow.addView(time, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(4) })

    box.addView(sectionLabel("نوع تراکنش"))
    box.addView(typeGroup)
    box.addView(gap(10))
    box.addView(sectionLabel("مبلغ"))
    box.addView(amount)
    box.addView(gap(8))
    box.addView(sectionLabel("شرح"))
    box.addView(note)
    box.addView(gap(8))
    box.addView(sectionLabel("زمان ثبت"))
    box.addView(dateTimeRow)

    val dialog = MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setView(box)
        .setPositiveButton("ثبت تراکنش", null)
        .setNegativeButton("انصراف", null)
        .create()

    dialog.setOnShowListener {
        box.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        val titleId = context.resources.getIdentifier("alertTitle", "id", "android")
        dialog.findViewById<TextView>(titleId)?.apply {
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.rgb(41, 55, 55))
        }
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).apply {
            setTextColor(Color.rgb(48, 137, 111))
            setOnClickListener {
                val a = normalizeDigits(amount.text.toString()).replace(",", "").toLongOrNull()
                val d = normalizeDigits(date.text.toString().trim())
                val t = normalizeDigits(time.text.toString().trim())
                val now = Jalali.now()
                val finalDate = if (d.isBlank()) now.substringBefore(" - ") else d
                val finalTime = if (t.isBlank()) now.substringAfter(" - ") else t
                when {
                    a == null || a <= 0L -> Toast.makeText(context, "مبلغ معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                    !Jalali.isValidDate(finalDate) -> Toast.makeText(context, "تاریخ شمسی معتبر نیست.", Toast.LENGTH_SHORT).show()
                    !Jalali.isValidTime(finalTime) -> Toast.makeText(context, "ساعت معتبر نیست.", Toast.LENGTH_SHORT).show()
                    else -> {
                        val kind = if (debtRadio.isChecked) "debt" else "credit"
                        done(kind, a, note.text.toString().trim(), "$finalDate - $finalTime")
                        dialog.dismiss()
                    }
                }
            }
        }
        dialog.getButton(android.content.DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.rgb(95, 107, 107))
    }
    dialog.show()
}

private fun showJalaliDatePicker(context: Context, current: String, done: (String) -> Unit) {
    val now = Jalali.now().substringBefore(" - ")
    val source = if (Jalali.isValidDate(current)) current else now
    val parts = source.split("/")
    val year = parts.getOrNull(0)?.toIntOrNull() ?: 1405
    val month = parts.getOrNull(1)?.toIntOrNull() ?: 1
    val day = parts.getOrNull(2)?.toIntOrNull() ?: 1

    val row = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER
        setPadding(8, 4, 8, 4)
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }
    val yearPicker = NumberPicker(context).apply { minValue = 1200; maxValue = 1600; value = year; wrapSelectorWheel = false }
    val monthPicker = NumberPicker(context).apply { minValue = 1; maxValue = 12; value = month; wrapSelectorWheel = false }
    val dayPicker = NumberPicker(context).apply { minValue = 1; maxValue = jalaliMonthDays(year, month); value = day.coerceAtMost(maxValue); wrapSelectorWheel = false }

    fun refreshDays() { dayPicker.maxValue = jalaliMonthDays(yearPicker.value, monthPicker.value); if (dayPicker.value > dayPicker.maxValue) dayPicker.value = dayPicker.maxValue }
    yearPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }
    monthPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }
    row.addView(dayPicker, LinearLayout.LayoutParams(90, 150))
    row.addView(monthPicker, LinearLayout.LayoutParams(90, 150))
    row.addView(yearPicker, LinearLayout.LayoutParams(105, 150))

    MaterialAlertDialogBuilder(context)
        .setTitle("انتخاب تاریخ شمسی")
        .setView(row)
        .setPositiveButton("انتخاب") { _, _ -> done("%04d/%02d/%02d".format(yearPicker.value, monthPicker.value, dayPicker.value)) }
        .setNegativeButton("انصراف", null)
        .show()
}

private fun jalaliMonthDays(year: Int, month: Int): Int = when {
    month in 1..6 -> 31
    month in 7..11 -> 30
    else -> if (Jalali.isValidDate("%04d/12/30".format(year))) 30 else 29
}

private fun showTimePicker(context: Context, current: String, done: (String) -> Unit) {
    val parts = normalizeDigits(current).split(":")
    val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE)
    android.app.TimePickerDialog(context, { _: TimePicker, h: Int, m: Int -> done("%02d:%02d".format(h, m)) }, hour, minute, true).show()
}
