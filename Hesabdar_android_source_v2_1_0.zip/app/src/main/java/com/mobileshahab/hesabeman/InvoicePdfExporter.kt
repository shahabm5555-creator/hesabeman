package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

object InvoicePdfExporter {

    fun export(
        context: Context,
        uri: Uri,
        invoiceNumber: Int,
        buyerName: String,
        buyerPhone: String = "",
        sellerName: String,
        sellerAddress: String,
        sellerPhone: String,
        sellerSlogan: String,
        items: List<InvoiceItem>,
        date: String,
        onDone: (Uri) -> Unit
    ): Boolean {
        return try {
            val pageW = 595; val pageH = 842
            val m = 36f

            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
            val c = page.canvas

            val bold = Typeface.DEFAULT_BOLD
            val green = Color.rgb(0, 100, 80)
            val lightGreen = Color.rgb(220, 239, 229)
            val darkGray = Color.rgb(60, 60, 60)
            val medGray = Color.rgb(120, 120, 120)

            fun p(size: Float, face: Typeface = Typeface.DEFAULT, color: Int = Color.BLACK, align: Paint.Align = Paint.Align.CENTER) =
                Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; typeface = face; this.color = color; textAlign = align }

            fun rect(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
            fun line(color: Int = Color.rgb(190, 210, 200), w: Float = 0.8f) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = w }
            fun roundRect(c2: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, stroke: Int = 0, strokeW: Float = 0f) {
                val fillP = rect(fill)
                c2.drawRoundRect(RectF(l, t, r, b), rad, rad, fillP)
                if (stroke != 0) {
                    val sp = line(stroke, strokeW)
                    sp.style = Paint.Style.STROKE
                    c2.drawRoundRect(RectF(l, t, r, b), rad, rad, sp)
                }
            }

            var y = m

            // ══ HEADER BLOCK ══
            roundRect(c, m, y, pageW - m, y + 80f, 12f, green)
            c.drawText(sellerName.ifBlank { "فاکتور فروش" }, pageW / 2f, y + 34f,
                p(24f, bold, Color.WHITE, Paint.Align.CENTER))
            if (sellerSlogan.isNotBlank())
                c.drawText(sellerSlogan, pageW / 2f, y + 56f,
                    p(11f, color = Color.rgb(200, 230, 220), align = Paint.Align.CENTER))
            y += 90f

            // ══ INVOICE INFO ROW (clearly below header) ══
            roundRect(c, m, y, pageW - m, y + 34f, 8f, lightGreen)
            c.drawText("فاکتور شماره: $invoiceNumber", pageW - m - 8f, y + 22f,
                p(12f, bold, green, Paint.Align.RIGHT))
            c.drawText("تاریخ: $date", m + 8f, y + 22f,
                p(12f, bold, green, Paint.Align.LEFT))
            y += 44f

            // ══ BUYER / SELLER CARDS ══
            val halfW = (pageW - 2 * m - 12f) / 2f
            val cardH = if ((sellerAddress + sellerPhone + buyerPhone).isNotBlank()) 72f else 52f

            // Seller card (right side in RTL context → left on canvas)
            val xSeller = m; val xBuyer = m + halfW + 12f

            for ((x, label, name, phone, address) in listOf(
                Data5(xSeller, "فروشنده", sellerName.ifBlank { "—" }, sellerPhone, sellerAddress),
                Data5(xBuyer, "خریدار", buyerName, buyerPhone, "")
            )) {
                roundRect(c, x, y, x + halfW, y + cardH, 10f, lightGreen, Color.rgb(170, 210, 195), 0.8f)
                // Header bar inside card
                roundRect(c, x, y, x + halfW, y + 22f, 10f, green)
                c.drawRect(x, y + 12f, x + halfW, y + 22f, rect(green)) // flatten bottom corners of header
                c.drawText(label, x + halfW / 2f, y + 15f, p(10f, bold, Color.WHITE, Paint.Align.CENTER))
                // Content
                c.drawText(name, x + halfW / 2f, y + 36f, p(11f, bold, darkGray, Paint.Align.CENTER))
                var cy = y + 50f
                if (phone.isNotBlank()) { c.drawText(phone, x + halfW / 2f, cy, p(9f, color = medGray, align = Paint.Align.CENTER)); cy += 14f }
                if (address.isNotBlank()) { c.drawText(address, x + halfW / 2f, cy, p(9f, color = medGray, align = Paint.Align.CENTER)) }
            }
            y += cardH + 16f

            // ══ ITEMS TABLE ══
            // Header row
            roundRect(c, m, y, pageW - m, y + 24f, 6f, green)
            val cols = mapOf(
                "ردیف" to (m + 16f to m + 38f),
                "شرح" to (m + 38f to pageW - m - 220f),
                "مقدار" to (pageW - m - 220f to pageW - m - 140f),
                "فی" to (pageW - m - 140f to pageW - m - 60f),
                "جمع" to (pageW - m - 60f to pageW - m)
            )
            val hdrY = y + 16f
            c.drawText("ردیف", m + 27f, hdrY, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("شرح کالا / خدمات", m + 38f + (pageW - m - 220f - m - 38f) / 2f, hdrY, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("مقدار", pageW - m - 180f, hdrY, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("فی (تومان)", pageW - m - 100f, hdrY, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("جمع", pageW - m - 30f, hdrY, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            y += 26f

            items.forEachIndexed { idx, item ->
                val rowH = 26f
                val rowBg = if (idx % 2 == 0) Color.WHITE else Color.rgb(245, 250, 247)
                c.drawRect(m, y, pageW - m, y + rowH, rect(rowBg))
                val cy2 = y + 17f
                c.drawText("${idx + 1}", m + 27f, cy2, p(9f, color = darkGray, align = Paint.Align.CENTER))
                // Item name — right aligned
                c.drawText(if (item.name.length > 28) item.name.take(28) + "…" else item.name,
                    pageW - m - 225f, cy2, p(9f, color = darkGray, align = Paint.Align.RIGHT))
                // Qty, price, total — left aligned
                c.drawText("${item.qty} عدد", pageW - m - 145f, cy2, p(9f, color = darkGray, align = Paint.Align.LEFT))
                c.drawText("%,d".format(item.unitPrice), pageW - m - 65f, cy2, p(9f, color = darkGray, align = Paint.Align.LEFT))
                c.drawText("%,d".format(item.total), pageW - m - 5f, cy2, p(9f, color = darkGray, align = Paint.Align.RIGHT))
                c.drawLine(m, y + rowH, pageW - m, y + rowH, line())
                y += rowH
            }
            // Table border
            val sp = line(Color.rgb(170, 210, 195), 1f); sp.style = Paint.Style.STROKE
            c.drawRect(m, y - items.size * 26f - 26f, pageW - m, y, sp)
            y += 14f

            // ══ TOTALS ══
            val grandTotal = items.sumOf { it.total }
            val totRows = listOf("جمع کل" to "%,d".format(grandTotal),
                "دریافتی" to "0", "قابل پرداخت" to "%,d".format(grandTotal),
                "جمع اقلام" to "${items.size}")
            totRows.forEachIndexed { i, (label, value) ->
                val bg = if (i == 2) Color.rgb(200, 235, 220) else lightGreen
                roundRect(c, m + 100f, y, pageW - m, y + 22f, 5f, bg)
                c.drawText(value, m + 200f, y + 15f, p(10f, bold, green, Paint.Align.CENTER))
                c.drawText(label, pageW - m - 10f, y + 15f, p(10f, bold, darkGray, Paint.Align.RIGHT))
                c.drawLine(m + 100f, y + 22f, pageW - m, y + 22f, line())
                y += 24f
            }
            y += 8f

            // ══ AMOUNT IN WORDS ══
            roundRect(c, m, y, pageW - m, y + 24f, 6f, lightGreen)
            c.drawText("قابل پرداخت: %,d تومان".format(grandTotal),
                pageW / 2f, y + 16f, p(10f, bold, green, Paint.Align.CENTER))
            y += 34f

            // ══ SIGNATURE ROW ══
            val sigW = (pageW - 2 * m - 12f) / 2f
            for ((x, label) in listOf(m to "امضا فروشنده", m + sigW + 12f to "امضا خریدار")) {
                roundRect(c, x, y, x + sigW, y + 60f, 10f, lightGreen, Color.rgb(170, 210, 195), 0.8f)
                roundRect(c, x, y, x + sigW, y + 22f, 10f, green)
                c.drawRect(x, y + 12f, x + sigW, y + 22f, rect(green))
                c.drawText(label, x + sigW / 2f, y + 15f, p(10f, bold, Color.WHITE, Paint.Align.CENTER))
            }

            doc.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Cannot open output")
            doc.close()
            Toast.makeText(context, "فاکتور PDF ذخیره شد.", Toast.LENGTH_LONG).show()
            onDone(uri)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ساخت PDF: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    // Helper data class for card drawing
    private data class Data5(val x: Float, val label: String, val name: String, val phone: String, val address: String)
}
