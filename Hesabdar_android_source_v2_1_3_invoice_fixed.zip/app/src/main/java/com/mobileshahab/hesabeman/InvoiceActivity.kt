package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class InvoiceActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1L
    private var notebookName = ""
    private var notebookPhone = ""
    private var editingInvoiceId: Long = -1L
    private var editingInvoiceNumber: Int = 0

    private val items = mutableListOf<InvoiceItem>()
    private lateinit var itemsContainer: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var prepayField: EditText
    private lateinit var dueDateField: TextView
    private lateinit var noteField: EditText
    private lateinit var kindGroup: RadioGroup
    private lateinit var kindDebt: RadioButton
    private lateinit var kindCredit: RadioButton

    private val savePdfLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> if (uri != null) exportPdf(uri, shareAfter = false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1L)
        notebookName = intent.getStringExtra("notebook_name") ?: db.notebookName(notebookId)
        notebookPhone = intent.getStringExtra("notebook_phone") ?: db.notebookInfo(notebookId).phone
        editingInvoiceId = intent.getLongExtra("invoice_id", -1L)

        buildUi()

        if (editingInvoiceId != -1L) loadInvoice(editingInvoiceId)
        else {
            dueDateField.text = "بدون سررسید"
            refreshItems()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(64))
        }
        val back = MaterialButton(this).apply {
            text = "×"; textSize = 24f; minWidth = 0; insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = if (editingInvoiceId == -1L) "فاکتور جدید" else "ویرایش فاکتور"
            textSize = 17f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        toolbar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        toolbar.addView(title)
        toolbar.addView(View(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(toolbar)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(100))
        }

        // Customer header
        val customerCard = card()
        val customer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        customer.addView(TextView(this).apply {
            text = notebookName; textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.END
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
        })
        if (notebookPhone.isNotBlank()) customer.addView(TextView(this).apply {
            text = notebookPhone; textSize = 11f; gravity = Gravity.END
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
        })
        customerCard.addView(customer)

        // Items table
        val itemsCard = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }
        head.addView(TextView(this).apply {
            text = "اقلام فاکتور"; textSize = 15f; setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        head.addView(TextView(this).apply {
            text = "تعداد  |  فی  |  مبلغ"; textSize = 9f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
        })
        itemsCard.addView(head)
        itemsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(10), dp(6))
        }
        itemsCard.addView(itemsContainer)

        val addItem = MaterialButton(this).apply {
            text = "+ افزودن کالا / خدمات"; textSize = 12f; cornerRadius = dp(13)
            insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.primary_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
            layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply {
                setMargins(dp(10), dp(4), dp(10), dp(10))
            }
            setOnClickListener { showAddItemDialog() }
        }
        itemsCard.addView(addItem)

        // Summary
        val summaryCard = card()
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        totalText = TextView(this).apply {
            text = "جمع کل: ۰ تومان"; textSize = 17f; gravity = Gravity.END
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
        }
        summary.addView(totalText)
        summary.addView(summaryLine("پیش‌پرداخت", true).first)
        summary.addView(summaryLine("مانده قابل پرداخت", false).first)
        summaryCard.addView(summary)

        // Kind
        val kindCard = card()
        val kindBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(9), dp(14), dp(9))
        }
        kindBox.addView(TextView(this).apply {
            text = "نحوه ثبت مانده در حساب"; textSize = 11f; gravity = Gravity.END
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
        })
        kindGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL; gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        kindDebt = RadioButton(this).apply {
            id = View.generateViewId(); text = "↑ پرداختی"; textSize = 12f
            layoutParams = RadioGroup.LayoutParams(0, dp(46), 1f)
        }
        kindCredit = RadioButton(this).apply {
            id = View.generateViewId(); text = "↓ دریافتی"; textSize = 12f
            layoutParams = RadioGroup.LayoutParams(0, dp(46), 1f)
        }
        kindGroup.addView(kindDebt); kindGroup.addView(kindCredit)
        kindGroup.check(kindDebt.id)
        kindBox.addView(kindGroup)
        kindCard.addView(kindBox)

        // Prepay
        val prepayCard = card()
        val prepayBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(9), dp(14), dp(9))
        }
        prepayBox.addView(label("پیش‌پرداخت"))
        prepayField = amountField("مثلاً ۵۰۰,۰۰۰")
        prepayBox.addView(prepayField, LinearLayout.LayoutParams(-1, dp(50)))
        prepayCard.addView(prepayBox)

        // Due date
        val dueCard = card()
        val dueBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(9))
        }
        val dueInfo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        dueInfo.addView(label("تاریخ سررسید"))
        dueDateField = TextView(this).apply {
            text = "بدون سررسید"; textSize = 14f; gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setPadding(0, dp(5), 0, dp(5))
        }
        dueInfo.addView(dueDateField)
        val dueBtn = MaterialButton(this).apply {
            text = "تقویم"; textSize = 11f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.primary_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
            setOnClickListener {
                promptJalaliDate(this@InvoiceActivity, if (dueDateField.text.toString() == "بدون سررسید") "" else dueDateField.text.toString()) {
                    dueDateField.text = it
                }
            }
        }
        val clearDue = MaterialButton(this).apply {
            text = "×"; textSize = 18f; minWidth = 0; insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            setOnClickListener { dueDateField.text = "بدون سررسید" }
        }
        dueBox.addView(dueInfo)
        dueBox.addView(dueBtn, LinearLayout.LayoutParams(dp(72), dp(44)))
        dueBox.addView(clearDue, LinearLayout.LayoutParams(dp(40), dp(44)))
        dueCard.addView(dueBox)

        // Note
        val noteCard = card()
        noteField = EditText(this).apply {
            hint = "شرح یا توضیحات فاکتور"
            textSize = 13f; gravity = Gravity.END
            minLines = 2; maxLines = 3
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setHintTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            background = null; setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        noteCard.addView(noteField)

        // Actions
        val save = MaterialButton(this).apply {
            text = if (editingInvoiceId == -1L) "ثبت فاکتور در حساب" else "ذخیره تغییرات"
            textSize = 13f; cornerRadius = dp(15)
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) }
            setOnClickListener { saveInvoice() }
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }
        val savePdf = MaterialButton(this).apply {
            text = "ذخیره PDF"; textSize = 12f; cornerRadius = dp(13); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_text))
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) }
            setOnClickListener { if (items.isEmpty()) toast("حداقل یک قلم اضافه کنید.") else savePdfLauncher.launch(defaultPdfName()) }
        }
        val share = MaterialButton(this).apply {
            text = "اشتراک"; textSize = 12f; cornerRadius = dp(13); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.primary_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(4) }
            setOnClickListener { if (items.isEmpty()) toast("حداقل یک قلم اضافه کنید.") else sharePdf() }
        }
        actions.addView(savePdf); actions.addView(share)

        inner.addView(customerCard)
        inner.addView(itemsCard)
        inner.addView(summaryCard)
        inner.addView(kindCard)
        inner.addView(prepayCard)
        inner.addView(dueCard)
        inner.addView(noteCard)
        inner.addView(save)
        inner.addView(actions)

        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        prepayField.addTextChangedListener(object : TextWatcher {
            private var busy = false
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                val digits = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).trimStart('0').ifEmpty { "" }
                val f = if (digits.isBlank()) "" else groupDigits(digits)
                if (e?.toString() != f) {
                    busy = true; setText(f); setSelection(text.length); busy = false
                }
                updateSummary()
            }
        })
    }

    private fun summaryLine(labelText: String, prepay: Boolean): Pair<LinearLayout, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(0))
        }
        val l = TextView(this).apply {
            text = labelText; textSize = 11f; setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val v = TextView(this).apply {
            text = "۰ تومان"; textSize = 12f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
        }
        row.addView(l); row.addView(v)
        if (prepay) prepaySummary = v else remainingSummary = v
        return row to v
    }

    private lateinit var prepaySummary: TextView
    private lateinit var remainingSummary: TextView

    private fun card() = MaterialCardView(this).apply {
        radius = dp(18).toFloat(); cardElevation = dp(1).toFloat()
        strokeWidth = dp(1)
        strokeColor = ContextCompat.getColor(this@InvoiceActivity, R.color.divider)
        setCardBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.surface))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 10f; gravity = Gravity.END
        setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
    }

    private fun amountField(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 15f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
        inputType = InputType.TYPE_CLASS_PHONE
        filters = arrayOf(InputFilter.LengthFilter(24))
        setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
        setHintTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
        background = bgInput()
        setPadding(dp(12), 0, dp(12), 0)
    }

    private fun bgInput() = android.graphics.drawable.GradientDrawable().apply {
        setColor(Color.WHITE); cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.rgb(189, 207, 202))
    }

    private fun refreshItems() {
        itemsContainer.removeAllViews()
        items.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(6), dp(7), dp(6), dp(7))
            }
            val name = TextView(this).apply {
                text = item.name; textSize = 12f; gravity = Gravity.END
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val detail = TextView(this).apply {
                text = "${item.qty} × ${groupDigits(item.unitPrice.toString())}"
                textSize = 10f; gravity = Gravity.CENTER
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(dp(105), -2)
            }
            val total = TextView(this).apply {
                text = groupDigits(item.total.toString()); textSize = 11f; gravity = Gravity.START
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
                layoutParams = LinearLayout.LayoutParams(dp(100), -2)
            }
            val edit = MaterialButton(this).apply {
                text = "ویرایش"; textSize = 9f; minWidth = 0; insetTop = 0; insetBottom = 0
                cornerRadius = dp(9); setPadding(dp(6), 0, dp(6), 0)
                layoutParams = LinearLayout.LayoutParams(dp(58), dp(34))
                backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.neutral_soft))
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
                setOnClickListener { showEditItemDialog(idx) }
            }
            val del = MaterialButton(this).apply {
                text = "×"; textSize = 17f; minWidth = 0; insetTop = 0; insetBottom = 0
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_text))
                setOnClickListener { items.removeAt(idx); refreshItems() }
            }
            row.addView(name); row.addView(detail); row.addView(total); row.addView(edit); row.addView(del)
            itemsContainer.addView(row)
            if (idx < items.lastIndex) itemsContainer.addView(View(this).apply {
                setBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.divider))
                layoutParams = LinearLayout.LayoutParams(-1, dp(1))
            })
        }
        updateSummary()
    }

    private fun updateSummary() {
        val total = items.sumOf { it.total }
        val prepay = normalizeDigits(prepayField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
        totalText.text = "جمع کل: ${groupDigits(total.toString())} تومان"
        prepaySummary.text = "${groupDigits(prepay.coerceAtMost(total).toString())} تومان"
        remainingSummary.text = "${groupDigits((total - prepay).coerceAtLeast(0L).toString())} تومان"
    }

    private fun showAddItemDialog() = showItemDialog(null)

    private fun showEditItemDialog(index: Int) = showItemDialog(index)

    private fun showItemDialog(index: Int?) {
        val old = index?.let { items[it] }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(4), dp(18), dp(4))
        }
        fun field(h: String, numeric: Boolean = false): EditText = EditText(this).apply {
            hint = h; textSize = 14f; gravity = if (numeric) Gravity.START else Gravity.END
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = bgInput()
            if (numeric) inputType = InputType.TYPE_CLASS_PHONE
        }
        val name = field("نام کالا / خدمات").apply { setText(old?.name.orEmpty()) }
        val qty = field("تعداد").apply { setText(old?.qty?.toString() ?: "1") }
        val price = field("قیمت واحد (تومان)", true).apply {
            setText(old?.unitPrice?.takeIf { it > 0 }?.let { groupDigits(it.toString()) }.orEmpty())
        }
        box.addView(name, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(gap(dp(7)))
        box.addView(qty, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(gap(dp(7)))
        box.addView(price, LinearLayout.LayoutParams(-1, dp(52)))

        price.addTextChangedListener(object : TextWatcher {
            private var busy = false
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                val digits = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).trimStart('0').ifEmpty { "" }
                val f = if (digits.isBlank()) "" else groupDigits(digits)
                if (e?.toString() != f) {
                    busy = true; price.setText(f); price.setSelection(price.text.length); busy = false
                }
            }
        })

        MaterialAlertDialogBuilder(this)
            .setTitle(if (index == null) "افزودن قلم فاکتور" else "ویرایش قلم")
            .setView(box)
            .setPositiveButton(if (index == null) "افزودن" else "ذخیره") { _, _ ->
                val n = name.text.toString().trim()
                val q = normalizeDigits(qty.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
                val p = normalizeDigits(price.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
                when {
                    n.isBlank() -> toast("نام کالا/خدمات را وارد کنید.")
                    q <= 0 -> toast("تعداد معتبر نیست.")
                    p <= 0 -> toast("قیمت معتبر نیست.")
                    else -> {
                        val item = InvoiceItem(name = n, qty = q, unitPrice = p, id = old?.id ?: 0L)
                        if (index == null) items.add(item) else items[index] = item
                        refreshItems()
                    }
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun saveInvoice() {
        if (items.isEmpty()) { toast("حداقل یک کالا یا خدمت اضافه کنید."); return }
        val total = items.sumOf { it.total }
        val prepay = normalizeDigits(prepayField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
        if (prepay > total) { toast("پیش‌پرداخت نمی‌تواند از جمع فاکتور بیشتر باشد."); return }
        val kind = if (kindGroup.checkedRadioButtonId == kindDebt.id) "debt" else "credit"
        val due = dueDateField.text.toString().takeUnless { it == "بدون سررسید" }.orEmpty()
        if (due.isNotBlank() && !Jalali.isValidDate(due)) { toast("تاریخ سررسید معتبر نیست."); return }
        val date = Jalali.now()
        val ok = if (editingInvoiceId == -1L) {
            db.saveInvoice(notebookId, kind, items, noteField.text.toString(), date, prepay, due) != -1L
        } else {
            db.updateInvoice(editingInvoiceId, notebookId, kind, items, noteField.text.toString(), prepay, due)
        }
        if (ok) {
            toast(if (editingInvoiceId == -1L) "فاکتور ثبت شد و مانده در ریز حساب ثبت شد." else "فاکتور و تراکنش مربوط به آن به‌روزرسانی شد.")
            setResult(RESULT_OK); finish()
        } else toast("ثبت فاکتور انجام نشد.")
    }

    private fun loadInvoice(id: Long) {
        val inv = db.invoices(notebookId).firstOrNull { it.id == id } ?: return
        editingInvoiceNumber = inv.number
        items.clear(); items.addAll(db.invoiceItems(id))
        prepayField.setText(if (inv.prepay > 0) groupDigits(inv.prepay.toString()) else "")
        dueDateField.text = if (inv.dueDate.isBlank()) "بدون سررسید" else inv.dueDate
        noteField.setText(inv.note)
        kindGroup.check(if (inv.kind == "credit") kindCredit.id else kindDebt.id)
        refreshItems()
    }

    private fun defaultPdfName(): String {
        val num = if (editingInvoiceNumber > 0) editingInvoiceNumber else db.nextInvoiceNumber(notebookId)
        return "فاکتور-${notebookName.replace("/","-")}-شماره$num.pdf"
    }

    private fun exportPdf(uri: Uri, shareAfter: Boolean) {
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        val num = if (editingInvoiceNumber > 0) editingInvoiceNumber else db.nextInvoiceNumber(notebookId)
        val due = dueDateField.text.toString().takeUnless { it == "بدون سررسید" }.orEmpty()
        InvoicePdfExporter.export(
            context = this, uri = uri, invoiceNumber = num,
            buyerName = notebookName, buyerPhone = notebookPhone,
            sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: "",
            sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "",
            sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "",
            sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: "",
            items = items, date = Jalali.now(), prepay = normalizeDigits(prepayField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L,
            dueDate = due,
            onDone = { if (!shareAfter) toast("فاکتور ذخیره شد.") }
        )
    }

    private fun sharePdf() {
        val temp = File(cacheDir, "hesabdar_invoice_${System.currentTimeMillis()}.pdf")
        val uri = Uri.fromFile(temp)
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        val num = if (editingInvoiceNumber > 0) editingInvoiceNumber else db.nextInvoiceNumber(notebookId)
        val due = dueDateField.text.toString().takeUnless { it == "بدون سررسید" }.orEmpty()
        InvoicePdfExporter.export(
            context = this, uri = uri, invoiceNumber = num,
            buyerName = notebookName, buyerPhone = notebookPhone,
            sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: "",
            sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "",
            sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "",
            sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: "",
            items = items, date = Jalali.now(),
            prepay = normalizeDigits(prepayField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L,
            dueDate = due,
            onDone = {
                try {
                    val shareUri = FileProvider.getUriForFile(this, "${packageName}.provider", temp)
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, shareUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "اشتراک فاکتور"))
                } catch (e: Exception) {
                    toast("اشتراک‌گذاری فاکتور انجام نشد.")
                }
            }
        )
    }

    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun normalizeDigits(value: String): String = value.map {
        when (it) {
            in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
            in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
            else -> it
        }
    }.joinToString("")

    private fun groupDigits(digits: String): String {
        val sb = StringBuilder()
        for ((i, c) in digits.filter(Char::isDigit).reversed().withIndex()) {
            if (i > 0 && i % 3 == 0) sb.append(',')
            sb.append(c)
        }
        return sb.reverse().toString()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
