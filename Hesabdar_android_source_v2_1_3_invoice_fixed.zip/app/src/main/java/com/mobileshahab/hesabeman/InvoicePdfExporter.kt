package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast

object InvoicePdfExporter {

    fun export(
        context: Context, uri: Uri, invoiceNumber: Int,
        buyerName: String, buyerPhone: String = "",
        sellerName: String, sellerAddress: String, sellerPhone: String, sellerSlogan: String,
        items: List<InvoiceItem>, date: String, prepay: Long = 0L, dueDate: String = "",
        onDone: (Uri) -> Unit
    ): Boolean {
        return try {
            val W = 595f; val H = 842f; val m = 36f
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), 1).create())
            val c = page.canvas

            val bold = Typeface.DEFAULT_BOLD
            val green = Color.rgb(0, 100, 80)
            val lightGreen = Color.rgb(220, 239, 229)
            val darkGray = Color.rgb(50, 50, 50)
            val medGray = Color.rgb(110, 110, 110)

            fun p(sz: Float, face: Typeface = Typeface.DEFAULT, col: Int = Color.BLACK, align: Paint.Align = Paint.Align.CENTER) =
                Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = sz; typeface = face; color = col; textAlign = align }

            fun fillRect(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
            fun strokeRect(col: Int, w: Float = 0.8f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = col; strokeWidth = w; style = Paint.Style.STROKE
            }
            fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, stroke: Int = 0) {
                c.drawRoundRect(RectF(l, t, r, b), rad, rad, fillRect(fill))
                if (stroke != 0) c.drawRoundRect(RectF(l, t, r, b), rad, rad, strokeRect(stroke, 1f))
            }

            var y = m

            // ══ HEADER ══
            rr(m, y, W - m, y + 84f, 14f, green)
            c.drawText(sellerName.ifBlank { "فاکتور فروش" }, W / 2f, y + 36f, p(26f, bold, Color.WHITE))
            if (sellerSlogan.isNotBlank())
                c.drawText(sellerSlogan, W / 2f, y + 58f, p(11f, col = Color.rgb(190, 230, 210)))
            y += 94f

            // ══ INVOICE INFO ══
            val infoH = if (dueDate.isBlank()) 36f else 52f
            rr(m, y, W - m, y + infoH, 8f, lightGreen, green)
            c.drawText("فاکتور شماره: $invoiceNumber", W - m - 10f, y + 20f, p(12f, bold, green, Paint.Align.RIGHT))
            c.drawText("تاریخ: $date", m + 10f, y + 20f, p(12f, bold, green, Paint.Align.LEFT))
            if (dueDate.isNotBlank())
                c.drawText("سررسید: $dueDate", m + 10f, y + 38f, p(10f, bold, green, Paint.Align.LEFT))
            y += infoH + 10f

            // ══ BUYER / SELLER CARDS ══
            val halfW = (W - 2 * m - 12f) / 2f
            val infoLines = listOf(sellerPhone, sellerAddress).count { it.isNotBlank() }
            val buyerLines = listOf(buyerPhone).count { it.isNotBlank() }
            val cardH = 42f + maxOf(infoLines, buyerLines) * 14f

            for ((x, label, name, phone, address) in listOf(
                D5(m, "فروشنده", sellerName.ifBlank { "—" }, sellerPhone, sellerAddress),
                D5(m + halfW + 12f, "خریدار", buyerName, buyerPhone, "")
            )) {
                rr(x, y, x + halfW, y + cardH, 10f, lightGreen, green)
                c.drawRect(x, y + cardH / 2f, x + halfW, y + cardH, fillRect(lightGreen))
                rr(x, y, x + halfW, y + 22f, 10f, green)
                c.drawRect(x, y + 12f, x + halfW, y + 22f, fillRect(green))
                c.drawText(label, x + halfW / 2f, y + 15f, p(10f, bold, Color.WHITE))
                c.drawText(name, x + halfW / 2f, y + 34f, p(11f, bold, darkGray))
                var cy = y + 48f
                if (phone.isNotBlank()) { c.drawText(phone, x + halfW / 2f, cy, p(9f, col = medGray)); cy += 14f }
                if (address.isNotBlank()) c.drawText(address, x + halfW / 2f, cy, p(9f, col = medGray))
            }
            y += cardH + 16f

            // ══ ITEMS TABLE (RTL: ردیف | شرح | مقدار | فی | جمع) ══
            // Column x positions on canvas (items drawn right-to-left reading order)
            val cRowNo  = m + 20f          // ردیف — leftmost on page but rightmost in RTL
            val cDesc   = m + 44f          // شرح کالا — right-aligned text within column
            val cDescEnd = W - m - 200f
            val cQty    = W - m - 155f
            val cPrice  = W - m - 90f
            val cTotal  = W - m - 10f

            // Header
            rr(m, y, W - m, y + 24f, 6f, green)
            val hy = y + 16f
            c.drawText("ردیف", cRowNo + 6f, hy, p(9f, bold, Color.WHITE, Paint.Align.LEFT))
            c.drawText("شرح کالا / خدمات", (m + 44f + (W - m - 200f)) / 2f, hy, p(9f, bold, Color.WHITE))
            c.drawText("تعداد", cQty, hy, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("فی (تومان)", cPrice, hy, p(9f, bold, Color.WHITE, Paint.Align.CENTER))
            c.drawText("جمع", cTotal, hy, p(9f, bold, Color.WHITE, Paint.Align.RIGHT))
            y += 26f

            val tableTop = y
            items.forEachIndexed { idx, item ->
                val rh = 26f
                c.drawRect(m, y, W - m, y + rh, fillRect(if (idx % 2 == 0) Color.WHITE else Color.rgb(245, 250, 247)))
                val ry = y + 17f
                // ردیف
                c.drawText("${idx + 1}", cRowNo + 6f, ry, p(9f, col = darkGray, align = Paint.Align.LEFT))
                // شرح — right aligned within its column
                c.drawText(if (item.name.length > 26) item.name.take(26) + "…" else item.name,
                    cDescEnd - 4f, ry, p(9f, col = darkGray, align = Paint.Align.RIGHT))
                // تعداد — centered
                c.drawText("${item.qty}", cQty, ry, p(9f, col = darkGray, align = Paint.Align.CENTER))
                // فی — centered
                c.drawText("%,d".format(item.unitPrice), cPrice, ry, p(9f, col = darkGray, align = Paint.Align.CENTER))
                // جمع — right
                c.drawText("%,d".format(item.total), cTotal, ry, p(9f, col = darkGray, align = Paint.Align.RIGHT))
                c.drawLine(m, y + rh, W - m, y + rh, Paint().apply { color = Color.rgb(200, 220, 210); strokeWidth = 0.5f })
                y += rh
            }
            // Table border
            c.drawRect(m, tableTop - 26f, W - m, y, strokeRect(Color.rgb(160, 200, 180), 1f))
            y += 10f

            // ══ TOTALS ══
            val grandTotal = items.sumOf { it.total }
            val totalQty = items.sumOf { it.qty }
            val remaining = (grandTotal - prepay).coerceAtLeast(0L)
            data class TRow(val label: String, val value: String, val highlight: Boolean = false)
            val rows = mutableListOf(
                TRow("جمع کل", "%,d".format(grandTotal)),
                TRow("جمع اقلام (تعداد کل)", "$totalQty عدد")
            )
            if (prepay > 0) rows.add(TRow("پیش‌پرداخت", "%,d".format(prepay)))
            rows.add(TRow("مانده قابل پرداخت", "%,d".format(remaining), true))

            rows.forEach { (label, value, hl) ->
                val bg = if (hl) Color.rgb(195, 235, 215) else lightGreen
                rr(m + 80f, y, W - m, y + 22f, 5f, bg)
                c.drawText(value, m + 220f, y + 15f, p(10f, if (hl) bold else Typeface.DEFAULT, if (hl) green else darkGray, Paint.Align.CENTER))
                c.drawText(label, W - m - 8f, y + 15f, p(10f, bold, darkGray, Paint.Align.RIGHT))
                c.drawLine(m + 80f, y + 22f, W - m, y + 22f, Paint().apply { color = Color.rgb(180, 215, 195); strokeWidth = 0.5f })
                y += 24f
            }
            y += 8f

            // ══ AMOUNT IN WORDS ══
            rr(m, y, W - m, y + 24f, 6f, lightGreen, green)
            c.drawText("مانده قابل پرداخت: %,d تومان".format(remaining), W / 2f, y + 16f, p(10f, bold, green))
            y += 34f

            // ══ SIGNATURE ══
            val sigW = (W - 2 * m - 12f) / 2f
            for ((x, label) in listOf(m to "امضا فروشنده", m + sigW + 12f to "امضا خریدار")) {
                rr(x, y, x + sigW, y + 60f, 10f, lightGreen, green)
                rr(x, y, x + sigW, y + 22f, 10f, green)
                c.drawRect(x, y + 12f, x + sigW, y + 22f, fillRect(green))
                c.drawText(label, x + sigW / 2f, y + 15f, p(10f, bold, Color.WHITE))
            }

            doc.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Cannot open output")
            doc.close()
            Toast.makeText(context, "فاکتور PDF ذخیره شد.", Toast.LENGTH_LONG).show()
            onDone(uri)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ساخت PDF: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private data class D5(val x: Float, val label: String, val name: String, val phone: String, val address: String)
}
