# حسابدار شخصی v1.1.0 - نقشه پیاده‌سازی و آزمایش

## ✅ مرحله ۱: تکمیل شده

### Database Schema Update (v1 → v3)
- ✅ DATABASE_VERSION به ۳ افزایش یافت
- ✅ جدول `notes` اضافه شد:
  ```
  id (INTEGER PRIMARY KEY)
  title (TEXT NOT NULL)
  body (TEXT NOT NULL)
  created_at (TEXT NOT NULL)
  reminder_date (TEXT)
  reminder_time (TEXT)
  ```
- ✅ Migration logic برای v2 → v3 آماده (onUpgrade)
- ✅ Data class `Note` اضافه شد
- ✅ متدهای CRUD برای notes پیاده‌سازی شد:
  - `createNote(title, body, reminderDate, reminderTime)`
  - `updateNote(id, ...)`
  - `deleteNote(id)`
  - `getNotes()`
  - `getNoteById(id)`
  - `getNotesWithReminder()`

### 5-Folder System
- ✅ پوشه پنجم "یادداشت‌ها" به onCreate اضافه شد
- ✅ Migration برای اضافه‌کردن پوشه به برنامه‌های قبلی آماده

### Backup/Restore System - Enhanced Safety
- ✅ RestoreSelected method بازنویسی شد:
  - Support برای .hbak (ZIP archive) files
  - Support برای legacy .db files
  - Validation قبل از restore (تشخیص آسیب یا incompatibility)
  - Emergency backup قبل از جایگزینی (*.before_restore)
  - Confirmation dialog in Persian
  - بررسی جداول اصلی (folders, notebooks, tx)

### Version Update
- ✅ versionCode: 9 → 10
- ✅ versionName: "1.0.9" → "1.1.0"

---

## 📝 مرحله ۲: در دست انجام (نیاز به اجرا)

### A. Notes Activity & UI
```kotlin
class NotesActivity : BaseActivity() {
    // Display notes in 3-column grid
    // Material cards with newest first
    // Support RTL
    // Light/dark mode
}
```

**فایل‌های مورد نیاز:**
- `NotesActivity.kt` (ساخت)
- `NotesAdapter.kt` (ساخت)
- `activity_notes.xml` (ساخت)
- `note_card.xml` (ساخت)

**قابلیت‌های مورد نیاز:**
- RecyclerView with 3-column GridLayout
- Sort by created_at DESC
- Material Cards
- RTL support
- FAB button for new note
- Long-click options (edit, delete)

### B. New Note Dialog
```kotlin
// Inside NotesActivity or as DialogFragment
// Fields:
// - عنوان یادداشت
// - متن یادداشت
// - تاریخ یادآوری (optional)
// - ساعت یادآوری (optional)
// 
// Date picker: Jalali/Shamsi format
// Time picker: HH:mm
// Colors for note (optional)
```

### C. Backup Share Feature
**Update SettingsActivity:**
- Add "صدور بکاپ به فرمت .hbak" button
- Implement createHbakBackup():
  ```
  Hesabdar_Backup_YYYY-MM-DD.hbak
  ├── hesabdar_database.db
  ├── hesabdar_database_previous.db (if exists)
  └── backup_info.json (metadata)
  ```
- Use FileProvider for shareability
- Open Android Sharesheet
- Support for Telegram, WhatsApp, Email, Drive, etc.

### D. Manual Backup Button
- Add new section in Settings: "پشتیبان‌گیری و اشتراک‌گذاری اطلاعات"
- Create backup → show location in Downloads
- Option to share

### E. Reminder Implementation
- WorkManager integration (or AlarmManager)
- Receiver for notification
- Reschedule on boot
- Persian notification text
- Support Jalali date/time

### F. UI Improvements
- **Settings buttons**: Increase height to 52dp, font to 14sp
- **Account dialog**: Use Material modern style
- **Transaction dialog**: Larger fields, better spacing
- **Startup message**: Red warning about old backups
- **Folder colors**: Implement color picker for folder customization
- **Notes colors**: Optional color selection for notes

### G. Light/Dark Mode Support
Check and fix:
- Settings activity
- Notes activity
- New note dialog
- Backup dialogs
- Colors in activity_main.xml
- Use theme-aware colors (avoid hardcoding)

---

## 🔧 مرحله ۳: تصحیح و تست

### Installation/Update Issue
Currently requires uninstalling before updating.

**Root causes to investigate:**
1. Check signing configuration consistency
2. Verify applicationId is unchanged
3. Check versionCode increments properly
4. Review debug/release keystore setup

**Solution:**
- For debug builds: No action needed (debug keystore auto-regenerates)
- For release builds: Use stable signing keystore
- Document keystore location and password

### Backward Compatibility
- ✅ Old backup files (v1, v2) are restorable with validation
- ✅ Migration from v2 to v3 is safe (no data loss)
- ✅ Existing folders/notebooks/transactions preserved

---

## 🧪 تست فاز۱: Database & Restore

```bash
# Step 1: Build and install
./gradlew clean build
adb install -r app/build/outputs/apk/debug/app-debug.apk

# Step 2: Create test data in app
- Add 2-3 folders
- Add 5-10 accounts
- Add 50+ transactions
- Create backup (auto-generated)

# Step 3: Test restore
- Copy backup file to phone
- Settings → بازیابی بکاپ قدیمی
- Select .db or .hbak file
- Verify data restores correctly

# Step 4: Test notes
- Add 5-10 notes
- Verify created_at is stored correctly
- Verify getNototes() returns them in DESC order
```

---

## 🧪 تست فاز۲: UI & Features

```
Test Checklist:
□ Notes screen displays notes correctly (3-column grid)
□ Newest notes appear first
□ Card layout is clean and readable
□ RTL text is correct
□ Light mode: readable text/backgrounds
□ Dark mode: readable text/backgrounds
□ FAB button appears and works
□ Can create new note
□ Can edit existing note
□ Can delete note
□ Reminder date/time picker works
□ Can share backup
□ Settings buttons are larger and bold
```

---

## 🚀 تست فاز۳: Complete App

```
Full App Test:
□ Install fresh (v1.1.0)
□ Run onUpgrade path (simulate old db)
□ Add folders/accounts/transactions
□ Add notes with reminders
□ Create manual backup
□ Export & share backup
□ Delete app data
□ Restore from backup
□ Verify all data is correct
□ Test light/dark mode
□ Check app doesn't require re-install for updates
```

---

## 📋 چک لیست ساخت Final Release

- [ ] DbHelper compiles without errors
- [ ] SettingsActivity compiles
- [ ] NotesActivity created & integrated
- [ ] All UI screens tested in light/dark mode
- [ ] Restore from old backups works
- [ ] Migration from v2 to v3 works
- [ ] Reminders implemented & tested
- [ ] Backup sharing tested
- [ ] No breaking changes to existing data
- [ ] versionCode incremented
- [ ] Ready for production release

---

## 🔗 فایل‌های تغییر یافته

```
✅ Completed:
- app/src/main/java/com/mobileshahab/hesabeman/DbHelper.kt
  * DATABASE_VERSION = 3
  * Note data class
  * notes table in onCreate
  * migration in onUpgrade
  * CRUD methods for notes

- app/src/main/java/com/mobileshahab/hesabeman/SettingsActivity.kt
  * Safe restore with validation
  * .hbak support
  * Emergency backup (.before_restore)
  * Better error messages in Persian

- app/build.gradle.kts
  * versionCode = 10
  * versionName = "1.1.0"

📝 Still needed:
- NotesActivity.kt (new)
- NotesAdapter.kt (new)
- activity_notes.xml (new)
- note_card.xml (new)
- Reminder implementation
- Backup share feature
- UI improvements
- Light/dark mode fixes
```

---

## 🎯 اولویت بعدی

1. **NotesActivity** - ضروری
2. **Reminder system** - ضروری
3. **Backup share** - مهم
4. **UI improvements** - بهتری
5. **Settings redesign** - بهتری
6. **Installation fix** - بهتری

---

## 📞 نکات مهم

### Data Safety
- کل restore system درون try-catch است
- Emergency backup قبل از هر restore
- اگر restore ناموفق باشد، database بی‌دست‌خوری می‌ماند
- Validation قبل از restore

### Backward Compatibility
- v1 backups → v3 مهاجر می‌شوند
- v2 backups → v3 مهاجر می‌شوند
- تمام داده‌های موجود محفوظ می‌مانند

### Testing Checklist
- [ ] Fresh install (no DB)
- [ ] Upgrade from v1.0.9
- [ ] Restore old backup v1
- [ ] Restore old backup v2
- [ ] Full restore cycle (backup → restore)
- [ ] Light mode
- [ ] Dark mode
- [ ] RTL text
