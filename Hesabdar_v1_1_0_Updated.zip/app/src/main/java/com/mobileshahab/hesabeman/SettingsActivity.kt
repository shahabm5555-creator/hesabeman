package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.biometric.BiometricManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivitySettingsBinding
import android.database.sqlite.SQLiteDatabase
import java.util.zip.ZipFile

class SettingsActivity : BaseActivity() {
    private lateinit var b: ActivitySettingsBinding
    private lateinit var db: DbHelper
    private val PICK_BACKUP = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater); setContentView(b.root); db = DbHelper(this)
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material); b.toolbar.setNavigationOnClickListener { finish() }
        b.about.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }

        // ── Seller info for invoice ──
        val prefs = AppPrefs.prefs(this)
        // Clear the old placeholder defaults from previous versions while keeping real user data.
        val storedName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: ""
        val cleanName = if (storedName == "شغل من" || storedName == "شغل و کسب کار") "" else storedName
        b.sellerName.setText(cleanName)
        val storedAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: ""
        val storedPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: ""
        val cleanAddress = if (storedAddress == "آدرس من") "" else storedAddress
        val cleanPhone = if (storedPhone == "09123456789") "" else storedPhone
        b.sellerAddress.setText(cleanAddress)
        b.sellerPhone.setText(cleanPhone)
        b.sellerSlogan.setText(prefs.getString(AppPrefs.SELLER_SLOGAN, "با تشکر از خرید شما"))
        b.saveSellerInfo.setOnClickListener {
            prefs.edit()
                .putString(AppPrefs.SELLER_NAME, b.sellerName.text.toString().trim())
                .putString(AppPrefs.SELLER_ADDRESS, b.sellerAddress.text.toString().trim())
                .putString(AppPrefs.SELLER_PHONE, b.sellerPhone.text.toString().trim())
                .putString(AppPrefs.SELLER_SLOGAN, b.sellerSlogan.text.toString().trim())
                .apply()
            android.widget.Toast.makeText(this, "اطلاعات فروشنده ذخیره شد.", android.widget.Toast.LENGTH_SHORT).show()
        }
        b.archive.setOnClickListener { showArchive() }
        b.trash.setOnClickListener { showTrash() }
        b.monthlyReport.setOnClickListener { askMonthlyReport() }
        b.restoreBackup.setOnClickListener { pickBackup() }

        // Core two-slot data-center synchronization is mandatory for data safety.
        when (prefs.getString(AppPrefs.LOCK_MODE, "off")) { "pin" -> b.lockPin.isChecked = true; "biometric" -> b.lockBiometric.isChecked = true; else -> b.lockOff.isChecked = true }
        b.lockGroup.setOnCheckedChangeListener { _, id -> when (id) { R.id.lockOff -> prefs.edit().putString(AppPrefs.LOCK_MODE, "off").apply(); R.id.lockPin -> requestPin(); R.id.lockBiometric -> enableBiometric() } }
    }


    private fun pickBackup() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { 
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/octet-stream", "application/x-sqlite3"))
        }
        startActivityForResult(i, PICK_BACKUP)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_BACKUP && resultCode == RESULT_OK) {
            data?.data?.let { restoreSelected(it) }
        }
    }

    private fun restoreSelected(uri: Uri) {
        try {
            val fileName = getFileName(uri)
            val isHbak = fileName.endsWith(".hbak", ignoreCase = true)
            
            MaterialAlertDialogBuilder(this)
                .setTitle("بازیابی بکاپ")
                .setMessage("اطلاعات فعلی با اطلاعات موجود در بکاپ جایگزین خواهد شد.\nقبل از ادامه یک نسخه پشتیبان از اطلاعات فعلی نگهداری می‌شود.")
                .setPositiveButton("ادامه") { _, _ -> doRestore(uri, isHbak) }
                .setNegativeButton("انصراف", null)
                .show()
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در انتخاب فایل بکاپ", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = ""
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) name = it.getString(it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME))
            }
        } else if (uri.scheme == "file") {
            name = File(uri.path ?: "").name
        }
        return name
    }

    private fun doRestore(uri: Uri, isHbak: Boolean) {
        try {
            DbHelper.closeAll()
            val dbFile = getDatabasePath(DbHelper.DB_NAME)
            val tempFile = getDatabasePath(DbHelper.DB_NAME + ".restore_temp")
            val emergencyBackup = File(dbFile.path + ".before_restore")
            
            // Create emergency backup of current database
            if (dbFile.exists()) dbFile.copyTo(emergencyBackup, true)
            
            // Copy input to temp location and validate
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output -> input.copyTo(output) }
            }
            
            // Validate the backup file
            if (!isValidBackupFile(tempFile)) {
                tempFile.delete()
                android.widget.Toast.makeText(this, "فایل بکاپ معتبر نیست یا تخریب‌شده است", android.widget.Toast.LENGTH_LONG).show()
                return
            }
            
            if (isHbak) {
                // Extract database from .hbak archive
                if (!extractHbakDatabase(tempFile, dbFile)) {
                    tempFile.delete()
                    // Restore from emergency backup
                    if (emergencyBackup.exists()) emergencyBackup.copyTo(dbFile, true)
                    android.widget.Toast.makeText(this, "خطا در استخراج بکاپ", android.widget.Toast.LENGTH_LONG).show()
                    return
                }
            } else {
                // Direct .db file restore
                if (!tempFile.renameTo(dbFile)) {
                    tempFile.delete()
                    if (emergencyBackup.exists()) emergencyBackup.copyTo(dbFile, true)
                    android.widget.Toast.makeText(this, "خطا در بازیابی بکاپ", android.widget.Toast.LENGTH_LONG).show()
                    return
                }
            }
            
            tempFile.delete()
            android.widget.Toast.makeText(this, "بکاپ بازیابی شد. برنامه را دوباره باز کنید.", android.widget.Toast.LENGTH_LONG).show()
            
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در بازیابی بکاپ: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun isValidBackupFile(file: File): Boolean {
        if (!file.exists() || file.length() < 4096) return false
        return try {
            SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY).use { db ->
                val tables = mutableListOf<String>()
                db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                    while (c.moveToNext()) tables += c.getString(0)
                }
                // Check for core tables
                val required = setOf("folders", "notebooks", "tx")
                tables.containsAll(required)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun extractHbakDatabase(hbakFile: File, outputDbFile: File): Boolean {
        return try {
            java.util.zip.ZipFile(hbakFile).use { zip ->
                val entry = zip.getEntry("hesabdar_database.db") ?: return false
                zip.getInputStream(entry).use { input ->
                    FileOutputStream(outputDbFile).use { output ->
                        input.copyTo(output)
                    }
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun showArchive() {
        val items = db.archivedNotebooks()
        if (items.isEmpty()) { Toast.makeText(this, "آرشیو خالی است.", Toast.LENGTH_SHORT).show(); return }
        MaterialAlertDialogBuilder(this).setTitle("آرشیو حساب‌ها").setItems(items.map { it.title }.toTypedArray()) { _, which ->
            val item = items[which]
            MaterialAlertDialogBuilder(this).setTitle(item.title).setMessage("این حساب به لیست فعال برگردد؟")
                .setPositiveButton("بازیابی") { _, _ -> if (db.restoreArchivedNotebook(item.id)) Toast.makeText(this, "حساب بازیابی شد.", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "ظرفیت پوشه تکمیل است و حساب بازیابی نشد.", Toast.LENGTH_LONG).show() }
                .setNegativeButton("انصراف", null).show()
        }.show()
    }

    private fun showTrash() {
        db.purgeExpiredTrash()
        val accountItems = db.trashItems()
        val invoiceItems = db.trashInvoices()
        val installmentItems = db.trashInstallmentPlans()
        val txItems = db.trashTx()
        val checkItems = db.trashChecks()
        if (accountItems.isEmpty() && invoiceItems.isEmpty() && installmentItems.isEmpty() && txItems.isEmpty() && checkItems.isEmpty()) {
            Toast.makeText(this, "سطل زباله خالی است.", Toast.LENGTH_SHORT).show()
            return
        }

        data class TrashChoice(val type: String, val id: Long, val title: String, val deletedAt: Long)
        val choices = mutableListOf<TrashChoice>()
        accountItems.forEach { choices += TrashChoice(it.type, it.id, it.title, it.deletedAt) }
        invoiceItems.forEach {
            choices += TrashChoice("invoice", it.id, "فاکتور شماره ${it.number}", it.deletedAt ?: System.currentTimeMillis())
        }
        installmentItems.forEach {
            choices += TrashChoice("installment", it.id, "فاکتور اقساط: ${it.description}", it.deletedAt ?: System.currentTimeMillis())
        }
        txItems.forEach {
            val kind = if (it.kind == "debt") "پرداخت" else "دریافت"
            choices += TrashChoice("tx", it.id, "ریز تراکنش: $kind ${"%,d".format(it.amount)} تومان", it.deletedAt)
        }
        checkItems.forEach {
            val kind = if (it.kind == "debt") "چک پرداختی" else "چک دریافتی"
            choices += TrashChoice("check", it.id, "$kind — ${"%,d".format(it.amount)} تومان", it.deletedAt)
        }
        choices.sortByDescending { it.deletedAt }

        val now = System.currentTimeMillis()
        val labels = choices.map {
            val daysLeft = ((5L * 24L * 60L * 60L * 1000L - (now - it.deletedAt))
                .coerceAtLeast(0L) / (24L * 60L * 60L * 1000L)) + 1
            "${it.title} — $daysLeft روز مانده"
        }.toTypedArray()

        MaterialAlertDialogBuilder(this)
            .setTitle("سطل زباله · ۵ روز")
            .setItems(labels) { _, which ->
                val item = choices[which]
                MaterialAlertDialogBuilder(this)
                    .setTitle("بازیابی")
                    .setMessage("${item.title} بازیابی شود؟")
                    .setPositiveButton("بازیابی") { _, _ ->
                        val ok = when (item.type) {
                            "invoice" -> db.restoreInvoice(item.id)
                            "installment" -> db.restoreInstallmentPlan(item.id)
                            "tx" -> db.restoreTx(item.id)
                            "check" -> db.restoreCheck(item.id)
                            else -> db.restoreTrash(TrashItem(item.id, item.type, item.title, item.deletedAt))
                        }
                        Toast.makeText(
                            this,
                            if (ok) "بازیابی شد." else "بازیابی انجام نشد.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .setNegativeButton("انصراف", null)
                    .show()
            }.show()
    }

    private fun askMonthlyReport() {
        val current = Jalali.now().substringBefore("/") + "/" + Jalali.now().split("/").getOrElse(1) { "01" }
        val input = EditText(this).apply { hint = "مثال: 1405/05"; setText(current); textSize = 18f }
        MaterialAlertDialogBuilder(this).setTitle("گزارش ماهانه").setMessage("سال و ماه شمسی را وارد کنید.").setView(input)
            .setPositiveButton("نمایش") { _, _ -> showMonthlyReport(input.text.toString().trim()) }.setNegativeButton("انصراف", null).show()
    }

    private fun showMonthlyReport(month: String) {
        val r = db.monthlySummary(month); val balance = r.credit - r.debt
        val text = "ماه: $month\n\nکل پرداخت کردم: ${"%,d".format(r.debt)} تومان\nکل دریافت کردم: ${"%,d".format(r.credit)} تومان\nمانده: ${"%,d".format(kotlin.math.abs(balance))} تومان ${if (balance < 0) "بدهکار" else if (balance > 0) "بستانکار" else "تسویه"}\nتعداد تراکنش‌ها: ${r.txCount}"
        MaterialAlertDialogBuilder(this).setTitle("گزارش ماهانه").setMessage(text).setPositiveButton("باشه", null).show()
    }

    private fun requestPin() {
        val input = EditText(this).apply { hint = "رمز ۴ رقمی"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; maxLines = 1; autoInputDirection() }
        MaterialAlertDialogBuilder(this).setTitle("تنظیم رمز برنامه").setMessage("یک رمز ۴ رقمی وارد کنید.").setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                val pin = input.text.toString()
                if (pin.length == 4 && pin.all { it.isDigit() }) { AppPrefs.prefs(this).edit().putString(AppPrefs.PIN_HASH, AppPrefs.hashPin(pin)).putString(AppPrefs.LOCK_MODE, "pin").apply(); Toast.makeText(this, "قفل با رمز فعال شد.", Toast.LENGTH_SHORT).show() }
                else { b.lockOff.isChecked = true; Toast.makeText(this, "رمز باید دقیقاً ۴ رقم باشد.", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("انصراف") { _, _ -> b.lockOff.isChecked = true }.setOnCancelListener { b.lockOff.isChecked = true }.show()
    }

    private fun enableBiometric() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) { AppPrefs.prefs(this).edit().putString(AppPrefs.LOCK_MODE, "biometric").apply(); Toast.makeText(this, "قفل اثر انگشت فعال شد.", Toast.LENGTH_SHORT).show() }
        else { b.lockOff.isChecked = true; Toast.makeText(this, "اثر انگشت در این دستگاه آماده نیست.", Toast.LENGTH_LONG).show() }
    }
}
