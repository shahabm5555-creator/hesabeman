# Hesabeman 1.0.13 - Build Fix

این نسخه از سورس 1.0.13 ساخته شده است.

## مشکل Build
نسخه قبلی در GitHub Actions پروژه را داخل پوشه `project` استخراج می‌کرد و به Gradle مسیر `-p project` می‌داد. برای کم کردن نقاط خطا، این workflow مستقیماً از ریشه پروژه Build می‌کند و دیگر ZIP را داخل پروژه استخراج نمی‌کند.

Gradle 8.9 و JDK 17 استفاده می‌شوند و Android SDK 35 نصب می‌شود.

## GitHub Actions
فایل:
`.github/workflows/android-debug.yml`

بعد از Push به `main` یا اجرای دستی workflow، APK در Artifacts با نام `hesabeman-1.0.13-debug` قرار می‌گیرد.

## نکته
`gradle-wrapper.properties` نیز اضافه شده است. Workflow عمداً از Gradle نصب‌شده توسط `gradle/actions/setup-gradle` استفاده می‌کند تا نبودن `gradle-wrapper.jar` باعث شکست Build نشود.
