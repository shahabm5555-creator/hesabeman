package com.mobileshahab.hesabeman

import android.content.Context
import android.content.res.ColorStateList
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TimePicker
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

private fun normalizeDigits(value: String): String = value.map {
    when (it) {
        in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
        else -> it
    }
}.joinToString("")

private fun formatAmountInput(value: String): String {
    val digits = normalizeDigits(value).filter(Char::isDigit).trimStart('0').ifEmpty { "0" }
    return try { "%,d".format(digits.toLong()) } catch (_: Exception) { digits }
}

private fun attachDateFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(8)
            val formatted = buildString {
                raw.forEachIndexed { i, ch ->
                    if (i == 4 || i == 6) append('/')
                    append(ch)
                }
            }
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

private fun attachTimeFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(4)
            val formatted = if (raw.length > 2) raw.substring(0, 2) + ":" + raw.substring(2) else raw
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint; textDirection = View.TEXT_DIRECTION_RTL; textSize = 18f; setPadding(36, 28, 36, 28)
    }
    MaterialAlertDialogBuilder(context).setTitle(title).setView(input)
        .setPositiveButton("ثبت") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
    val name = EditText(context).apply { hint = "نام شخص / حساب"; textSize = 18f; minHeight = 60 }
    val phone = EditText(context).apply { hint = "شماره موبایل (اختیاری)"; inputType = InputType.TYPE_CLASS_PHONE; textSize = 18f; minHeight = 60 }
    box.addView(name); box.addView(phone)
    MaterialAlertDialogBuilder(context).setTitle("حساب جدید").setMessage("شماره موبایل برای تماس و ارسال مانده حساب استفاده می‌شود.").setView(box)
        .setPositiveButton("ثبت") { _, _ -> name.text.toString().trim().takeIf { it.isNotEmpty() }?.let { done(it, normalizeDigits(phone.text.toString().trim())) } }
        .setNegativeButton("انصراف", null).show()
}

fun promptOrder(context: Context, title: String, current: Int, max: Int, done: (Int) -> Unit) {
    val input = EditText(context).apply {
        hint = "شماره ردیف از ۱ تا $max"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 18f; minHeight = 60
        setText(current.toString()); selectAll()
    }
    MaterialAlertDialogBuilder(context).setTitle(title)
        .setMessage("ردیف جدید را وارد کنید؛ موارد دیگر خودکار جابه‌جا می‌شوند.")
        .setView(input)
        .setPositiveButton("انتقال") { _, _ -> input.text.toString().toIntOrNull()?.takeIf { it in 1..max }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptTransaction(
    context: Context,
    title: String,
    initialKind: String = "debt",
    initialAmount: Long? = null,
    initialNote: String = "",
    initialDateTime: String = Jalali.now(),
    done: (String, Long, String, String) -> Unit
) {
    val box = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 4, 22, 8)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        clipToPadding = false
    }

    val typeGroup = RadioGroup(context).apply {
        orientation = RadioGroup.HORIZONTAL
        gravity = android.view.Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(0, 2, 0, 4)
    }

    val debtRadio = RadioButton(context).apply {
        id = View.generateViewId()
        text = "پرداخت کردم"
        textSize = 13f
        minHeight = 44
        minWidth = 0
        includeFontPadding = false
        gravity = android.view.Gravity.CENTER_VERTICAL
        setPadding(10, 0, 10, 0)
        textDirection = View.TEXT_DIRECTION_RTL
        background = context.getDrawable(R.drawable.bg_transaction_choice)
        buttonTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(context.getColor(R.color.debt_text), context.getColor(R.color.secondary))
        )
    }
    val creditRadio = RadioButton(context).apply {
        id = View.generateViewId()
        text = "دریافت کردم"
        textSize = 13f
        minHeight = 44
        minWidth = 0
        includeFontPadding = false
        gravity = android.view.Gravity.CENTER_VERTICAL
        setPadding(10, 0, 10, 0)
        textDirection = View.TEXT_DIRECTION_RTL
        background = context.getDrawable(R.drawable.bg_transaction_choice)
        buttonTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(context.getColor(R.color.credit_text), context.getColor(R.color.secondary))
        )
    }
    typeGroup.addView(debtRadio, RadioGroup.LayoutParams(0, 44, 1f).apply { marginStart = 4; marginEnd = 4 })
    typeGroup.addView(creditRadio, RadioGroup.LayoutParams(0, 44, 1f).apply { marginStart = 4; marginEnd = 4 })
    typeGroup.check(if (initialKind == "credit") creditRadio.id else debtRadio.id)

    val amount = EditText(context).apply {
        hint = "مبلغ به تومان"
        inputType = InputType.TYPE_CLASS_NUMBER
        textSize = 16f
        minHeight = 48
        includeFontPadding = false
        gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END
        textDirection = View.TEXT_DIRECTION_LTR
        background = context.getDrawable(R.drawable/bg_transaction_field)
        setPadding(16, 0, 16, 0)
        filters = arrayOf(InputFilter.LengthFilter(18))
        setText(initialAmount?.let { "%,d".format(it) } ?: "")
        setSelection(text.length)
        addTextChangedListener(object : TextWatcher {
            private var busy = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                val formatted = formatAmountInput(e?.toString().orEmpty())
                if (e?.toString() != formatted) {
                    busy = true
                    setText(formatted)
                    setSelection(text.length)
                    busy = false
                }
            }
        })
    }

    val note = EditText(context).apply {
        hint = "توضیحات"
        textSize = 14f
        minHeight = 44
        includeFontPadding = false
        setSingleLine(true)
        gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END
        textDirection = View.TEXT_DIRECTION_RTL
        background = context.getDrawable(R.drawable.bg_transaction_field)
        setPadding(16, 0, 16, 0)
        setText(initialNote)
    }

    val parts = initialDateTime.split(" - ")
    val date = EditText(context).apply {
        hint = "تاریخ شمسی"
        textSize = 13f
        minHeight = 40
        includeFontPadding = false
        gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END
        textDirection = View.TEXT_DIRECTION_LTR
        isFocusable = false
        isClickable = true
        setText(parts.getOrNull(0).orEmpty())
        background = context.getDrawable(R.drawable.bg_transaction_field)
        setPadding(10, 0, 10, 0)
        setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_date_color, 0, 0, 0)
        compoundDrawablePadding = 7
        setOnClickListener { showJalaliDatePicker(context, text.toString()) { setText(it) } }
    }

    val time = EditText(context).apply {
        hint = "ساعت"
        textSize = 13f
        minHeight = 40
        includeFontPadding = false
        gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.CENTER
        textDirection = View.TEXT_DIRECTION_LTR
        isFocusable = false
        isClickable = true
        setText(parts.getOrNull(1).orEmpty())
        background = context.getDrawable(R.drawable.bg_transaction_field)
        setPadding(10, 0, 10, 0)
        setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_time_color, 0, 0, 0)
        compoundDrawablePadding = 7
        setOnClickListener { showTimePicker(context, text.toString()) { setText(it) } }
    }

    val dateTimeRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }
    dateTimeRow.addView(date, LinearLayout.LayoutParams(0, 40, 1f).apply { marginEnd = 5 })
    dateTimeRow.addView(time, LinearLayout.LayoutParams(0, 40, 0.52f).apply { marginStart = 5 })

    fun addGap(top: Int) {
        val gap = View(context)
        box.addView(gap, LinearLayout.LayoutParams(1, top))
    }

    box.addView(typeGroup)
    addGap(6)
    box.addView(amount, LinearLayout.LayoutParams(-1, 48))
    addGap(7)
    box.addView(note, LinearLayout.LayoutParams(-1, 44))
    addGap(7)
    box.addView(dateTimeRow, LinearLayout.LayoutParams(-1, 40))

    val dialog = MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setView(box)
        .setPositiveButton("ثبت", null)
        .setNegativeButton("انصراف", null)
        .create()

    dialog.setOnShowListener {
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val a = normalizeDigits(amount.text.toString()).replace(",", "").toLongOrNull()
            val d = normalizeDigits(date.text.toString().trim())
            val t = normalizeDigits(time.text.toString().trim())
            val now = Jalali.now()
            val finalDate = if (d.isBlank()) now.substringBefore(" - ") else d
            val finalTime = if (t.isBlank()) now.substringAfter(" - ") else t
            when {
                a == null || a <= 0L -> Toast.makeText(context, "مبلغ معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                !Jalali.isValidDate(finalDate) -> Toast.makeText(context, "تاریخ شمسی معتبر نیست.", Toast.LENGTH_SHORT).show()
                !Jalali.isValidTime(finalTime) -> Toast.makeText(context, "ساعت معتبر نیست.", Toast.LENGTH_SHORT).show()
                else -> {
                    val checkedId = typeGroup.checkedRadioButtonId
                    if (checkedId == -1) {
                        Toast.makeText(context, "نوع تراکنش را انتخاب کنید.", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    val kind = if (checkedId == debtRadio.id) "debt" else "credit"
                    done(kind, a, note.text.toString().trim(), "$finalDate - $finalTime")
                    dialog.dismiss()
                }
            }
        }
    }
    dialog.show()
}

private fun showJalaliDatePicker(context: Context, current: String, done: (String) -> Unit) {
    val now = Jalali.now().substringBefore(" - ")
    val source = if (Jalali.isValidDate(current)) current else now
    val parts = source.split("/")
    val year = parts.getOrNull(0)?.toIntOrNull() ?: 1405
    val month = parts.getOrNull(1)?.toIntOrNull() ?: 1
    val day = parts.getOrNull(2)?.toIntOrNull() ?: 1

    val row = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER
        setPadding(8, 4, 8, 4)
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }
    val yearPicker = NumberPicker(context).apply { minValue = 1200; maxValue = 1600; value = year; wrapSelectorWheel = false }
    val monthPicker = NumberPicker(context).apply { minValue = 1; maxValue = 12; value = month; wrapSelectorWheel = false }
    val dayPicker = NumberPicker(context).apply { minValue = 1; maxValue = jalaliMonthDays(year, month); value = day.coerceAtMost(maxValue); wrapSelectorWheel = false }

    fun refreshDays() { dayPicker.maxValue = jalaliMonthDays(yearPicker.value, monthPicker.value); if (dayPicker.value > dayPicker.maxValue) dayPicker.value = dayPicker.maxValue }
    yearPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }
    monthPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }
    row.addView(dayPicker, LinearLayout.LayoutParams(90, 150))
    row.addView(monthPicker, LinearLayout.LayoutParams(90, 150))
    row.addView(yearPicker, LinearLayout.LayoutParams(105, 150))

    MaterialAlertDialogBuilder(context)
        .setTitle("انتخاب تاریخ شمسی")
        .setView(row)
        .setPositiveButton("انتخاب") { _, _ -> done("%04d/%02d/%02d".format(yearPicker.value, monthPicker.value, dayPicker.value)) }
        .setNegativeButton("انصراف", null)
        .show()
}

private fun jalaliMonthDays(year: Int, month: Int): Int = when {
    month in 1..6 -> 31
    month in 7..11 -> 30
    else -> if (Jalali.isValidDate("%04d/12/30".format(year))) 30 else 29
}

private fun showTimePicker(context: Context, current: String, done: (String) -> Unit) {
    val parts = normalizeDigits(current).split(":")
    val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE)
    android.app.TimePickerDialog(context, { _: TimePicker, h: Int, m: Int -> done("%02d:%02d".format(h, m)) }, hour, minute, true).show()
}
