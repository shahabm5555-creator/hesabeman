package com.mobileshahab.hesabeman

data class InvoiceItem(
    val id: Long = 0,
    val name: String,
    val description: String = "",
    val qty: Long,
    val unitPrice: Long
) {
    val total: Long get() = qty * unitPrice
}
