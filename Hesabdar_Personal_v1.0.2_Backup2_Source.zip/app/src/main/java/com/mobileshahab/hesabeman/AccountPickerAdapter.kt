package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class AccountPickerAdapter(
    private var items: List<NotebookListItem>,
    private val onClick: (NotebookListItem) -> Unit
) : RecyclerView.Adapter<AccountPickerAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.accountAvatar)
        val name: TextView = view.findViewById(R.id.accountName)
        val phone: TextView = view.findViewById(R.id.accountPhone)
        val balance: TextView = view.findViewById(R.id.accountBalance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_account_picker, parent, false)
    )

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val ctx = holder.itemView.context

        holder.name.text = item.name
        holder.phone.text = if (item.phone.isBlank()) "بدون شماره" else item.phone
        holder.avatar.text = item.name.trim().firstOrNull()?.uppercase() ?: "?"

        val debtColor = ContextCompat.getColor(ctx, R.color.debt_text)
        val creditColor = ContextCompat.getColor(ctx, R.color.credit_text)
        val neutralColor = ContextCompat.getColor(ctx, R.color.secondary)
        val avatarColor = when {
            item.balance > 0 -> debtColor
            item.balance < 0 -> creditColor
            else -> neutralColor
        }
        holder.avatar.backgroundTintList = ColorStateList.valueOf(avatarColor)

        val amount = "%,d".format(kotlin.math.abs(item.balance))
        when {
            item.balance > 0 -> { holder.balance.text = "بدهکار $amount"; holder.balance.setTextColor(debtColor); holder.balance.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.debt_soft)) }
            item.balance < 0 -> { holder.balance.text = "بستانکار $amount"; holder.balance.setTextColor(creditColor); holder.balance.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.credit_soft)) }
            else -> { holder.balance.text = "تسویه"; holder.balance.setTextColor(neutralColor); holder.balance.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.neutral_soft)) }
        }

        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size
    fun submit(newItems: List<NotebookListItem>) { items = newItems; notifyDataSetChanged() }
}
