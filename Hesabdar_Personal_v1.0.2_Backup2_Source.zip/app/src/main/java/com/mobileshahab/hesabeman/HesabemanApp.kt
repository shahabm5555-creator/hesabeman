package com.mobileshahab.hesabeman

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class HesabemanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Database creation is handled by DbHelper. Never restore an old snapshot
        // silently during startup; restore is always an explicit user action.
    }
}
