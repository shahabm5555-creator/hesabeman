package com.mobileshahab.hesabeman

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Debounced automatic backup. Any screen can request a backup after a data change.
 * The actual filesystem/database work is off the main thread.
 */
object BackupScheduler {
    private const val DELAY_MS = 1200L
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val dirty = AtomicBoolean(false)
    private var appContext: Context? = null

    @Synchronized
    fun request(context: Context) {
        appContext = context.applicationContext
        if (!AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) return
        dirty.set(true)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ runBackup() }, DELAY_MS)
    }

    @Synchronized
    fun flush(context: Context) {
        appContext = context.applicationContext
        if (!dirty.get()) return
        handler.removeCallbacksAndMessages(null)
        if (!AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) { dirty.set(false); return }
        if (!dirty.compareAndSet(true, false)) return
        runCatching { BackupManager.backup(context, silent = true) }
    }

    private fun runBackup() {
        val context = appContext ?: return
        if (!dirty.compareAndSet(true, false)) return
        executor.execute { BackupManager.backup(context, silent = true) }
    }
}
