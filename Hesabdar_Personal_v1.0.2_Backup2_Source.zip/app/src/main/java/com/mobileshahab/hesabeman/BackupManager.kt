package com.mobileshahab.hesabeman

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Simple, durable backup layer.
 *
 * Public backup folder contains at most TWO meaningful database files:
 *  1) hesabdar_database.db          = newest valid backup
 *  2) hesabdar_database_previous.db = previous valid backup
 *
 * SQLite -wal/-shm/-journal files are temporary runtime files and are NEVER
 * treated as backup files. The backup is a self-contained SQLite snapshot.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val LEGACY_PREFIX = "hesabdar_database"

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val snapshot = createConsistentSnapshot(context)
            try {
                validateDatabase(snapshot)
                publishTwoSlotBackup(context, snapshot)
            } finally {
                snapshot.delete()
            }
            if (!silent) {
                Toast.makeText(
                    context,
                    "پشتیبان در Download/Hesabdarman ذخیره شد.\nفقط آخرین و نسخه قبلی نگهداری می‌شوند.",
                    Toast.LENGTH_LONG
                ).show()
            }
            true
        } catch (e: Exception) {
            if (!silent) {
                Toast.makeText(
                    context,
                    "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}",
                    Toast.LENGTH_LONG
                ).show()
            }
            false
        }
    }

    /** Returns the newest valid external backup, preferring the canonical file. */
    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val primary = findMediaStoreFile(context, CANONICAL_NAME)
            if (primary != null && isValidUri(context, primary)) return primary
            val previous = findMediaStoreFile(context, PREVIOUS_NAME)
            if (previous != null && isValidUri(context, previous)) return previous
            return null
        }

        val dir = backupDirectory()
        val primary = File(dir, CANONICAL_NAME)
        if (primary.exists() && runCatching { validateDatabase(primary); true }.getOrDefault(false)) {
            return Uri.fromFile(primary)
        }
        val previous = File(dir, PREVIOUS_NAME)
        return previous.takeIf { it.exists() && runCatching { validateDatabase(it); true }.getOrDefault(false) }
            ?.let(Uri::fromFile)
    }

    /** Restores one user-selected backup file. The file name is irrelevant. */
    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val candidate = File(context.cacheDir, "restore_candidate_${System.nanoTime()}.db")
        return try {
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)

            DbHelper.closeAll()
            val target = DbHelper.databaseFile(context)
            target.parentFile?.mkdirs()
            deleteSidecars(target)

            val replacement = File(target.parentFile, "${target.name}.restore.tmp")
            replacement.delete()
            copyFile(candidate, replacement)
            validateDatabase(replacement)

            if (target.exists() && !target.delete()) {
                error("پایگاه داده فعلی قابل جایگزینی نیست")
            }
            if (!replacement.renameTo(target)) {
                copyFile(candidate, target)
                replacement.delete()
            }
            validateDatabase(target)
            candidate.delete()
            true
        } catch (e: Exception) {
            candidate.delete()
            File(DbHelper.databaseFile(context).parentFile, "${DbHelper.databaseFile(context).name}.restore.tmp").delete()
            Toast.makeText(
                context,
                "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }

    /** Restores the newest valid public backup without requiring the user to browse for a file. */
    @Synchronized
    fun restoreLatest(context: Context): Boolean {
        val uri = findBestExternalBackup(context) ?: return false
        return restore(context, uri)
    }

    /** Consistent SQLite snapshot independent of WAL/journal side files. */
    private fun createConsistentSnapshot(context: Context): File {
        val helper = DbHelper(context)
        val snapshot = File(context.cacheDir, "hesabdar_snapshot_${System.nanoTime()}.db")
        return try {
            val db = helper.writableDatabase
            // Finish pending WAL work before taking the standalone snapshot.
            db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            val escaped = snapshot.absolutePath.replace("'", "''")
            db.execSQL("VACUUM INTO '$escaped'")
            helper.close()
            if (!snapshot.exists() || snapshot.length() < 4096L) {
                error("اسنپ‌شات دیتابیس ساخته نشد")
            }
            snapshot
        } catch (e: Exception) {
            runCatching { helper.close() }
            snapshot.delete()
            throw e
        }
    }

    /**
     * Two-slot rotation:
     * - validate old primary -> publish it as previous
     * - publish new snapshot as primary
     * - remove every duplicate/legacy file from this backup folder
     *
     * No history chain is created, so the user never has to guess which file is newest.
     */
    private fun publishTwoSlotBackup(context: Context, source: File) {
        validateDatabase(source)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val oldPrimary = findMediaStoreFile(context, CANONICAL_NAME)
            if (oldPrimary != null && isValidUri(context, oldPrimary)) {
                val previousTemp = File(context.cacheDir, "previous_${System.nanoTime()}.db")
                try {
                    copyUriToFile(context.contentResolver, oldPrimary, previousTemp)
                    validateDatabase(previousTemp)
                    publishNewMediaFile(context, PREVIOUS_NAME, previousTemp)
                } finally {
                    previousTemp.delete()
                }
            }
            publishNewMediaFile(context, CANONICAL_NAME, source)
            cleanupPublicDuplicates(context)
        } else {
            val dir = backupDirectory()
            if (!dir.exists() && !dir.mkdirs()) error("پوشه پشتیبان قابل ساخت نیست")
            val primary = File(dir, CANONICAL_NAME)
            val previous = File(dir, PREVIOUS_NAME)
            if (primary.exists() && runCatching { validateDatabase(primary); true }.getOrDefault(false)) {
                copyFile(primary, File(dir, "${PREVIOUS_NAME}.tmp"))
                validateDatabase(File(dir, "${PREVIOUS_NAME}.tmp"))
                File(dir, "${PREVIOUS_NAME}.tmp").renameTo(previous)
            }
            val tmp = File(dir, "${CANONICAL_NAME}.tmp")
            copyFile(source, tmp)
            validateDatabase(tmp)
            if (primary.exists() && !primary.delete()) error("فایل پشتیبان قبلی قابل جایگزینی نیست")
            if (!tmp.renameTo(primary)) {
                copyFile(source, primary)
                tmp.delete()
            }
            cleanupLegacyFiles(dir)
        }
    }

    private fun publishNewMediaFile(context: Context, name: String, source: File) {
        validateDatabase(source)
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val tempName = ".${name}.${System.nanoTime()}.tmp"
        val uri = resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, tempName)
            put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
            put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")

        try {
            resolver.openOutputStream(uri, "wt")?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            } ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")

            val probe = File(context.cacheDir, "media_probe_${System.nanoTime()}.db")
            try {
                copyUriToFile(resolver, uri, probe)
                validateDatabase(probe)
            } finally {
                probe.delete()
            }

            val published = resolver.update(
                uri,
                ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.IS_PENDING, 0)
                },
                null,
                null
            )
            if (published != 1) error("امکان نهایی‌کردن فایل پشتیبان وجود ندارد")
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }

        // Remove older duplicates with the same logical slot. The newest item is kept.
        deleteMediaStoreDuplicates(context, name, uri)
    }

    private fun cleanupPublicDuplicates(context: Context) {
        deleteMediaStoreDuplicates(context, CANONICAL_NAME, findMediaStoreFile(context, CANONICAL_NAME))
        deleteMediaStoreDuplicates(context, PREVIOUS_NAME, findMediaStoreFile(context, PREVIOUS_NAME))

        // Remove old history/legacy files produced by previous builds. These are not used anymore.
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val deleteUris = mutableListOf<Uri>()
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH),
            null
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (c.moveToNext()) {
                val n = c.getString(name)
                if (n.startsWith("hesabdar_history_") || n == LEGACY_PREFIX) {
                    deleteUris += ContentUris.withAppendedId(collection, c.getLong(id))
                }
            }
        }
        deleteUris.forEach { resolver.delete(it, null, null) }
    }

    private fun deleteMediaStoreDuplicates(context: Context, logicalName: String, keep: Uri?) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val matches = mutableListOf<Uri>()
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (c.moveToNext()) {
                val n = c.getString(name)
                // File managers may create names such as hesabdar_database.db (1).
                if (isSlotName(n, logicalName)) {
                    matches += ContentUris.withAppendedId(collection, c.getLong(id))
                }
            }
        }
        matches.forEach { if (keep == null || it != keep) resolver.delete(it, null, null) }
    }

    private fun isSlotName(actual: String, logical: String): Boolean {
        if (actual == logical) return true
        val base = logical.removeSuffix(".db")
        return actual.matches(Regex("${Regex.escape(base)} \\(\\d+\\)\\.db"))
    }

    private fun cleanupLegacyFiles(dir: File) {
        dir.listFiles()?.forEach { file ->
            if (!file.isFile) return@forEach
            val n = file.name
            if (n.startsWith("hesabdar_history_") || n == LEGACY_PREFIX ||
                n.matches(Regex("${Regex.escape(CANONICAL_NAME.removeSuffix(".db"))} \\(\\d+\\)\\.db")) ||
                n.matches(Regex("${Regex.escape(PREVIOUS_NAME.removeSuffix(".db"))} \\(\\d+\\)\\.db"))) {
                file.delete()
            }
        }
    }

    private fun findMediaStoreFile(context: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH, name),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        )?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(collection, c.getLong(0))
        }
        return null
    }

    private fun backupDirectory(): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Hesabdarman"
    )

    private fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        } ?: error("فایل قابل خواندن نیست")
    }

    private fun copyFile(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        }
    }

    private fun deleteSidecars(target: File) {
        File(target.path + "-wal").delete()
        File(target.path + "-shm").delete()
        File(target.path + "-journal").delete()
    }

    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val probe = File(context.cacheDir, "probe_${System.nanoTime()}.db")
        return try {
            copyUriToFile(context.contentResolver, uri, probe)
            validateDatabase(probe)
            true
        } catch (_: Exception) {
            false
        } finally {
            probe.delete()
        }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) {
            error("فایل پشتیبان خالی یا ناقص است")
        }
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf(
                "folders", "notebooks", "tx", "invoices", "invoice_items",
                "installment_plans", "installment_items", "checks", "app_meta"
            )
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) found += c.getString(0)
            }
            if (!found.containsAll(required)) {
                error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")
            }
            val integrityOk = db.rawQuery("PRAGMA integrity_check", null).use {
                it.moveToFirst() && it.getString(0).equals("ok", true)
            }
            if (!integrityOk) error("فایل پشتیبان آسیب‌دیده است")

            val appId = db.rawQuery(
                "SELECT value FROM app_meta WHERE key='app_id' LIMIT 1", null
            ).use { if (it.moveToFirst()) it.getString(0) else "" }
            if (appId != "hesabdar_personal") {
                error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")
            }

            val version = db.rawQuery("PRAGMA user_version", null).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (version > DbHelper.DATABASE_VERSION) {
                error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
            }
        } finally {
            db.close()
        }
    }
}
