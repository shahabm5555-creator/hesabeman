package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityLockBinding

class LockActivity : BaseActivity() {
    private lateinit var b: ActivityLockBinding
    private var authenticated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLockBinding.inflate(layoutInflater); setContentView(b.root)

        // A reinstall removes the private DB. External backups live in Download and
        // therefore survive uninstall. Detect them before entering the app and ask
        // the user explicitly; never overwrite data silently at startup.
        val backupUri = BackupManager.findBestExternalBackup(this)
        val liveDb = DbHelper.databaseFile(this)
        if ((!liveDb.exists() || liveDb.length() < 4096L) && backupUri != null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("پشتیبان قدیمی پیدا شد")
                .setMessage("یک پشتیبان معتبر از حسابدار شخصی در حافظه دستگاه پیدا شد. آیا می‌خواهید اطلاعات آن بازیابی شود؟")
                .setPositiveButton("بازیابی") { _, _ ->
                    if (BackupManager.restore(this, backupUri)) {
                        Toast.makeText(this, "اطلاعات با موفقیت بازیابی شد.", Toast.LENGTH_LONG).show()
                    }
                    continueToApp()
                }
                .setNegativeButton("فعلاً نه") { _, _ -> continueToApp() }
                .setOnCancelListener { continueToApp() }
                .show()
        } else {
            continueToApp()
        }
    }

    private fun continueToApp() {
        val mode = AppPrefs.prefs(this).getString(AppPrefs.LOCK_MODE, "off") ?: "off"
        when (mode) {
            "pin" -> showPin()
            "biometric" -> showBiometric()
            else -> enterApp()
        }
    }

    private fun showPin() {
        b.pinBox.visibility = View.VISIBLE
        b.biometricMessage.visibility = View.GONE
        b.unlock.setOnClickListener {
            val pin = b.pin.text.toString()
            val saved = AppPrefs.prefs(this).getString(AppPrefs.PIN_HASH, "")
            if (pin.length == 4 && AppPrefs.hashPin(pin) == saved) enterApp()
            else {
                b.pin.text?.clear()
                Toast.makeText(this, "رمز نادرست است.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showBiometric() {
        b.pinBox.visibility = View.GONE
        b.biometricMessage.visibility = View.VISIBLE
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            b.biometricMessage.text = "اثر انگشت در دسترس نیست. از تنظیمات سیستم آن را فعال کنید."
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result); enterApp()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                b.biometricMessage.text = "برای ورود، دوباره اثر انگشت را امتحان کنید."
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ورود به حسابدار شخصی")
            .setSubtitle("اثر انگشت خود را تأیید کنید")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .setNegativeButtonText("انصراف")
            .build()
        b.biometricMessage.setOnClickListener { prompt.authenticate(info) }
        prompt.authenticate(info)
    }

    private fun enterApp() {
        if (authenticated) return
        authenticated = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
