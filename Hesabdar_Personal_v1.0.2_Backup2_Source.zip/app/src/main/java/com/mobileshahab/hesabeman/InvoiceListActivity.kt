package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import java.io.File
import android.os.Bundle
import android.view.Gravity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InvoiceListActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1
    private var notebookName = ""
    private var notebookPhone = ""
    private lateinit var listContainer: LinearLayout
    private var pendingSaveInv: DbHelper.InvoiceHeader? = null
    private var pendingSaveInstallment: InstallmentPlan? = null
    private var pendingPdfSize = "A5"

    private val pdfSaveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            pendingSaveInv?.let { inv -> exportInvoice(inv, uri, pendingPdfSize) { toast("PDF فاکتور ذخیره شد") } }
            pendingSaveInstallment?.let { plan -> exportInstallment(plan, uri, pendingPdfSize) { toast("PDF فاکتور اقساط ذخیره شد") } }
        }
        pendingSaveInv = null; pendingSaveInstallment = null
    }
    private val newInvoiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) loadList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""
        notebookPhone = intent.getStringExtra("notebook_phone") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(color(R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, ins ->
                val b = ins.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, b.top, 0, b.bottom); ins
            }
        }

        // Toolbar
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(color(R.color.surface))
            layoutParams = LinearLayout.LayoutParams(-1, dp(60))
            addView(closeButton(this@InvoiceListActivity, 22f, color(R.color.text), 44) { finish() })
            addView(TextView(this@InvoiceListActivity).apply {
                text = "فاکتورهای $notebookName"; textSize = 15f; gravity = Gravity.CENTER
                setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(MaterialButton(this@InvoiceListActivity).apply {
                text = "چک‌ها"; textSize = 10.5f; cornerRadius = dp(12); insetTop=0; insetBottom=0
                setPadding(dp(8),0,dp(8),0); layoutParams=LinearLayout.LayoutParams(-2,dp(38)).apply{marginEnd=dp(4)}
                setOnClickListener { startActivity(Intent(this@InvoiceListActivity, CheckActivity::class.java).apply{putExtra("notebook_id",notebookId);putExtra("notebook_name",notebookName)}) }
            })
            addView(MaterialButton(this@InvoiceListActivity).apply {
                text = "+ جدید"; textSize = 12f; cornerRadius = dp(14); insetTop = 0; insetBottom = 0
                setPadding(dp(12), 0, dp(12), 0)
                layoutParams = LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(10) }
                setOnClickListener {
                    newInvoiceLauncher.launch(Intent(this@InvoiceListActivity, InvoiceActivity::class.java).apply {
                        putExtra("notebook_id", notebookId)
                        putExtra("notebook_name", notebookName)
                        putExtra("notebook_phone", notebookPhone)
                    })
                }
            })
        })

        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(16))
        }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadList()
    }

    private fun loadList() {
        listContainer.removeAllViews()
        val invoices = db.invoices(notebookId)
        val installments = db.installmentPlans(notebookId)
        if (invoices.isEmpty() && installments.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "هیچ فاکتوری ثبت نشده"; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(color(R.color.secondary)); setPadding(0, dp(40), 0, 0)
            }); return
        }
        if (installments.isNotEmpty()) {
            if (invoices.isNotEmpty()) listContainer.addView(sectionLabel("فاکتورهای اقساطی"))
            installments.forEach { plan -> listContainer.addView(buildInstallmentCard(plan)) }
        }
        if (invoices.isNotEmpty()) {
            if (installments.isNotEmpty()) listContainer.addView(sectionLabel("فاکتورها"))
            invoices.forEach { inv -> listContainer.addView(buildInvoiceCard(inv)) }
        }
    }

    private fun sectionLabel(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(color(R.color.secondary))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(4), dp(10), dp(4), dp(6))
    }

    private fun buildInvoiceCard(inv: DbHelper.InvoiceHeader): View {
        val card = MaterialCardView(this).apply {
            radius = dp(16).toFloat(); cardElevation = dp(2).toFloat()
            setCardBackgroundColor(color(R.color.surface))
            strokeWidth = dp(1); strokeColor = color(R.color.divider)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // ── Top row: pill + number + date ──
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val isDebt = inv.kind == "debt"
        topRow.addView(TextView(this).apply {
            text = if (isDebt) "فاکتور فروش" else "فاکتور خرید"; textSize = 10f
            setTextColor(color(if (isDebt) R.color.debt_text else R.color.credit_text))
            backgroundTintList = ColorStateList.valueOf(color(if (isDebt) R.color.debt_soft else R.color.credit_soft))
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_status_pill)
            setPadding(dp(8), dp(3), dp(8), dp(3))
        })
        topRow.addView(TextView(this).apply {
            text = "  فاکتور شماره ${inv.number}"; textSize = 14f
            setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        topRow.addView(TextView(this).apply {
            text = inv.createdAt; textSize = 10f; setTextColor(color(R.color.secondary))
        })
        box.addView(topRow)

        // ── Amounts ──
        val remaining = (inv.total - inv.discount - inv.prepay).coerceAtLeast(0L)
        val amtRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }
        amtRow.addView(TextView(this).apply {
            text = "جمع: %,d تومان".format(inv.total); textSize = 12f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        amtRow.addView(TextView(this).apply {
            text = "مانده: %,d تومان".format(remaining); textSize = 13f
            setTextColor(color(R.color.primary)); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(amtRow)

        // ── Prepay + due date ──
        if (inv.prepay > 0 || inv.discount > 0 || inv.dueDate.isNotBlank()) {
            val extraRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
            }
            if (inv.prepay > 0) extraRow.addView(TextView(this).apply {
                text = "پیش‌پرداخت: %,d".format(inv.prepay); textSize = 11f
                setTextColor(color(R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            if (inv.discount > 0) extraRow.addView(TextView(this).apply {
                text = "تخفیف: %,d".format(inv.discount); textSize = 11f
                setTextColor(color(R.color.debt_text))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            if (inv.dueDate.isNotBlank()) extraRow.addView(TextView(this).apply {
                text = "سررسید: ${inv.dueDate}"; textSize = 11f
                setTextColor(color(R.color.orange))
            })
            box.addView(extraRow)
        }

        // ── Items summary ──
        val invItems = db.invoiceItems(inv.id)
        if (invItems.isNotEmpty()) {
            val divider = View(this).apply {
                setBackgroundColor(color(R.color.divider))
                layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(6) }
            }
            box.addView(divider)
            invItems.take(3).forEach { item ->
                box.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) }
                    addView(TextView(this@InvoiceListActivity).apply {
                        text = "• ${item.name}"; textSize = 11f
                        setTextColor(color(R.color.text))
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    })
                    addView(TextView(this@InvoiceListActivity).apply {
                        text = "${item.qty}× %,d  =  %,d".format(item.unitPrice, item.total); textSize = 11f
                        setTextColor(color(R.color.secondary))
                    })
                })
            }
            if (invItems.size > 3) box.addView(TextView(this).apply {
                text = "و ${invItems.size - 3} قلم دیگر…"; textSize = 10f
                setTextColor(color(R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
            })
        }

        // ── Action buttons ──
        fun btn(label: String, bg: Int, tc: Int, action: () -> Unit) = MaterialButton(this).apply {
            text = label; textSize = 10.5f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(bg)); setTextColor(color(tc))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) }
            setOnClickListener { action() }
        }
        fun actionRow(vararg buttons: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            buttons.forEach { addView(it) }
        }
        box.addView(actionRow(
            btn("ویرایش", R.color.primary_soft, R.color.primary) { showEditDialog(inv) },
            btn("نمایش PDF", R.color.primary_soft, R.color.primary) { previewInvoice(inv) },
            btn("اشتراک PDF", R.color.credit_soft, R.color.credit_text) { shareInvoice(inv) }
        ))
        box.addView(actionRow(
            btn("ذخیره PDF فاکتور", R.color.neutral_soft, R.color.text) { saveInvoicePdf(inv) },
            btn("حذف", R.color.debt_soft, R.color.debt_text) {
                MaterialAlertDialogBuilder(this).setTitle("حذف فاکتور")
                    .setMessage("این فاکتور به مدت ۵ روز در سطل زباله می‌ماند و سپس خودکار حذف می‌شود.")
                    .setPositiveButton("حذف") { _, _ ->
                        if (db.trashInvoice(inv.id)) { toast("فاکتور به سطل زباله منتقل شد"); loadList() }
                    }.setNegativeButton("انصراف", null).show()
            }
        ))
        card.addView(box)
        return card
    }

    private fun buildInstallmentCard(plan: InstallmentPlan): View {
        val card = MaterialCardView(this).apply {
            radius = dp(16).toFloat(); cardElevation = dp(2).toFloat()
            setCardBackgroundColor(color(R.color.surface))
            strokeWidth = dp(1); strokeColor = color(R.color.divider)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(TextView(this).apply {
            text = "قسطی"; textSize = 10f
            setTextColor(color(R.color.primary))
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_status_pill)
            backgroundTintList = ColorStateList.valueOf(color(R.color.primary_soft))
            setPadding(dp(8), dp(3), dp(8), dp(3))
        })
        topRow.addView(TextView(this).apply {
            text = "  ${plan.description}"; textSize = 14f
            setTextColor(color(R.color.text)); setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        topRow.addView(TextView(this).apply {
            text = plan.createdAt; textSize = 10f; setTextColor(color(R.color.secondary))
        })
        box.addView(topRow)

        val totalPayable = (plan.price - plan.prepay) + plan.totalInterest
        val amtRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }
        amtRow.addView(TextView(this).apply {
            text = "قیمت کالا: %,d تومان".format(plan.price); textSize = 12f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        amtRow.addView(TextView(this).apply {
            text = "مبلغ کل اقساط: %,d تومان".format(totalPayable); textSize = 13f
            setTextColor(color(R.color.primary)); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(amtRow)

        val extraRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
        }
        extraRow.addView(TextView(this).apply {
            text = "پیش‌پرداخت: %,d — تخفیف: %,d — تعداد اقساط: ${plan.installmentCount}".format(plan.prepay, plan.discount); textSize = 11f
            setTextColor(color(R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        extraRow.addView(TextView(this).apply {
            text = "تسویه: ${plan.settlementDate}"; textSize = 11f
            setTextColor(color(R.color.orange))
        })
        box.addView(extraRow)

        fun btn(label: String, bg: Int, tc: Int, action: () -> Unit) = MaterialButton(this).apply {
            text = label; textSize = 10.5f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(bg)); setTextColor(color(tc))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) }
            setOnClickListener { action() }
        }
        fun actionRow(vararg buttons: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            buttons.forEach { addView(it) }
        }
        box.addView(actionRow(
            btn("ویرایش", R.color.primary_soft, R.color.primary) { showInstallmentEditDialog(plan) },
            btn("نمایش PDF", R.color.primary_soft, R.color.primary) { previewInstallment(plan) },
            btn("اشتراک PDF", R.color.credit_soft, R.color.credit_text) { shareInstallment(plan) }
        ))
        box.addView(actionRow(
            btn("ذخیره PDF فاکتور", R.color.neutral_soft, R.color.text) { saveInstallmentPdf(plan) },
            btn("حذف", R.color.debt_soft, R.color.debt_text) {
                MaterialAlertDialogBuilder(this).setTitle("حذف فاکتور اقساط")
                    .setMessage("این فاکتور و سررسیدهای اقساط آن به مدت ۵ روز در سطل زباله می‌ماند و سپس خودکار حذف می‌شود.")
                    .setPositiveButton("حذف") { _, _ ->
                        if (db.trashInstallmentPlan(plan.id)) { toast("فاکتور اقساط به سطل زباله منتقل شد"); loadList() }
                    }.setNegativeButton("انصراف", null).show()
            }
        ))
        card.addView(box)
        return card
    }


    private fun choosePdfSize(title: String, done: (String) -> Unit) {
        val labels = arrayOf("A5  —  148 × 210 میلی‌متر", "B5  —  176 × 250 میلی‌متر")
        MaterialAlertDialogBuilder(this).setTitle(title)
            .setSingleChoiceItems(labels, if (pendingPdfSize == "B5") 1 else 0) { dialog, which ->
                pendingPdfSize = if (which == 1) "B5" else "A5"; dialog.dismiss(); done(pendingPdfSize)
            }.setNegativeButton("انصراف", null).show()
    }
    private fun saveInvoicePdf(inv: DbHelper.InvoiceHeader) = choosePdfSize("اندازه PDF فاکتور") {
        pendingSaveInv = inv; pendingSaveInstallment = null
        pdfSaveLauncher.launch("فاکتور-${notebookName.replace("/", "-")}-شماره${inv.number}-$it.pdf")
    }
    private fun saveInstallmentPdf(plan: InstallmentPlan) = choosePdfSize("اندازه PDF فاکتور اقساط") {
        pendingSaveInstallment = plan; pendingSaveInv = null
        pdfSaveLauncher.launch("فاکتور اقساط-${notebookName.replace("/", "-")}-${plan.description.replace("/", "-")}-$it.pdf")
    }
    private fun previewInvoice(inv: DbHelper.InvoiceHeader) = choosePdfSize("اندازه نمایش فاکتور") { size ->
        val uri = cachePdfUri("فاکتور-${inv.number}-$size.pdf"); exportInvoice(inv, uri, size) { openPdf(uri) }
    }
    private fun shareInvoice(inv: DbHelper.InvoiceHeader) = choosePdfSize("اندازه PDF برای اشتراک") { size ->
        val uri = cachePdfUri("فاکتور-${inv.number}-$size.pdf"); exportInvoice(inv, uri, size) { sharePdf(uri, "فاکتور ${inv.number}") }
    }
    private fun previewInstallment(plan: InstallmentPlan) = choosePdfSize("اندازه نمایش فاکتور اقساط") { size ->
        val uri = cachePdfUri("فاکتور-اقساط-${plan.id}-$size.pdf"); exportInstallment(plan, uri, size) { openPdf(uri) }
    }
    private fun shareInstallment(plan: InstallmentPlan) = choosePdfSize("اندازه PDF برای اشتراک") { size ->
        val uri = cachePdfUri("فاکتور-اقساط-${plan.id}-$size.pdf"); exportInstallment(plan, uri, size) { sharePdf(uri, "فاکتور اقساط") }
    }
    private fun cachePdfUri(name: String): Uri {
        val dir = File(cacheDir, "shared_pdfs").apply { mkdirs() }; val file = File(dir, name.replace("/", "-")); if (file.exists()) file.delete()
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    }
    private fun openPdf(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
        catch (_: Exception) { sharePdf(uri, "نمایش PDF") }
    }
    private fun sharePdf(uri: Uri, title: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_TITLE, title); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "اشتراک $title"))
    }
    private fun exportInvoice(inv: DbHelper.InvoiceHeader, uri: Uri, pageSize: String = "A5", done: (Uri) -> Unit) {
        val items = db.invoiceItems(inv.id); val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        InvoicePdfExporter.export(context=this, uri=uri, invoiceNumber=inv.number, invoiceKind=inv.kind, buyerName=notebookName, buyerPhone=notebookPhone,
            sellerName=prefs.getString(AppPrefs.SELLER_NAME, "") ?: "", sellerAddress=prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "", sellerPhone=prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "",
            sellerSlogan=prefs.getString(AppPrefs.SELLER_SLOGAN, "با تشکر از خرید شما") ?: "", items=items, date=inv.createdAt, prepay=inv.prepay, discount=inv.discount, dueDate=inv.dueDate, pageSize=pageSize) { done(it) }
    }
    private fun exportInstallment(plan: InstallmentPlan, uri: Uri, pageSize: String = "A5", done: (Uri) -> Unit) {
        val items = db.installmentItems(plan.id); val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        InstallmentPdfExporter.export(context=this, uri=uri, notebookName=notebookName, notebookPhone=notebookPhone, sellerName=prefs.getString(AppPrefs.SELLER_NAME, "") ?: "",
            sellerAddress=prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: "", sellerPhone=prefs.getString(AppPrefs.SELLER_PHONE, "") ?: "", sellerSlogan=prefs.getString(AppPrefs.SELLER_SLOGAN, "با تشکر از خرید شما") ?: "", plan=plan, items=items, pageSize=pageSize) { done(it) }
    }

    private fun showInstallmentEditDialog(plan: InstallmentPlan) {
        var startDate = plan.startDate
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        fun f(h: String, v: String, money: Boolean = false) = EditText(this).apply {
            hint = h; setText(if (money && v.isNotBlank()) groupDigits(v) else v); textSize = 13f
            inputType = if (money) android.text.InputType.TYPE_CLASS_PHONE else android.text.InputType.TYPE_CLASS_TEXT
            if (money) {
                gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
                textDirection = android.view.View.TEXT_DIRECTION_LTR
                textAlignment = android.view.View.TEXT_ALIGNMENT_GRAVITY
            } else {
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                textDirection = android.view.View.TEXT_DIRECTION_RTL
                textAlignment = android.view.View.TEXT_ALIGNMENT_GRAVITY
            }
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
            if (money) addTextChangedListener(moneyWatcher())
        }
        val desc = f("نام کالا / توضیحات", plan.description)
        val price = f("قیمت کالا (تومان)", plan.price.toString(), true)
        val prepay = f("پیش‌پرداخت (تومان)", plan.prepay.toString(), true)
        val discount = f("تخفیف (تومان)", plan.discount.toString(), true)
        val percent = EditText(this).apply {
            hint = "درصد سود ماهانه"; setText(if (plan.profitPercent > 0) plan.profitPercent.toString() else "")
            textSize = 13f; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textDirection = android.view.View.TEXT_DIRECTION_LTR; textAlignment = android.view.View.TEXT_ALIGNMENT_GRAVITY
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
        }
        val count = EditText(this).apply {
            hint = "تعداد اقساط"; setText(plan.installmentCount.toString())
            textSize = 13f; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textDirection = android.view.View.TEXT_DIRECTION_LTR; textAlignment = android.view.View.TEXT_ALIGNMENT_GRAVITY
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
        }
        val interval = EditText(this).apply {
            hint = "فاصله اقساط (روز)"; setText(plan.intervalDays.toString())
            textSize = 13f; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textDirection = android.view.View.TEXT_DIRECTION_LTR; textAlignment = android.view.View.TEXT_ALIGNMENT_GRAVITY
            background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
        }
        box.addView(desc); box.addView(price); box.addView(prepay); box.addView(discount); box.addView(percent); box.addView(count); box.addView(interval)

        val startLabel = TextView(this).apply {
            text = "تاریخ شروع: $startDate"; textSize = 11f; setTextColor(color(R.color.secondary)); setPadding(0, dp(8), 0, 0)
        }
        box.addView(startLabel)
        box.addView(MaterialButton(this).apply {
            text = "📅 تغییر تاریخ شروع"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(4) }
            setOnClickListener { promptJalaliDate(this@InvoiceListActivity, startDate) { d -> startDate = d; startLabel.text = "تاریخ شروع: $d" } }
        })

        MaterialAlertDialogBuilder(this)
            .setTitle("ویرایش فاکتور اقساط")
            .setView(box)
            .setPositiveButton("ذخیره فاکتور") { _, _ ->
                val d = desc.text.toString().trim()
                val p = parseDigitsLong(price.text.toString())
                val pp = parseDigitsLong(prepay.text.toString())
                val dc = parseDigitsLong(discount.text.toString())
                val pr = parseDigitsDouble(percent.text.toString())
                val n = parseDigitsLong(count.text.toString()).toInt()
                val gap = parseDigitsLong(interval.text.toString()).toInt()
                if (db.updateInstallmentPlan(plan.id, notebookId, startDate, d, p, pp, dc, pr, n, gap)) {
                    toast("فاکتور اقساط ویرایش شد"); loadList()
                } else toast("اطلاعات فاکتور اقساط کامل نیست")
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showEditDialog(inv: DbHelper.InvoiceHeader) {
        val items = db.invoiceItems(inv.id).toMutableList()
        var dueDate = inv.dueDate
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        val itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshItems() {
            itemsBox.removeAllViews()
            items.forEachIndexed { idx, item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                    setOnClickListener { showItemEditDialog(items, idx, ::refreshItems) }
                }
                row.addView(TextView(this).apply {
                    text = "${item.name} — ${item.description.ifBlank { "بدون توضیح" }}\nتعداد: ${item.qty}   فی: ${"%,d".format(item.unitPrice)}   جمع: ${"%,d".format(item.total)} تومان"
                    textSize = 11f; setTextColor(color(R.color.text))
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                })
                row.addView(closeButton(this, 16f, color(R.color.debt_text), 32) { items.removeAt(idx); refreshItems() })
                itemsBox.addView(row)
                itemsBox.addView(View(this).apply { setBackgroundColor(color(R.color.divider)); layoutParams = LinearLayout.LayoutParams(-1, 1) })
            }
        }
        refreshItems()
        box.addView(TextView(this).apply { text = "اقلام فاکتور"; textSize = 12f; setTextColor(color(R.color.secondary)); setPadding(0,0,0,dp(4)) })
        box.addView(itemsBox)
        box.addView(MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            backgroundTintList = ColorStateList.valueOf(color(R.color.surface))
            strokeColor = ColorStateList.valueOf(Color.BLACK); strokeWidth = dp(1)
            setTextColor(Color.BLACK); setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(8) }
            setOnClickListener { showItemEditDialog(items, -1, ::refreshItems) }
        })

        val kindGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(8) } }
        val rdDebt = RadioButton(this).apply { id=View.generateViewId(); text="فاکتور فروش"; layoutParams=RadioGroup.LayoutParams(0,-2,1f) }
        val rdCredit = RadioButton(this).apply { id=View.generateViewId(); text="فاکتور خرید"; layoutParams=RadioGroup.LayoutParams(0,-2,1f) }
        kindGroup.addView(rdDebt); kindGroup.addView(rdCredit); kindGroup.check(if(inv.kind=="debt") rdDebt.id else rdCredit.id)
        box.addView(TextView(this).apply { text="نوع ثبت در حساب"; textSize=11f; setTextColor(color(R.color.secondary)); setPadding(0,dp(8),0,0) })
        box.addView(kindGroup)

        var issueDate = inv.createdAt.substringBefore(" - ")
        var issueTime = inv.createdAt.substringAfter(" - ", "00:00")
        val issueBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, 0) }
        val issueDateLabel = TextView(this).apply { text = issueDate; textSize = 12f; gravity = Gravity.CENTER; setTextColor(color(R.color.text)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val issueTimeLabel = TextView(this).apply { text = issueTime; textSize = 12f; gravity = Gravity.CENTER; setTextColor(color(R.color.text)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        issueBox.addView(MaterialButton(this).apply { text="📅 تاریخ صدور"; textSize=10.5f; cornerRadius=dp(11); insetTop=0; insetBottom=0; backgroundTintList=ColorStateList.valueOf(color(R.color.primary_soft)); setTextColor(color(R.color.primary)); setOnClickListener{promptJalaliDate(this@InvoiceListActivity,issueDate,"انتخاب تاریخ صدور"){d->issueDate=d;issueDateLabel.text=d}} })
        issueBox.addView(issueDateLabel)
        issueBox.addView(MaterialButton(this).apply { text="🕒 ساعت"; textSize=10.5f; cornerRadius=dp(11); insetTop=0; insetBottom=0; backgroundTintList=ColorStateList.valueOf(color(R.color.primary_soft)); setTextColor(color(R.color.primary)); setOnClickListener{promptTimeForEdit(issueTime){t->issueTime=t;issueTimeLabel.text=t}} })
        issueBox.addView(issueTimeLabel)
        box.addView(issueBox)

        val prepay = EditText(this).apply {
            hint="پیش‌پرداخت (تومان)"; textSize=13f; gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL;inputType=android.text.InputType.TYPE_CLASS_PHONE;textDirection=android.view.View.TEXT_DIRECTION_LTR;textAlignment=android.view.View.TEXT_ALIGNMENT_GRAVITY
            setText(if(inv.prepay>0) groupDigits(inv.prepay.toString()) else "")
            background=ContextCompat.getDrawable(this@InvoiceListActivity,R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14),dp(12),dp(14),dp(12))
            layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(7)}
            addTextChangedListener(moneyWatcher())
        }
        box.addView(prepay)

        val discount = EditText(this).apply {
            hint="تخفیف (تومان)"; textSize=13f; gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
            inputType=android.text.InputType.TYPE_CLASS_PHONE; textDirection=android.view.View.TEXT_DIRECTION_LTR
            textAlignment=android.view.View.TEXT_ALIGNMENT_GRAVITY
            setText(if(inv.discount>0) groupDigits(inv.discount.toString()) else "")
            background=ContextCompat.getDrawable(this@InvoiceListActivity,R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14),dp(12),dp(14),dp(12))
            layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(7)}
            addTextChangedListener(moneyWatcher())
        }
        box.addView(discount)

        val dueLabel=TextView(this).apply{text=if(dueDate.isBlank())"سررسید: انتخاب نشده" else "سررسید: $dueDate";textSize=11f;setTextColor(color(R.color.secondary));setPadding(0,dp(8),0,0)}
        box.addView(dueLabel)
        box.addView(MaterialButton(this).apply{
            text="📅 تغییر سررسید";textSize=12f;cornerRadius=dp(12);insetTop=0;insetBottom=0
            layoutParams=LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(4)}
            setOnClickListener{promptJalaliDate(this@InvoiceListActivity,dueDate){d->dueDate=d;dueLabel.text="سررسید: $d";dueLabel.setTextColor(color(R.color.text))}}
        })

        MaterialAlertDialogBuilder(this)
            .setTitle("ویرایش فاکتور شماره ${inv.number}")
            .setView(box)
            .setPositiveButton("ذخیره فاکتور") { _, _ ->
                val newKind=if(kindGroup.checkedRadioButtonId==rdDebt.id)"debt" else "credit"
                val newPrepay=parseDigitsLong(prepay.text.toString())
                val newDiscount=parseDigitsLong(discount.text.toString())
                if(db.updateInvoice(inv.id,notebookId,newKind,items,inv.note,newPrepay,dueDate,inv.txId,newDiscount,"$issueDate - $issueTime")){toast("فاکتور ویرایش شد");loadList()}else toast("اطلاعات فاکتور کامل نیست")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showItemEditDialog(items: MutableList<InvoiceItem>, index: Int, refresh: () -> Unit) {
        val old=items.getOrNull(index)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(18),dp(4),dp(18),dp(4))}
        fun f(h:String,v:String,n:Boolean=false)=EditText(this).apply{
            hint=h;setText(if(n && v.isNotBlank()) groupDigits(v) else v);textSize=13f
            inputType=if(n)android.text.InputType.TYPE_CLASS_PHONE else android.text.InputType.TYPE_CLASS_TEXT
            if(n){
                gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
                textDirection=android.view.View.TEXT_DIRECTION_LTR
                textAlignment=android.view.View.TEXT_ALIGNMENT_GRAVITY
            }else{
                gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
                textDirection=android.view.View.TEXT_DIRECTION_RTL
                textAlignment=android.view.View.TEXT_ALIGNMENT_GRAVITY
            }
            background=ContextCompat.getDrawable(this@InvoiceListActivity,R.drawable.bg_search_field)
            setTextColor(color(R.color.text)); setHintTextColor(color(R.color.secondary))
            setPadding(dp(14),dp(12),dp(14),dp(12))
            layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(7)}
            if(n) addTextChangedListener(moneyWatcher())
        }
        val name=f("نام کالا",old?.name.orEmpty())
        val desc=f("توضیحات",old?.description.orEmpty())
        val qty=f("تعداد",old?.qty?.toString()?:"1",true)
        val price=f("فی (تومان)",old?.unitPrice?.toString().orEmpty(),true)
        box.addView(name);box.addView(desc);box.addView(qty);box.addView(price)
        MaterialAlertDialogBuilder(this).setTitle(if(old==null)"افزودن قلم" else "ویرایش قلم").setView(box)
            .setPositiveButton(if(old==null)"افزودن" else "ذخیره"){_,_->
                val n=name.text.toString().trim();val q=parseDigitsLong(qty.text.toString());val p=parseDigitsLong(price.text.toString())
                if(n.isBlank()||q<=0||p<=0){toast("نام کالا، تعداد و فی را کامل وارد کنید");return@setPositiveButton}
                val item=InvoiceItem(name=n,description=desc.text.toString().trim(),qty=q,unitPrice=p)
                if(old==null)items.add(item)else items[index]=item
                refresh()
            }.setNegativeButton("انصراف",null).show()
    }


    private fun promptTimeForEdit(current:String, done:(String)->Unit){
        val parts=current.split(":"); val h=parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0,23) ?: 0; val m=parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0,59) ?: 0
        android.app.TimePickerDialog(this,{_,hh,mm->done("%02d:%02d".format(hh,mm))},h,m,true).show()
    }
    private fun normalizeDigits(value:String):String = value.map { when(it) { in '۰'..'۹' -> ('0'.code + (it.code-'۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (it.code-'٠'.code)).toChar(); else -> it } }.joinToString("")
    private fun parseDigitsLong(value:String):Long = normalizeDigits(value).replace(",", "").filter(Char::isDigit).toLongOrNull() ?: 0L
    private fun parseDigitsDouble(value:String):Double = normalizeDigits(value).replace(",", "").replace("٫", ".").filter { it.isDigit() || it == '.' }.toDoubleOrNull() ?: 0.0
    private fun groupDigits(value:String):String {
        val d = value.map { when(it) { in '۰'..'۹' -> ('0'.code + (it.code-'۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (it.code-'٠'.code)).toChar(); else -> it } }.joinToString("").filter(Char::isDigit).trimStart('0')
        if(d.isEmpty()) return ""
        return d.reversed().chunked(3).joinToString(",").reversed()
    }
    private fun moneyWatcher() = object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if(busy) return
            val f = groupDigits(e?.toString().orEmpty())
            if(e?.toString() != f) { busy = true; e?.replace(0, e.length, f); busy = false }
        }
    }
    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
