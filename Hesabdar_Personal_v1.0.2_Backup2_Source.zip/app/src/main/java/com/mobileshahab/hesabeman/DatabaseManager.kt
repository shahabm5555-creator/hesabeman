package com.mobileshahab.hesabeman

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Central safety layer for the live database.
 * The live DB stays in Android private storage; recovery copies are also private.
 */
object DatabaseManager {
    private const val RECOVERY_DIR = "Hesabdarman/Recovery"
    private const val LATEST = "recovery_latest.db"
    private const val PREVIOUS = "recovery_previous.db"

    @Synchronized
    fun initialize(context: Context) {
        val db = DbHelper.databaseFile(context)
        if (!db.exists()) {
            restoreRecoveryIfAvailable(context)
        } else if (!isHealthy(db)) {
            restoreRecoveryIfAvailable(context)
        }
    }

    @Synchronized
    fun createRecoverySnapshot(context: Context): Boolean {
        val db = DbHelper.databaseFile(context)
        if (!db.exists()) {
            runCatching { DbHelper(context).close() }
        } else {
            runCatching {
                val helper = DbHelper(context)
                helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
                helper.close()
            }
        }
        if (!db.exists() || db.length() < 4096L) return false
        if (!isHealthy(db)) return false
        val dir = File(context.filesDir, RECOVERY_DIR)
        if (!dir.exists() && !dir.mkdirs()) return false
        val latest = File(dir, LATEST)
        val previous = File(dir, PREVIOUS)
        return try {
            val temp = File(dir, "recovery_tmp.db")
            copy(db, temp)
            if (!isHealthy(temp)) {
                temp.delete()
                return false
            }
            if (latest.exists()) {
                latest.copyTo(previous, overwrite = true)
            }
            temp.renameTo(latest).also { ok -> if (!ok) temp.delete() }
        } catch (_: Exception) {
            false
        }
    }

    private fun restoreRecoveryIfAvailable(context: Context): Boolean {
        val dir = File(context.filesDir, RECOVERY_DIR)
        val latest = File(dir, LATEST)
        val previous = File(dir, PREVIOUS)
        val source = when {
            latest.exists() && isHealthy(latest) -> latest
            previous.exists() && isHealthy(previous) -> previous
            else -> null
        } ?: return false

        DbHelper.closeAll()
        val target = DbHelper.databaseFile(context)
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, "personal_hesabdar_restore.tmp")
        return try {
            copy(source, temp)
            if (!isHealthy(temp)) {
                temp.delete()
                return false
            }
            File(target.path + "-wal").delete()
            File(target.path + "-shm").delete()
            if (target.exists()) target.delete()
            temp.renameTo(target).also { ok -> if (!ok) temp.delete() }
        } catch (_: Exception) {
            temp.delete()
            false
        }
    }

    private fun isHealthy(file: File): Boolean {
        if (!file.exists() || file.length() < 4096L) return false
        return try {
            val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val quick = db.rawQuery("PRAGMA quick_check", null).use {
                    it.moveToFirst() && it.getString(0).equals("ok", true)
                }
                val version = db.rawQuery("PRAGMA user_version", null).use {
                    it.moveToFirst() && it.getInt(0) <= DbHelper.DATABASE_VERSION
                }
                quick && version
            } finally {
                db.close()
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun copy(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        }
    }
}
