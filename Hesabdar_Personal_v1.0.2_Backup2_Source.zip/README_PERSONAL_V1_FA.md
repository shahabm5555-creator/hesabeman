# حسابدار شخصی 1.0.0

نسخه بازسازی‌شده بر پایه رابط و امکانات نسخه سالم حسابدار، با هسته دیتابیس جدید و محافظت‌شده.

## ذخیره‌سازی
- دیتابیس زنده: Android private database storage با نام `personal_hesabdar.db`
- فایل زنده در حافظه عمومی قرار نمی‌گیرد و برای کار عادی به Storage Permission نیاز ندارد.
- Recovery داخلی در `files/Hesabdarman/Recovery/` نگهداری می‌شود.
- Backup قابل مشاهده کاربر در `Download/Hesabdarman/hesabdar_database.db` قرار می‌گیرد.

## ایمنی
- SQLite WAL و Foreign Keys فعال است.
- قبل از Recovery/Backup بررسی `quick_check` انجام می‌شود.
- Restore فقط با انتخاب صریح کاربر انجام می‌شود.
- Backup خارجی هرگز در Startup به‌صورت خودکار وارد نمی‌شود.
- سطل بازیافت ۵ روزه حفظ شده است.

## اطلاعات
جداول نسخه V1 شامل پوشه‌ها، کاربران، تراکنش‌ها، چک‌ها، فاکتورها، اقلام فاکتور، اقساط و اقلام اقساط است.

## Build
GitHub Actions فایل `Hesabdar_Personal_v1.0.0.apk` را به‌عنوان Artifact تولید می‌کند.
