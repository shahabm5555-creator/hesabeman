package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * One canonical external backup. The filename is always exactly:
 *   Download/Hesabdar/hesabdar_database
 * Old copies such as (1), (2), ... are removed.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    private const val CANONICAL_RELATIVE_PATH = "Download/Hesabdarman/"

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            checkpoint(context)
            val src = DbHelper.databaseFile(context)
            if (!src.exists() || src.length() < 4096L) error("پایگاه داده هنوز آماده پشتیبان‌گیری نیست")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                writeCanonicalMediaStore(context, src)
            } else {
                writeCanonicalLegacy(src)
            }
            if (!silent) Toast.makeText(context, "پشتیبان اصلی در Download/Hesabdarman/$CANONICAL_NAME ذخیره شد.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    /**
     * Restore the canonical public backup only when the live database does not
     * exist yet. Never overwrite an existing live database during app startup.
     * This prevents an old backup from silently replacing newer user data.
     */
    fun restoreCanonicalIfPresent(context: Context): Boolean {
        val dbFile = DbHelper.databaseFile(context)
        if (dbFile.exists() && dbFile.length() >= 4096L) return false
        return try {
            val source = findCanonical(context) ?: return false
            val tmp = File(context.cacheDir, "canonical_database.tmp")
            context.contentResolver.openInputStream(source)?.use { input ->
                FileOutputStream(tmp, false).use { output -> input.copyTo(output) }
            } ?: error("فایل اصلی قابل خواندن نیست")
            validateDatabase(tmp)
            dbFile.parentFile?.mkdirs()
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { input.copyTo(it) } }
            tmp.delete()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun maybeAutoBackup(context: Context) {
        if (AppPrefs.prefs(context).getBoolean(AppPrefs.AUTO_BACKUP, true)) backup(context, true)
    }

    fun restore(context: Context, uri: Uri): Boolean {
        val dbFile = DbHelper.databaseFile(context)
        val tmp = File(context.cacheDir, "restore_candidate.db")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp, false).use { input.copyTo(it) }
            } ?: error("فایل قابل خواندن نیست")
            validateDatabase(tmp)
            dbFile.parentFile?.mkdirs()
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            FileInputStream(tmp).use { input -> FileOutputStream(dbFile, false).use { input.copyTo(it) } }
            tmp.delete()
            // The restored data immediately becomes the one canonical external backup.
            backup(context, true)
            true
        } catch (e: Exception) {
            tmp.delete()
            Toast.makeText(context, "خطا در بازیابی: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun checkpoint(context: Context) {
        val helper = DbHelper(context)
        try {
            helper.writableDatabase.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
        } finally {
            helper.close()
        }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < 4096L) error("فایل پشتیبان خالی یا ناقص است")
        val db = android.database.sqlite.SQLiteDatabase.openDatabase(file.path, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf("folders", "notebooks", "tx", "invoices", "invoice_items", "installment_plans", "installment_items", "checks")
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { while (it.moveToNext()) found += it.getString(0) }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار من نیست")
            val ok = db.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0).equals("ok", true) }
            if (!ok) error("فایل پشتیبان آسیب‌دیده است")
            val version = db.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        } finally {
            db.close()
        }
    }

    /** Return the newest exact canonical file; duplicate cleanup is handled separately. */
    private fun findCanonical(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            resolver.query(
                collection,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
                arrayOf(CANONICAL_NAME, CANONICAL_RELATIVE_PATH),
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                if (c.moveToFirst()) return Uri.withAppendedPath(collection, c.getLong(0).toString())
            }
            return null
        }
        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman/$CANONICAL_NAME")
        return if (file.exists()) Uri.fromFile(file) else null
    }

    private fun writeCanonicalMediaStore(context: Context, src: File) {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI

        // First normalize the directory: exactly one canonical file may remain.
        cleanupDuplicateCanonicalEntries(context)
        var uri = findCanonical(context)

        if (uri == null) {
            uri = resolver.insert(collection, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, CANONICAL_NAME)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                put(MediaStore.Downloads.RELATIVE_PATH, CANONICAL_RELATIVE_PATH)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }) ?: error("امکان ساخت فایل اصلی وجود ندارد")
        }

        resolver.openOutputStream(uri, "wt")?.use { out ->
            FileInputStream(src).use { input -> input.copyTo(out) }
        } ?: error("امکان نوشتن فایل اصلی وجود ندارد")

        // If it was newly inserted, publish it. Existing files are already published.
        try {
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (_: Exception) { /* already published on older MediaStore implementations */ }

        // A second cleanup catches stale suffixed files left by older app versions.
        cleanupDuplicateCanonicalEntries(context)
    }

    /**
     * Delete every variant whose name begins with hesabdar_database, then keep only
     * the newest exact canonical file. This removes files like (1), (2), ... created
     * by older versions or interrupted MediaStore writes.
     */
    private fun cleanupDuplicateCanonicalEntries(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val rows = mutableListOf<Triple<Long, String, Int>>()
        resolver.query(
            collection,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
            arrayOf(CANONICAL_RELATIVE_PATH, "$CANONICAL_NAME%"),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            while (c.moveToNext()) rows += Triple(c.getLong(0), c.getString(1), c.getInt(2))
        }

        var keptExact = false
        for ((id, name, pending) in rows) {
            val uri = Uri.withAppendedPath(collection, id.toString())
            val keep = name == CANONICAL_NAME && pending == 0 && !keptExact
            if (keep) {
                keptExact = true
            } else {
                resolver.delete(uri, null, null)
            }
        }
    }

    private fun writeCanonicalLegacy(src: File) {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman")
        if (!dir.exists()) dir.mkdirs()
        // Remove old suffixed copies from legacy storage as well.
        dir.listFiles()?.filter { it.name.startsWith(CANONICAL_NAME) && it.name != CANONICAL_NAME }
            ?.forEach { it.delete() }
        FileInputStream(src).use { input -> FileOutputStream(File(dir, CANONICAL_NAME), false).use { input.copyTo(it) } }
    }
}
