package com.mobileshahab.hesabeman

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityNotebookBinding

class NotebookActivity : BaseActivity() {
    private lateinit var b: ActivityNotebookBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: TxAdapter
    private var notebookId = 0L
    private var notebookName = "حساب"
    private var phone = ""

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) PdfExporter.export(this, uri, notebookName, db.txRecords(notebookId), db.balance(notebookId))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNotebookBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this); notebookId = intent.getLongExtra("notebook_id", 0); loadNotebookInfo()
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material); b.toolbar.setNavigationOnClickListener { finish() }
        adapter = TxAdapter(emptyList()) { editTransaction(it) }
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter
        b.addDebt.setOnClickListener { add("debt", "پرداخت کردم") }
        b.addCredit.setOnClickListener { add("credit", "دریافت کردم") }
        b.call.setOnClickListener { callPerson() }; b.sms.setOnClickListener { sendBalanceSms() }
        b.dueDate.setOnClickListener { editDueDate() }
        b.exportPdf.setOnClickListener { pdfPicker.launch("${notebookName.replace("/", "-")}.pdf") }
        b.phoneText.setOnClickListener { if (phone.isBlank()) editPhone() else callPerson() }; b.editPhone.setOnClickListener { editPhone() }
        b.personName.setOnClickListener { editName() }
    }

    private fun loadNotebookInfo() {
        val info = db.notebookInfo(notebookId); notebookName = info.name; phone = info.phone
        b.toolbar.title = notebookName; b.personName.text = notebookName
        b.avatar.text = notebookName.trim().firstOrNull()?.toString() ?: "ح"
        b.phoneText.text = if (phone.isBlank()) "شماره موبایل ثبت نشده" else phone
    }

    private fun add(kind: String, title: String) {
        promptTransaction(this, title) { amount, note, dateTime ->
            if (db.addTx(notebookId, kind, amount, note, dateTime) > 0L) refresh()
            else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
        }
    }

    private fun editTransaction(record: TxRecord) {
        promptTransaction(this, "ویرایش تراکنش", record.amount, record.note, record.createdAt) { amount, note, dateTime ->
            if (db.updateTx(record.id, amount, note, dateTime)) refresh()
            else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
        }
    }

    private fun editName() {
        promptText(this, "نام حساب", notebookName) { value ->
            if (db.updateNotebookName(notebookId, value)) {
                loadNotebookInfo()
                Toast.makeText(this, "نام حساب تغییر کرد.", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "نام حساب نمی‌تواند خالی باشد.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editPhone() { promptText(this, "شماره موبایل", "مثال: 09123456789") { db.updateNotebookPhone(notebookId, it); loadNotebookInfo() } }
    private fun editDueDate() {
        val current = db.notebookInfo(notebookId).dueDate
        promptText(this, "تاریخ سررسید بدهی", if (current.isBlank()) "مثال: 1405/06/15" else current) {
            db.setDueDate(notebookId, it); Toast.makeText(this, "تاریخ سررسید ذخیره شد.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun callPerson() {
        if (phone.isBlank()) { Toast.makeText(this, "ابتدا شماره موبایل را برای این حساب ثبت کنید.", Toast.LENGTH_LONG).show(); editPhone(); return }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    }

    private fun sendBalanceSms() {
        if (phone.isBlank()) { Toast.makeText(this, "ابتدا شماره موبایل را برای این حساب ثبت کنید.", Toast.LENGTH_LONG).show(); editPhone(); return }
        val credit = db.totalCredit(notebookId); val debt = db.totalDebt(notebookId); val net = credit - debt
        val message = buildString {
            append("با سلام $notebookName\n")
            append("گزارش مانده حساب شما:\n")
            append("کل پرداختی: ${formatMoney(debt)} تومان\n")
            append("کل دریافتی: ${formatMoney(credit)} تومان\n")
            when {
                net < 0L -> {
                    append("مانده بدهکاری: ${formatMoney(-net)} تومان\n")
                    append("لطفاً حساب خود را تسویه نمایید.\n")
                }
                net > 0L -> {
                    append("مانده بستانکاری: ${formatMoney(net)} تومان\n")
                    append("این مبلغ مانده طلب شماست.\n")
                }
                else -> append("وضعیت حساب: تسویه شده\n")
            }
            append("نرم افزار حسابدار من")
        }
        MaterialAlertDialogBuilder(this).setTitle("ارسال مانده حساب").setMessage(message)
            .setPositiveButton("ارسال پیامک") { _, _ -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", message)) }
            .setNegativeButton("انصراف", null).show()
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        loadNotebookInfo(); adapter.submit(db.txRecords(notebookId))
        val credit = db.totalCredit(notebookId); val debt = db.totalDebt(notebookId); val x = credit - debt
        b.totalCredit.text = "${formatMoney(credit)} تومان"; b.totalDebt.text = "${formatMoney(debt)} تومان"
        b.balance.text = "${formatMoney(kotlin.math.abs(x))} تومان ${when { x > 0 -> "بستانکار"; x < 0 -> "بدهکار"; else -> "تسویه" }}"
        b.balance.setTextColor(getColor(when { x > 0 -> R.color.credit_text; x < 0 -> R.color.debt_text; else -> R.color.neutral_text }))
    }
    private fun formatMoney(value: Long) = "%,d".format(value)
}
