package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivitySearchBinding

class SearchActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySearchBinding.inflate(layoutInflater); setContentView(b.root)
        val db = DbHelper(this)
        val pendingAction = intent.getStringExtra("pending_action")
        val adapter = SearchResultAdapter(emptyList()) { hit ->
            if (hit.type == "folder") {
                startActivity(Intent(this, FolderActivity::class.java)
                    .putExtra("folder_id", hit.id).putExtra("folder_name", hit.targetName))
            } else {
                startActivity(Intent(this, NotebookActivity::class.java)
                    .putExtra("notebook_id", hit.id).putExtra("notebook_name", hit.targetName).apply {
                        if (pendingAction != null) putExtra("pending_action", pendingAction)
                    })
                if (pendingAction != null) finish()
            }
        }
        b.results.layoutManager = LinearLayoutManager(this)
        b.results.adapter = adapter
        b.toolbar.title = when (pendingAction) {
            "invoice" -> "انتخاب حساب برای صدور فاکتور"
            "installment" -> "انتخاب حساب برای ثبت اقساط"
            "check" -> "انتخاب حساب برای صدور چک"
            "pay" -> "انتخاب حساب برای ثبت پرداخت"
            "receive" -> "انتخاب حساب برای ثبت دریافت"
            else -> "جستجوی حسابدار من"
        }
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.search.setOnClickListener {
            val q = b.query.text.toString().trim()
            if (q.isBlank()) {
                adapter.submit(emptyList())
                b.empty.visibility = View.VISIBLE
                b.empty.text = "عبارت جستجو را وارد کنید."
            } else {
                val hits = db.search(q)
                adapter.submit(hits)
                b.empty.visibility = if (hits.isEmpty()) View.VISIBLE else View.GONE
                b.empty.text = "نتیجه‌ای پیدا نشد."
            }
        }
    }
}
