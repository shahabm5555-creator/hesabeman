package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RowItem(val id: Long, val title: String)
data class FolderItem(val id: Long, val name: String, val color: String, val sortOrder: Int)
data class SearchHit(val id: Long, val type: String, val title: String, val targetName: String)
data class TxRecord(val id: Long, val kind: String, val amount: Long, val note: String, val createdAt: String)
data class NotebookInfo(val id: Long, val name: String, val phone: String)
data class AccountSummary(val totalDebt: Long, val totalCredit: Long, val balance: Long, val debtors: Int, val creditors: Int)

class DbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 4) {
    companion object { const val DB_NAME = "hesabeman.db" }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE folders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER,
            name TEXT NOT NULL,
            color TEXT NOT NULL DEFAULT '#E4EFEC',
            sort_order INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE notebooks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT ''
        )""")
        db.execSQL("""CREATE TABLE tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notebook_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            try { db.execSQL("ALTER TABLE notebooks ADD COLUMN phone TEXT NOT NULL DEFAULT ''") } catch (_: Exception) { }
        }
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE folders ADD COLUMN color TEXT NOT NULL DEFAULT '#E4EFEC'") } catch (_: Exception) { }
            try { db.execSQL("ALTER TABLE folders ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0") } catch (_: Exception) { }
            try { db.execSQL("UPDATE folders SET sort_order=id WHERE sort_order=0") } catch (_: Exception) { }
        }
        if (oldVersion < 4) {
            // زیرپوشه در نسخه 1.0.4 حذف شده است؛ دفترچه‌های قدیمی به پوشه اصلی منتقل می‌شوند.
            try {
                db.execSQL("""UPDATE notebooks SET folder_id=(
                    SELECT parent_id FROM folders WHERE folders.id=notebooks.folder_id
                ) WHERE folder_id IN (SELECT id FROM folders WHERE parent_id IS NOT NULL)""")
                db.execSQL("DELETE FROM folders WHERE parent_id IS NOT NULL")
            } catch (_: Exception) { }
        }
    }

    fun addFolder(parentId: Long?, name: String): Boolean {
        if (parentId != null) return false
        if (countFolders(null) >= 10) return false
        val nextOrder = readableDatabase.rawQuery("SELECT COALESCE(MAX(sort_order),0)+1 FROM folders WHERE parent_id IS NULL", null).use {
            if (it.moveToFirst()) it.getInt(0) else 1
        }
        return writableDatabase.insert("folders", null, ContentValues().apply {
            putNull("parent_id")
            put("name", name)
            put("color", "#E4EFEC")
            put("sort_order", nextOrder)
        }) != -1L
    }

    fun folderItems(): List<FolderItem> {
        val out = mutableListOf<FolderItem>()
        readableDatabase.rawQuery(
            "SELECT id,name,color,sort_order FROM folders WHERE parent_id IS NULL ORDER BY sort_order ASC,id ASC", null
        ).use {
            while (it.moveToNext()) out += FolderItem(it.getLong(0), it.getString(1), it.getString(2), it.getInt(3))
        }
        return out
    }

    fun folders(parentId: Long?): List<RowItem> = if (parentId == null) folderItems().map { RowItem(it.id, it.name) } else emptyList()

    fun countFolders(parentId: Long?): Int {
        if (parentId != null) return 0
        readableDatabase.rawQuery("SELECT COUNT(*) FROM folders WHERE parent_id IS NULL", null).use { if (it.moveToFirst()) return it.getInt(0) }
        return 0
    }

    fun parentId(folderId: Long): Long? = null

    fun renameFolder(folderId: Long, name: String) {
        writableDatabase.update("folders", ContentValues().apply { put("name", name.trim()) }, "id=?", arrayOf(folderId.toString()))
    }

    fun setFolderColor(folderId: Long, color: String) {
        writableDatabase.update("folders", ContentValues().apply { put("color", color) }, "id=?", arrayOf(folderId.toString()))
    }

    fun moveFolder(folderId: Long, direction: Int) {
        val items = folderItems().toMutableList()
        val index = items.indexOfFirst { it.id == folderId }
        val target = index + direction
        if (index < 0 || target !in items.indices) return
        val a = items[index]
        val b = items[target]
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.update("folders", ContentValues().apply { put("sort_order", b.sortOrder) }, "id=?", arrayOf(a.id.toString()))
            db.update("folders", ContentValues().apply { put("sort_order", a.sortOrder) }, "id=?", arrayOf(b.id.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addNotebook(folderId: Long, name: String, phone: String = ""): Boolean {
        if (countNotebooks(folderId) >= 30) return false
        return writableDatabase.insert("notebooks", null, ContentValues().apply {
            put("folder_id", folderId); put("name", name); put("phone", phone.trim())
        }) != -1L
    }

    fun countNotebooks(folderId: Long): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notebooks WHERE folder_id=?", arrayOf(folderId.toString())).use {
            if (it.moveToFirst()) return it.getInt(0)
        }
        return 0
    }

    fun notebooks(folderId: Long): List<RowItem> {
        val out = mutableListOf<RowItem>()
        readableDatabase.rawQuery(
            "SELECT id,name,phone FROM notebooks WHERE folder_id=? ORDER BY id DESC",
            arrayOf(folderId.toString())
        ).use {
            while (it.moveToNext()) {
                val phone = it.getString(2).orEmpty()
                val subtitle = if (phone.isBlank()) "" else "\n$phone"
                out += RowItem(it.getLong(0), it.getString(1) + subtitle)
            }
        }
        return out
    }

    fun notebookInfo(notebookId: Long): NotebookInfo {
        readableDatabase.rawQuery("SELECT id,name,phone FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) return NotebookInfo(it.getLong(0), it.getString(1), it.getString(2).orEmpty())
        }
        return NotebookInfo(notebookId, "دفترچه حساب", "")
    }

    fun notebookName(notebookId: Long): String = notebookInfo(notebookId).name

    fun updateNotebookPhone(notebookId: Long, phone: String) {
        writableDatabase.update("notebooks", ContentValues().apply { put("phone", phone.trim()) }, "id=?", arrayOf(notebookId.toString()))
    }

    fun addTx(notebookId: Long, kind: String, amount: Long, note: String, date: String) {
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("notebook_id", notebookId); put("kind", kind); put("amount", amount)
            put("note", note); put("created_at", date)
        })
    }

    fun updateTx(txId: Long, amount: Long, note: String, date: String) {
        writableDatabase.update("tx", ContentValues().apply {
            put("amount", amount); put("note", note); put("created_at", date)
        }, "id=?", arrayOf(txId.toString()))
    }

    fun txRecords(notebookId: Long): List<TxRecord> {
        val out = mutableListOf<TxRecord>()
        readableDatabase.rawQuery(
            "SELECT id,kind,amount,note,created_at FROM tx WHERE notebook_id=? ORDER BY id DESC",
            arrayOf(notebookId.toString())
        ).use {
            while (it.moveToNext()) out += TxRecord(
                it.getLong(0), it.getString(1), it.getLong(2), it.getString(3).orEmpty(), it.getString(4)
            )
        }
        return out
    }

    fun tx(notebookId: Long): List<RowItem> = txRecords(notebookId).map {
        val kind = if (it.kind == "debt") "بدهکار" else "بستانکار"
        RowItem(it.id, "$kind — ${"%,d".format(it.amount)} تومان\n${it.note}\n${it.createdAt}")
    }

    fun totalCredit(notebookId: Long): Long = totalByKind(notebookId, "credit")
    fun totalDebt(notebookId: Long): Long = totalByKind(notebookId, "debt")

    private fun totalByKind(notebookId: Long, kind: String): Long {
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE notebook_id=? AND kind=?",
            arrayOf(notebookId.toString(), kind)
        ).use { if (it.moveToFirst()) return it.getLong(0) }
        return 0
    }

    fun balance(notebookId: Long): Long = totalCredit(notebookId) - totalDebt(notebookId)

    fun accountSummary(): AccountSummary {
        val debt = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE kind='debt'", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        val credit = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE kind='credit'", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        var debtors = 0
        var creditors = 0
        readableDatabase.rawQuery("""SELECT n.id,
            COALESCE(SUM(CASE WHEN t.kind='credit' THEN t.amount ELSE 0 END),0)-
            COALESCE(SUM(CASE WHEN t.kind='debt' THEN t.amount ELSE 0 END),0) AS bal
            FROM notebooks n LEFT JOIN tx t ON t.notebook_id=n.id GROUP BY n.id""", null).use {
            while (it.moveToNext()) {
                val b = it.getLong(1)
                if (b < 0) debtors++ else if (b > 0) creditors++
            }
        }
        return AccountSummary(debt, credit, credit - debt, debtors, creditors)
    }

    fun search(q: String): List<SearchHit> {
        val x = "%$q%"
        val out = mutableListOf<SearchHit>()
        readableDatabase.rawQuery("SELECT id,name FROM folders WHERE parent_id IS NULL AND name LIKE ? LIMIT 20", arrayOf(x)).use {
            while (it.moveToNext()) out += SearchHit(it.getLong(0), "folder", "پوشه: ${it.getString(1)}", it.getString(1))
        }
        readableDatabase.rawQuery("SELECT id,name,phone FROM notebooks WHERE name LIKE ? OR phone LIKE ? LIMIT 30", arrayOf(x, x)).use {
            while (it.moveToNext()) {
                val name = it.getString(1)
                val phone = it.getString(2).orEmpty()
                out += SearchHit(it.getLong(0), "notebook", "دفترچه: $name${if (phone.isBlank()) "" else " — $phone"}", name)
            }
        }
        readableDatabase.rawQuery(
            """SELECT t.notebook_id,n.name,t.kind,t.amount,t.note,t.created_at
               FROM tx t JOIN notebooks n ON n.id=t.notebook_id
               WHERE t.note LIKE ? OR CAST(t.amount AS TEXT) LIKE ? LIMIT 30""",
            arrayOf(x, x)
        ).use {
            while (it.moveToNext()) {
                val kind = if (it.getString(2) == "debt") "بدهکار" else "بستانکار"
                val display = "${it.getString(1)} — $kind — ${"%,d".format(it.getLong(3))} تومان\n${it.getString(4).orEmpty()} | ${it.getString(5)}"
                out += SearchHit(it.getLong(0), "notebook", display, it.getString(1))
            }
        }
        return out
    }
}
