package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter

    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("بازیابی پشتیبان")
                .setMessage("اطلاعات فعلی برنامه با اطلاعات این پشتیبان جایگزین شود؟")
                .setPositiveButton("بازیابی") { _, _ ->
                    db.close()
                    if (BackupManager.restore(this, uri)) {
                        Toast.makeText(this, "بازیابی با موفقیت انجام شد.", Toast.LENGTH_LONG).show()
                        db = DbHelper(this); refresh()
                    } else db = DbHelper(this)
                }
                .setNegativeButton("انصراف", null).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        adapter = FolderGridAdapter(emptyList(),
            onClick = { startActivity(Intent(this, FolderActivity::class.java).putExtra("folder_id", it.id).putExtra("folder_name", it.name)) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = GridLayoutManager(this, 2); b.list.adapter = adapter
        b.add.setOnClickListener {
            if (db.countFolders(null) >= 10) Toast.makeText(this, "حداکثر ۱۰ پوشه اصلی مجاز است.", Toast.LENGTH_LONG).show()
            else promptText(this, "پوشه جدید", "نام پوشه") { name -> if (db.addFolder(null, name)) refresh() }
        }
        b.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.search -> startActivity(Intent(this, SearchActivity::class.java))
                R.id.backup -> BackupManager.backup(this)
                R.id.restore -> restorePicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "*/*"))
                R.id.settings -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.about -> startActivity(Intent(this, AboutActivity::class.java))
            }; true
        }
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ", "انتقال به بالا", "انتقال به پایین")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
                2 -> { db.moveFolder(item.id, -1); refresh() }
                3 -> { db.moveFolder(item.id, 1); refresh() }
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        val names = arrayOf("سبز ملایم", "آبی ملایم", "کرم", "بنفش ملایم", "صورتی ملایم", "خاکستری روشن")
        val colors = arrayOf("#DCEFE5", "#DCEAF5", "#F4EEDB", "#E9E1F3", "#F4E1E5", "#E7EBEC")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which ->
            db.setFolderColor(item.id, colors[which]); refresh()
        }.show()
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        val items = db.folderItems(); adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val s = db.accountSummary()
        b.totalDebt.text = "${formatMoney(s.totalDebt)} تومان"
        b.totalCredit.text = "${formatMoney(s.totalCredit)} تومان"
        b.totalBalance.text = "${formatMoney(kotlin.math.abs(s.balance))} تومان ${when { s.balance < 0 -> "بدهکار"; s.balance > 0 -> "بستانکار"; else -> "تسویه" }}"
        b.debtorCount.text = "${s.debtors} نفر"
        b.creditorCount.text = "${s.creditors} نفر"
    }
    private fun formatMoney(value: Long) = "%,d".format(value)
}
