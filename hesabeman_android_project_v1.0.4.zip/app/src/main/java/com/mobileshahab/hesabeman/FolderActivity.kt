package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivityFolderBinding

class FolderActivity : BaseActivity() {
    private lateinit var b: ActivityFolderBinding
    private lateinit var db: DbHelper
    private lateinit var notebookAdapter: SimpleAdapter
    private var folderId = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFolderBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        folderId = intent.getLongExtra("folder_id", 0)
        b.toolbar.title = intent.getStringExtra("folder_name") ?: "پوشه"
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        notebookAdapter = SimpleAdapter(emptyList()) {
            startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", it.id))
        }
        b.notebooks.layoutManager = LinearLayoutManager(this); b.notebooks.adapter = notebookAdapter
        b.addNotebook.setOnClickListener {
            if (db.countNotebooks(folderId) >= 30) Toast.makeText(this, "در هر پوشه حداکثر ۳۰ دفترچه مجاز است.", Toast.LENGTH_LONG).show()
            else promptNotebook(this) { name, phone -> if (db.addNotebook(folderId, name, phone)) refresh() }
        }
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() { notebookAdapter.submit(db.notebooks(folderId)) }
}
