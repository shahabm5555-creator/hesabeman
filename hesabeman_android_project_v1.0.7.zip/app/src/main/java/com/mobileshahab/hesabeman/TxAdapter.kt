package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TxAdapter(
    private var items: List<TxRecord>,
    private val onLongClick: (TxRecord) -> Unit
) : RecyclerView.Adapter<TxAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: com.google.android.material.card.MaterialCardView = view.findViewById(R.id.txCard)
        val header: TextView = view.findViewById(R.id.txHeader)
        val rowNo: TextView = view.findViewById(R.id.txRowNo)
        val note: TextView = view.findViewById(R.id.txNote)
        val date: TextView = view.findViewById(R.id.txDate)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
    )
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val x = items[position]; val isDebt = x.kind == "debt"; val ctx = holder.itemView.context
        holder.card.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_soft else R.color.credit_soft))
        holder.header.setBackgroundColor(ContextCompat.getColor(ctx, R.color.tx_header))
        holder.header.setTextColor(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_accent else R.color.credit_accent))
        holder.header.text = "${if (isDebt) "↑  پرداخت کردم" else "↓  دریافت کردم"}   ${"%,d".format(x.amount)} تومان"
        holder.rowNo.text = "ردیف ${items.size - position}"
        holder.note.text = if (x.note.isBlank()) "بدون توضیحات" else x.note
        holder.date.text = x.createdAt.replace(" - ", "\n")
        holder.itemView.setOnLongClickListener { onLongClick(x); true }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<TxRecord>) { items = newItems; notifyDataSetChanged() }
}
