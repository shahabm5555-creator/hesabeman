package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RowItem(val id: Long, val title: String)
data class FolderItem(val id: Long, val name: String, val color: String, val sortOrder: Int, val notebookCount: Int)
data class NotebookListItem(val id: Long, val name: String, val phone: String, val balance: Long, val dueDate: String = "", val sortOrder: Int = 0)
data class SearchHit(val id: Long, val type: String, val title: String, val targetName: String)
data class TxRecord(val id: Long, val kind: String, val amount: Long, val note: String, val createdAt: String)
data class NotebookInfo(val id: Long, val name: String, val phone: String, val dueDate: String)
data class AccountSummary(val totalDebt: Long, val totalCredit: Long, val balance: Long, val debtors: Int, val creditors: Int)
data class TrashItem(val id: Long, val type: String, val title: String, val deletedAt: Long)
data class MonthlySummary(val debt: Long, val credit: Long, val txCount: Int)

class DbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 10) {
    companion object {
        const val DB_NAME = "hesabeman.db"
        const val MAX_FOLDERS = 30
        const val MAX_ACCOUNTS_PER_FOLDER = 500
    }

    private fun normalizeFolderOrders(db: SQLiteDatabase = writableDatabase) {
        val ids = mutableListOf<Long>()
        db.rawQuery("SELECT id FROM folders WHERE parent_id IS NULL AND deleted_at IS NULL ORDER BY sort_order ASC,id ASC", null).use {
            while (it.moveToNext()) ids += it.getLong(0)
        }
        ids.forEachIndexed { index, id ->
            db.update("folders", ContentValues().apply { put("sort_order", index + 1) }, "id=?", arrayOf(id.toString()))
        }
    }

    private fun normalizeAccountOrders(folderId: Long, db: SQLiteDatabase = writableDatabase) {
        val ids = mutableListOf<Long>()
        db.rawQuery("""SELECT id FROM notebooks
            WHERE folder_id=? AND archived=0 AND deleted_at IS NULL
            ORDER BY sort_order ASC,id ASC""", arrayOf(folderId.toString())).use {
            while (it.moveToNext()) ids += it.getLong(0)
        }
        ids.forEachIndexed { index, id ->
            db.update("notebooks", ContentValues().apply { put("sort_order", index + 1) }, "id=?", arrayOf(id.toString()))
        }
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE folders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER,
            name TEXT NOT NULL,
            color TEXT NOT NULL DEFAULT '#DCEFE5',
            sort_order INTEGER NOT NULL DEFAULT 0,
            deleted_at INTEGER
        )""")
        db.execSQL("""CREATE TABLE notebooks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            archived INTEGER NOT NULL DEFAULT 0,
            deleted_at INTEGER,
            due_date TEXT NOT NULL DEFAULT '',
            sort_order INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notebook_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_folders_active_order ON folders(deleted_at, sort_order, id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notebooks_folder_active_order ON notebooks(folder_id, deleted_at, archived, sort_order, id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notebooks_deleted_at ON notebooks(deleted_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_notebook_created ON tx(notebook_id, created_at, id)")
        db.execSQL("""CREATE TABLE invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notebook_id INTEGER NOT NULL,
            invoice_number INTEGER NOT NULL DEFAULT 1,
            kind TEXT NOT NULL DEFAULT 'debt',
            created_at TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT ''
        )""")
        db.execSQL("""CREATE TABLE invoice_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            qty INTEGER NOT NULL DEFAULT 1,
            unit_price INTEGER NOT NULL DEFAULT 0
        )""")
        val defaults = listOf("همکار", "مشتری", "خانواده", "دوستان")
        defaults.forEachIndexed { index, name ->
            db.insert("folders", null, ContentValues().apply {
                put("name", name); put("color", "#DCEFE5"); put("sort_order", index + 1)
            })
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) try { db.execSQL("ALTER TABLE notebooks ADD COLUMN phone TEXT NOT NULL DEFAULT ''") } catch (_: Exception) {}
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE folders ADD COLUMN color TEXT NOT NULL DEFAULT '#DCEFE5'") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE folders ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("UPDATE folders SET sort_order=id WHERE sort_order=0") } catch (_: Exception) {}
        }
        if (oldVersion < 4) {
            try {
                db.execSQL("""UPDATE notebooks SET folder_id=(SELECT parent_id FROM folders WHERE folders.id=notebooks.folder_id)
                    WHERE folder_id IN (SELECT id FROM folders WHERE parent_id IS NOT NULL)""")
                db.execSQL("DELETE FROM folders WHERE parent_id IS NOT NULL")
            } catch (_: Exception) {}
        }
        if (oldVersion < 6) {
            try { db.execSQL("ALTER TABLE folders ADD COLUMN deleted_at INTEGER") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE notebooks ADD COLUMN archived INTEGER NOT NULL DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE notebooks ADD COLUMN deleted_at INTEGER") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE notebooks ADD COLUMN due_date TEXT NOT NULL DEFAULT ''") } catch (_: Exception) {}
        }
        if (oldVersion < 7) {
            try { db.execSQL("ALTER TABLE notebooks ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0") } catch (_: Exception) {}
            try {
                val folderIds = mutableListOf<Long>()
                db.rawQuery("SELECT id FROM folders", null).use { while (it.moveToNext()) folderIds += it.getLong(0) }
                folderIds.forEach { folderId ->
                    var order = 1
                    db.rawQuery("SELECT id FROM notebooks WHERE folder_id=? ORDER BY CASE WHEN sort_order>0 THEN sort_order ELSE id END,id", arrayOf(folderId.toString())).use { c ->
                        while (c.moveToNext()) {
                            db.update("notebooks", ContentValues().apply { put("sort_order", order++) }, "id=?", arrayOf(c.getLong(0).toString()))
                        }
                    }
                    normalizeAccountOrders(folderId, db)
                }
                normalizeFolderOrders(db)
            } catch (_: Exception) {}
        }
        if (oldVersion < 8) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_folders_active_order ON folders(deleted_at, sort_order, id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_notebooks_folder_active_order ON notebooks(folder_id, deleted_at, archived, sort_order, id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_notebooks_deleted_at ON notebooks(deleted_at)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_notebook_created ON tx(notebook_id, created_at, id)")
        }
        if (oldVersion < 9) {
            val hasFolders = db.rawQuery("SELECT COUNT(*) FROM folders WHERE deleted_at IS NULL AND parent_id IS NULL", null).use { it.moveToFirst() && it.getInt(0) > 0 }
            if (!hasFolders) {
                listOf("همکار", "مشتری", "خانواده", "دوستان").forEachIndexed { index, name ->
                    db.insert("folders", null, ContentValues().apply { put("name", name); put("color", "#DCEFE5"); put("sort_order", index + 1) })
                }
            }
        }
        if (oldVersion < 10) {
            try { db.execSQL("""CREATE TABLE IF NOT EXISTS invoices(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                notebook_id INTEGER NOT NULL,
                invoice_number INTEGER NOT NULL DEFAULT 1,
                kind TEXT NOT NULL DEFAULT 'debt',
                created_at TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT ''
            )""") } catch (_: Exception) {}
            try { db.execSQL("""CREATE TABLE IF NOT EXISTS invoice_items(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                qty INTEGER NOT NULL DEFAULT 1,
                unit_price INTEGER NOT NULL DEFAULT 0
            )""") } catch (_: Exception) {}
        }
    }

    fun addFolder(parentId: Long?, name: String): Boolean {
        if (parentId != null || countFolders(null) >= MAX_FOLDERS) return false
        normalizeFolderOrders()
        val nextOrder = countFolders(null) + 1
        return writableDatabase.insert("folders", null, ContentValues().apply {
            putNull("parent_id"); put("name", name.trim()); put("color", "#DCEFE5"); put("sort_order", nextOrder); putNull("deleted_at")
        }) != -1L
    }

    fun folderItems(): List<FolderItem> {
        val out = mutableListOf<FolderItem>()
        readableDatabase.rawQuery("""SELECT f.id,f.name,f.color,f.sort_order,
            (SELECT COUNT(*) FROM notebooks n WHERE n.folder_id=f.id AND n.archived=0 AND n.deleted_at IS NULL) AS cnt
            FROM folders f WHERE f.parent_id IS NULL AND f.deleted_at IS NULL ORDER BY f.sort_order ASC,f.id ASC""", null).use {
            while (it.moveToNext()) out += FolderItem(it.getLong(0), it.getString(1), it.getString(2), it.getInt(3), it.getInt(4))
        }
        return out
    }

    fun folders(parentId: Long?): List<RowItem> = if (parentId == null) folderItems().map { RowItem(it.id, it.name) } else emptyList()

    fun countFolders(parentId: Long?): Int {
        if (parentId != null) return 0
        readableDatabase.rawQuery("SELECT COUNT(*) FROM folders WHERE parent_id IS NULL AND deleted_at IS NULL", null).use { if (it.moveToFirst()) return it.getInt(0) }
        return 0
    }

    fun parentId(folderId: Long): Long? = readableDatabase.rawQuery(
        "SELECT parent_id FROM folders WHERE id=?", arrayOf(folderId.toString())
    ).use { c ->
        if (!c.moveToFirst() || c.isNull(0)) null else c.getLong(0)
    }

    fun renameFolder(folderId: Long, name: String) {
        val clean = name.trim(); if (clean.isEmpty()) return
        writableDatabase.update("folders", ContentValues().apply { put("name", clean) }, "id=?", arrayOf(folderId.toString()))
    }

    fun setFolderColor(folderId: Long, color: String) {
        writableDatabase.update("folders", ContentValues().apply { put("color", color) }, "id=?", arrayOf(folderId.toString()))
    }

    fun setFolderOrder(folderId: Long, newOrder: Int) {
        normalizeFolderOrders()
        val items = folderItems()
        val current = items.firstOrNull { it.id == folderId } ?: return
        val target = newOrder.coerceIn(1, items.size.coerceAtLeast(1))
        val oldOrder = current.sortOrder
        if (oldOrder == target) return

        val d = writableDatabase
        d.beginTransaction()
        try {
            if (target < oldOrder) {
                d.execSQL("""UPDATE folders SET sort_order=sort_order+1
                    WHERE parent_id IS NULL AND deleted_at IS NULL
                    AND sort_order>=? AND sort_order<? AND id<>?""",
                    arrayOf<Any>(target, oldOrder, folderId))
            } else {
                d.execSQL("""UPDATE folders SET sort_order=sort_order-1
                    WHERE parent_id IS NULL AND deleted_at IS NULL
                    AND sort_order>? AND sort_order<=? AND id<>?""",
                    arrayOf<Any>(oldOrder, target, folderId))
            }
            d.update("folders", ContentValues().apply { put("sort_order", target) }, "id=?", arrayOf(folderId.toString()))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        normalizeFolderOrders()
    }

    fun moveFolder(folderId: Long, direction: Int) {
        val items = folderItems(); val index = items.indexOfFirst { it.id == folderId }; val target = index + direction
        if (index < 0 || target !in items.indices) return
        setFolderOrder(folderId, items[target].sortOrder)
    }

    fun trashFolder(folderId: Long) {
        val now = System.currentTimeMillis(); val d = writableDatabase; d.beginTransaction()
        try {
            d.update("folders", ContentValues().apply { put("deleted_at", now) }, "id=?", arrayOf(folderId.toString()))
            d.update("notebooks", ContentValues().apply { put("deleted_at", now) }, "folder_id=? AND deleted_at IS NULL", arrayOf(folderId.toString()))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        normalizeFolderOrders()
    }

    fun addNotebook(folderId: Long, name: String, phone: String = ""): Boolean {
        if (countNotebooks(folderId) >= MAX_ACCOUNTS_PER_FOLDER) return false
        normalizeAccountOrders(folderId)
        val nextOrder = countNotebooks(folderId) + 1
        return writableDatabase.insert("notebooks", null, ContentValues().apply {
            put("folder_id", folderId); put("name", name.trim()); put("phone", phone.trim()); put("archived", 0)
            putNull("deleted_at"); put("due_date", ""); put("sort_order", nextOrder)
        }) != -1L
    }

    fun setNotebookOrder(notebookId: Long, newOrder: Int) {
        val folderId = readableDatabase.rawQuery("SELECT folder_id FROM notebooks WHERE id=? AND archived=0 AND deleted_at IS NULL", arrayOf(notebookId.toString())).use {
            if (!it.moveToFirst()) return
            it.getLong(0)
        }
        normalizeAccountOrders(folderId)
        val activeCount = countNotebooks(folderId)
        val currentOrder = readableDatabase.rawQuery("SELECT sort_order FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else return
        }
        val target = newOrder.coerceIn(1, activeCount.coerceAtLeast(1))
        if (target == currentOrder) return

        val d = writableDatabase
        d.beginTransaction()
        try {
            if (target < currentOrder) {
                d.execSQL("""UPDATE notebooks SET sort_order=sort_order+1
                    WHERE folder_id=? AND archived=0 AND deleted_at IS NULL
                    AND sort_order>=? AND sort_order<? AND id<>?""",
                    arrayOf<Any>(folderId, target, currentOrder, notebookId))
            } else {
                d.execSQL("""UPDATE notebooks SET sort_order=sort_order-1
                    WHERE folder_id=? AND archived=0 AND deleted_at IS NULL
                    AND sort_order>? AND sort_order<=? AND id<>?""",
                    arrayOf<Any>(folderId, currentOrder, target, notebookId))
            }
            d.update("notebooks", ContentValues().apply { put("sort_order", target) }, "id=?", arrayOf(notebookId.toString()))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        normalizeAccountOrders(folderId)
    }

    fun countNotebooks(folderId: Long): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notebooks WHERE folder_id=? AND archived=0 AND deleted_at IS NULL", arrayOf(folderId.toString())).use {
            if (it.moveToFirst()) return it.getInt(0)
        }
        return 0
    }

    fun notebooksDetailed(folderId: Long, filter: String = "all", sort: String = "number"): List<NotebookListItem> {
        val out = mutableListOf<NotebookListItem>()
        readableDatabase.rawQuery("""SELECT n.id,n.name,n.phone,n.due_date,n.sort_order,
            COALESCE(SUM(CASE WHEN t.kind='credit' THEN t.amount ELSE 0 END),0)-
            COALESCE(SUM(CASE WHEN t.kind='debt' THEN t.amount ELSE 0 END),0) AS bal
            FROM notebooks n LEFT JOIN tx t ON t.notebook_id=n.id
            WHERE n.folder_id=? AND n.archived=0 AND n.deleted_at IS NULL
            GROUP BY n.id,n.name,n.phone,n.due_date,n.sort_order""", arrayOf(folderId.toString())).use {
            while (it.moveToNext()) out += NotebookListItem(
                it.getLong(0), it.getString(1), it.getString(2).orEmpty(), it.getLong(5), it.getString(3).orEmpty(), it.getInt(4)
            )
        }
        val filtered = when (filter) {
            "debt" -> out.filter { it.balance < 0 }
            "credit" -> out.filter { it.balance > 0 }
            "settled" -> out.filter { it.balance == 0L }
            else -> out
        }
        return when (sort) {
            "debt" -> filtered.sortedBy { it.balance }
            "credit" -> filtered.sortedByDescending { it.balance }
            "name" -> filtered.sortedBy { it.name }
            else -> filtered.sortedWith(compareBy<NotebookListItem> { it.sortOrder }.thenBy { it.id })
        }
    }

    fun notebooks(folderId: Long): List<RowItem> = notebooksDetailed(folderId).map { RowItem(it.id, it.name + if (it.phone.isBlank()) "" else "\n${it.phone}") }

    fun notebookInfo(notebookId: Long): NotebookInfo {
        readableDatabase.rawQuery("SELECT id,name,phone,due_date FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) return NotebookInfo(it.getLong(0), it.getString(1), it.getString(2).orEmpty(), it.getString(3).orEmpty())
        }
        return NotebookInfo(notebookId, "حساب", "", "")
    }

    fun notebookName(notebookId: Long): String = notebookInfo(notebookId).name
    fun updateNotebookPhone(notebookId: Long, phone: String) { writableDatabase.update("notebooks", ContentValues().apply { put("phone", phone.trim()) }, "id=?", arrayOf(notebookId.toString())) }
    fun updateNotebookName(notebookId: Long, name: String): Boolean {
        val clean = name.trim()
        if (clean.isBlank()) return false
        return writableDatabase.update("notebooks", ContentValues().apply { put("name", clean) }, "id=?", arrayOf(notebookId.toString())) > 0
    }
    fun setDueDate(notebookId: Long, date: String) { writableDatabase.update("notebooks", ContentValues().apply { put("due_date", date.trim()) }, "id=?", arrayOf(notebookId.toString())) }
    fun archiveNotebook(notebookId: Long): Boolean {
        if (balance(notebookId) != 0L) return false
        val folderId = readableDatabase.rawQuery("SELECT folder_id FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) it.getLong(0) else return false
        }
        val ok = writableDatabase.update("notebooks", ContentValues().apply { put("archived", 1) }, "id=? AND deleted_at IS NULL", arrayOf(notebookId.toString())) > 0
        if (ok) normalizeAccountOrders(folderId)
        return ok
    }

    fun restoreArchivedNotebook(notebookId: Long): Boolean {
        val folderId = readableDatabase.rawQuery("SELECT folder_id FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) it.getLong(0) else return false
        }
        if (countNotebooks(folderId) >= MAX_ACCOUNTS_PER_FOLDER) return false
        normalizeAccountOrders(folderId)
        return writableDatabase.update("notebooks", ContentValues().apply {
            put("archived", 0); put("sort_order", countNotebooks(folderId) + 1)
        }, "id=?", arrayOf(notebookId.toString())) > 0
    }

    fun trashNotebook(notebookId: Long) {
        val folderId = readableDatabase.rawQuery("SELECT folder_id FROM notebooks WHERE id=?", arrayOf(notebookId.toString())).use {
            if (it.moveToFirst()) it.getLong(0) else return
        }
        writableDatabase.update("notebooks", ContentValues().apply { put("deleted_at", System.currentTimeMillis()) }, "id=?", arrayOf(notebookId.toString()))
        normalizeAccountOrders(folderId)
    }

    fun archivedNotebooks(): List<RowItem> {
        val out = mutableListOf<RowItem>()
        readableDatabase.rawQuery("SELECT id,name FROM notebooks WHERE archived=1 AND deleted_at IS NULL ORDER BY name", null).use { while (it.moveToNext()) out += RowItem(it.getLong(0), it.getString(1)) }
        return out
    }

    fun trashItems(): List<TrashItem> {
        purgeExpiredTrash()
        val out = mutableListOf<TrashItem>()
        readableDatabase.rawQuery("SELECT id,name,deleted_at FROM folders WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC", null).use {
            while (it.moveToNext()) out += TrashItem(it.getLong(0), "folder", "پوشه: ${it.getString(1)}", it.getLong(2))
        }
        readableDatabase.rawQuery("SELECT id,name,deleted_at FROM notebooks WHERE deleted_at IS NOT NULL AND folder_id NOT IN (SELECT id FROM folders WHERE deleted_at IS NOT NULL) ORDER BY deleted_at DESC", null).use {
            while (it.moveToNext()) out += TrashItem(it.getLong(0), "notebook", "حساب: ${it.getString(1)}", it.getLong(2))
        }
        return out.sortedByDescending { it.deletedAt }
    }

    fun restoreTrash(item: TrashItem): Boolean {
        val d = writableDatabase
        if (item.type == "folder") {
            if (countFolders(null) >= MAX_FOLDERS) return false
            normalizeFolderOrders()
            d.beginTransaction()
            try {
                val folderDeletedAt = readableDatabase.rawQuery(
                    "SELECT deleted_at FROM folders WHERE id=?", arrayOf(item.id.toString())
                ).use { c -> if (c.moveToFirst()) c.getLong(0) else return false }
                d.update("folders", ContentValues().apply {
                    putNull("deleted_at"); put("sort_order", countFolders(null) + 1)
                }, "id=? AND deleted_at=?", arrayOf(item.id.toString(), folderDeletedAt.toString()))
                // Only restore accounts deleted together with this folder.
                // Accounts that had already been sent to trash keep their own deletion state.
                d.update("notebooks", ContentValues().apply { putNull("deleted_at") },
                    "folder_id=? AND deleted_at=?", arrayOf(item.id.toString(), folderDeletedAt.toString()))
                d.setTransactionSuccessful()
            } finally { d.endTransaction() }
            normalizeAccountOrders(item.id)
            normalizeFolderOrders()
            return true
        }

        val folderId = readableDatabase.rawQuery("SELECT folder_id FROM notebooks WHERE id=?", arrayOf(item.id.toString())).use {
            if (it.moveToFirst()) it.getLong(0) else return false
        }
        val folderActive = readableDatabase.rawQuery("SELECT COUNT(*) FROM folders WHERE id=? AND deleted_at IS NULL", arrayOf(folderId.toString())).use {
            it.moveToFirst() && it.getInt(0) > 0
        }
        if (!folderActive || countNotebooks(folderId) >= MAX_ACCOUNTS_PER_FOLDER) return false
        normalizeAccountOrders(folderId)
        val ok = d.update("notebooks", ContentValues().apply {
            putNull("deleted_at"); put("sort_order", countNotebooks(folderId) + 1)
        }, "id=?", arrayOf(item.id.toString())) > 0
        normalizeAccountOrders(folderId)
        return ok
    }

    fun purgeExpiredTrash() {
        val cutoff = System.currentTimeMillis() - 5L * 24L * 60L * 60L * 1000L
        val d = writableDatabase; d.beginTransaction()
        try {
            val notebookIds = mutableListOf<Long>()
            d.rawQuery("SELECT id FROM notebooks WHERE deleted_at IS NOT NULL AND deleted_at<?", arrayOf(cutoff.toString())).use { while (it.moveToNext()) notebookIds += it.getLong(0) }
            notebookIds.forEach { d.delete("tx", "notebook_id=?", arrayOf(it.toString())) }
            d.delete("notebooks", "deleted_at IS NOT NULL AND deleted_at<?", arrayOf(cutoff.toString()))
            val folderIds = mutableListOf<Long>()
            d.rawQuery("SELECT id FROM folders WHERE deleted_at IS NOT NULL AND deleted_at<?", arrayOf(cutoff.toString())).use { while (it.moveToNext()) folderIds += it.getLong(0) }
            folderIds.forEach { fid ->
                val ids = mutableListOf<Long>(); d.rawQuery("SELECT id FROM notebooks WHERE folder_id=?", arrayOf(fid.toString())).use { while (it.moveToNext()) ids += it.getLong(0) }
                ids.forEach { d.delete("tx", "notebook_id=?", arrayOf(it.toString())) }
                d.delete("notebooks", "folder_id=?", arrayOf(fid.toString()))
            }
            d.delete("folders", "deleted_at IS NOT NULL AND deleted_at<?", arrayOf(cutoff.toString()))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    fun addTx(notebookId: Long, kind: String, amount: Long, note: String, date: String): Long {
        if (kind !in setOf("debt", "credit") || amount <= 0L || dateTimeKey(date) == 0L) return -1L
        val exists = readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM notebooks WHERE id=? AND archived=0 AND deleted_at IS NULL",
            arrayOf(notebookId.toString())
        ).use { it.moveToFirst() && it.getInt(0) > 0 }
        if (!exists) return -1L
        return writableDatabase.insert("tx", null, ContentValues().apply {
            put("notebook_id", notebookId); put("kind", kind); put("amount", amount);
            put("note", note.trim()); put("created_at", date.trim())
        })
    }

    fun updateTx(txId: Long, amount: Long, note: String, date: String): Boolean {
        if (amount <= 0L || dateTimeKey(date) == 0L) return false
        return writableDatabase.update("tx", ContentValues().apply {
            put("amount", amount); put("note", note.trim()); put("created_at", date.trim())
        }, "id=?", arrayOf(txId.toString())) > 0
    }

    fun updateTxKind(txId: Long, kind: String): Boolean {
        if (kind !in setOf("debt", "credit")) return false
        return writableDatabase.update("tx", ContentValues().apply { put("kind", kind) }, "id=?", arrayOf(txId.toString())) > 0
    }

    fun deleteTx(txId: Long): Boolean = writableDatabase.delete("tx", "id=?", arrayOf(txId.toString())) > 0

    private fun dateTimeKey(value: String): Long {
        val nums = Regex("\\d+").findAll(value).mapNotNull { it.value.toLongOrNull() }.toList(); if (nums.size < 3) return 0L
        val y = nums.getOrElse(0) { 0 }; val m = nums.getOrElse(1) { 0 }; val d = nums.getOrElse(2) { 0 }; val h = nums.getOrElse(3) { 0 }; val min = nums.getOrElse(4) { 0 }
        return (((((y * 100L) + m) * 100L + d) * 100L + h) * 100L + min)
    }

    fun txRecords(notebookId: Long): List<TxRecord> {
        val out = mutableListOf<TxRecord>()
        readableDatabase.rawQuery("SELECT id,kind,amount,note,created_at FROM tx WHERE notebook_id=?", arrayOf(notebookId.toString())).use {
            while (it.moveToNext()) out += TxRecord(it.getLong(0), it.getString(1), it.getLong(2), it.getString(3).orEmpty(), it.getString(4))
        }
        return out.sortedWith(compareByDescending<TxRecord> { dateTimeKey(it.createdAt) }.thenByDescending { it.id })
    }

    fun tx(notebookId: Long): List<RowItem> = txRecords(notebookId).map { RowItem(it.id, "${if (it.kind == "debt") "پرداخت کردم" else "دریافت کردم"} — ${"%,d".format(it.amount)} تومان\n${it.note}\n${it.createdAt}") }
    fun totalCredit(notebookId: Long): Long = totalByKind(notebookId, "credit")
    fun totalDebt(notebookId: Long): Long = totalByKind(notebookId, "debt")
    private fun totalByKind(notebookId: Long, kind: String): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE notebook_id=? AND kind=?", arrayOf(notebookId.toString(), kind)).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    fun balance(notebookId: Long): Long = totalCredit(notebookId) - totalDebt(notebookId)

    fun accountSummary(): AccountSummary {
        val whereActive = "n.archived=0 AND n.deleted_at IS NULL AND n.folder_id IN (SELECT id FROM folders WHERE deleted_at IS NULL)"
        val debt = readableDatabase.rawQuery("SELECT COALESCE(SUM(t.amount),0) FROM tx t JOIN notebooks n ON n.id=t.notebook_id WHERE t.kind='debt' AND $whereActive", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        val credit = readableDatabase.rawQuery("SELECT COALESCE(SUM(t.amount),0) FROM tx t JOIN notebooks n ON n.id=t.notebook_id WHERE t.kind='credit' AND $whereActive", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        var debtors = 0; var creditors = 0
        readableDatabase.rawQuery("""SELECT n.id,COALESCE(SUM(CASE WHEN t.kind='credit' THEN t.amount ELSE 0 END),0)-COALESCE(SUM(CASE WHEN t.kind='debt' THEN t.amount ELSE 0 END),0) AS bal
            FROM notebooks n LEFT JOIN tx t ON t.notebook_id=n.id WHERE $whereActive GROUP BY n.id""", null).use {
            while (it.moveToNext()) { val b = it.getLong(1); if (b < 0) debtors++ else if (b > 0) creditors++ }
        }
        return AccountSummary(debt, credit, credit - debt, debtors, creditors)
    }

    fun monthlySummary(jalaliYearMonth: String): MonthlySummary {
        val like = "$jalaliYearMonth/%"
        var debt = 0L; var credit = 0L; var count = 0
        readableDatabase.rawQuery("""SELECT t.kind,COALESCE(SUM(t.amount),0),COUNT(*) FROM tx t JOIN notebooks n ON n.id=t.notebook_id
            JOIN folders f ON f.id=n.folder_id WHERE t.created_at LIKE ? AND n.deleted_at IS NULL AND n.archived=0 AND f.deleted_at IS NULL GROUP BY t.kind""", arrayOf(like)).use {
            while (it.moveToNext()) { if (it.getString(0) == "debt") debt = it.getLong(1) else credit = it.getLong(1); count += it.getInt(2) }
        }
        return MonthlySummary(debt, credit, count)
    }

    fun dueNotebooks(today: String): List<NotebookListItem> {
        val out = mutableListOf<NotebookListItem>()
        readableDatabase.rawQuery("""SELECT n.id,n.name,n.phone,n.due_date,
            COALESCE(SUM(CASE WHEN t.kind='credit' THEN t.amount ELSE 0 END),0)-COALESCE(SUM(CASE WHEN t.kind='debt' THEN t.amount ELSE 0 END),0) AS bal
            FROM notebooks n LEFT JOIN tx t ON t.notebook_id=n.id JOIN folders f ON f.id=n.folder_id
            WHERE n.due_date<>'' AND n.due_date<=? AND n.archived=0 AND n.deleted_at IS NULL AND f.deleted_at IS NULL
            GROUP BY n.id HAVING bal<0 ORDER BY n.due_date""", arrayOf(today)).use {
            while (it.moveToNext()) out += NotebookListItem(it.getLong(0), it.getString(1), it.getString(2).orEmpty(), it.getLong(4), it.getString(3).orEmpty())
        }
        return out
    }

    // ───────── Invoice ─────────
    fun nextInvoiceNumber(notebookId: Long): Int {
        return readableDatabase.rawQuery(
            "SELECT COALESCE(MAX(invoice_number),0)+1 FROM invoices WHERE notebook_id=?",
            arrayOf(notebookId.toString())
        ).use { if (it.moveToFirst()) it.getInt(0) else 1 }
    }

    fun saveInvoice(notebookId: Long, kind: String, items: List<InvoiceItem>, note: String, date: String): Long {
        val total = items.sumOf { it.total }
        if (total <= 0) return -1L
        val d = writableDatabase
        d.beginTransaction()
        return try {
            val invNum = nextInvoiceNumber(notebookId)
            val invId = d.insert("invoices", null, ContentValues().apply {
                put("notebook_id", notebookId); put("invoice_number", invNum)
                put("kind", kind); put("created_at", date); put("note", note.trim())
            })
            if (invId == -1L) return -1L
            items.forEach { item ->
                d.insert("invoice_items", null, ContentValues().apply {
                    put("invoice_id", invId); put("name", item.name.trim())
                    put("qty", item.qty); put("unit_price", item.unitPrice)
                })
            }
            // Also record as a transaction in the account
            addTx(notebookId, kind, total, "فاکتور شماره $invNum${if (note.isNotBlank()) " — $note" else ""}", date)
            d.setTransactionSuccessful()
            invId
        } finally { d.endTransaction() }
    }

    fun invoiceItems(invoiceId: Long): List<InvoiceItem> {
        val out = mutableListOf<InvoiceItem>()
        readableDatabase.rawQuery(
            "SELECT id,name,qty,unit_price FROM invoice_items WHERE invoice_id=?",
            arrayOf(invoiceId.toString())
        ).use { while (it.moveToNext()) out += InvoiceItem(it.getLong(0), it.getString(1), it.getLong(2), it.getLong(3)) }
        return out
    }

    data class InvoiceHeader(val id: Long, val number: Int, val kind: String, val createdAt: String, val note: String, val total: Long)

    fun invoices(notebookId: Long): List<InvoiceHeader> {
        val out = mutableListOf<InvoiceHeader>()
        readableDatabase.rawQuery("""
            SELECT inv.id, inv.invoice_number, inv.kind, inv.created_at, inv.note,
                   COALESCE(SUM(ii.qty * ii.unit_price), 0) AS total
            FROM invoices inv LEFT JOIN invoice_items ii ON ii.invoice_id = inv.id
            WHERE inv.notebook_id = ?
            GROUP BY inv.id ORDER BY inv.invoice_number DESC""",
            arrayOf(notebookId.toString())
        ).use {
            while (it.moveToNext())
                out += InvoiceHeader(it.getLong(0), it.getInt(1), it.getString(2), it.getString(3), it.getString(4), it.getLong(5))
        }
        return out
    }

    fun search(q: String): List<SearchHit> {
        val x = "%$q%"; val out = mutableListOf<SearchHit>()
        readableDatabase.rawQuery("SELECT id,name FROM folders WHERE parent_id IS NULL AND deleted_at IS NULL AND name LIKE ? LIMIT 20", arrayOf(x)).use {
            while (it.moveToNext()) out += SearchHit(it.getLong(0), "folder", "پوشه: ${it.getString(1)}", it.getString(1))
        }
        readableDatabase.rawQuery("SELECT id,name,phone FROM notebooks WHERE archived=0 AND deleted_at IS NULL AND (name LIKE ? OR phone LIKE ?) LIMIT 30", arrayOf(x, x)).use {
            while (it.moveToNext()) { val name = it.getString(1); val phone = it.getString(2).orEmpty(); out += SearchHit(it.getLong(0), "notebook", "حساب: $name${if (phone.isBlank()) "" else " — $phone"}", name) }
        }
        readableDatabase.rawQuery("""SELECT t.notebook_id,n.name,t.kind,t.amount,t.note,t.created_at FROM tx t JOIN notebooks n ON n.id=t.notebook_id
            WHERE n.archived=0 AND n.deleted_at IS NULL AND (t.note LIKE ? OR CAST(t.amount AS TEXT) LIKE ?) LIMIT 30""", arrayOf(x, x)).use {
            while (it.moveToNext()) {
                val kind = if (it.getString(2) == "debt") "پرداخت کردم" else "دریافت کردم"
                out += SearchHit(it.getLong(0), "notebook", "${it.getString(1)} — $kind — ${"%,d".format(it.getLong(3))} تومان\n${it.getString(4).orEmpty()} | ${it.getString(5)}", it.getString(1))
            }
        }
        return out
    }
}
