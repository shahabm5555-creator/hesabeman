package com.mobileshahab.hesabeman

data class InvoiceItem(
    val id: Long = 0,
    val name: String,
    val qty: Long,
    val unitPrice: Long
) {
    val total: Long get() = qty * unitPrice
}
