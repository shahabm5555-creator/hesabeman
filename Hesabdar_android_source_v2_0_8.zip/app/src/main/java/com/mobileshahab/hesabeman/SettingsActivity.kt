package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivitySettingsBinding

class SettingsActivity : BaseActivity() {
    private lateinit var b: ActivitySettingsBinding
    private lateinit var db: DbHelper

    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) MaterialAlertDialogBuilder(this).setTitle("بازیابی پشتیبان")
            .setMessage("اطلاعات فعلی برنامه با اطلاعات این پشتیبان جایگزین شود؟")
            .setPositiveButton("بازیابی") { _, _ ->
                db.close()
                if (BackupManager.restore(this, uri)) {
                    Toast.makeText(this, "بازیابی با موفقیت انجام شد.", Toast.LENGTH_LONG).show()
                    recreate()
                } else {
                    db = DbHelper(this)
                }
            }
            .setNegativeButton("انصراف", null).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater); setContentView(b.root); db = DbHelper(this)
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material); b.toolbar.setNavigationOnClickListener { finish() }
        b.backup.setOnClickListener { BackupManager.backup(this) }
        b.restore.setOnClickListener { restorePicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "*/*")) }
        b.about.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }

        // ── Seller info for invoice ──
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        b.sellerName.setText(prefs.getString(AppPrefs.SELLER_NAME, ""))
        b.sellerAddress.setText(prefs.getString(AppPrefs.SELLER_ADDRESS, ""))
        b.sellerPhone.setText(prefs.getString(AppPrefs.SELLER_PHONE, ""))
        b.sellerSlogan.setText(prefs.getString(AppPrefs.SELLER_SLOGAN, ""))
        b.saveSellerInfo.setOnClickListener {
            prefs.edit()
                .putString(AppPrefs.SELLER_NAME, b.sellerName.text.toString().trim())
                .putString(AppPrefs.SELLER_ADDRESS, b.sellerAddress.text.toString().trim())
                .putString(AppPrefs.SELLER_PHONE, b.sellerPhone.text.toString().trim())
                .putString(AppPrefs.SELLER_SLOGAN, b.sellerSlogan.text.toString().trim())
                .apply()
            android.widget.Toast.makeText(this, "اطلاعات فروشنده ذخیره شد.", android.widget.Toast.LENGTH_SHORT).show()
        }
        b.archive.setOnClickListener { showArchive() }
        b.trash.setOnClickListener { showTrash() }
        b.monthlyReport.setOnClickListener { askMonthlyReport() }

        val prefs = AppPrefs.prefs(this)
        b.autoBackup.isChecked = prefs.getBoolean(AppPrefs.AUTO_BACKUP, true)
        b.autoBackup.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(AppPrefs.AUTO_BACKUP, checked).apply() }
        when (prefs.getString(AppPrefs.TEXT_SIZE, "normal")) { "medium" -> b.textMedium.isChecked = true; "large" -> b.textLarge.isChecked = true; else -> b.textNormal.isChecked = true }
        when (prefs.getString(AppPrefs.LOCK_MODE, "off")) { "pin" -> b.lockPin.isChecked = true; "biometric" -> b.lockBiometric.isChecked = true; else -> b.lockOff.isChecked = true }
        b.textGroup.setOnCheckedChangeListener { _, id ->
            val value = when (id) { R.id.textMedium -> "medium"; R.id.textLarge -> "large"; else -> "normal" }
            prefs.edit().putString(AppPrefs.TEXT_SIZE, value).apply(); recreate()
        }
        b.lockGroup.setOnCheckedChangeListener { _, id -> when (id) { R.id.lockOff -> prefs.edit().putString(AppPrefs.LOCK_MODE, "off").apply(); R.id.lockPin -> requestPin(); R.id.lockBiometric -> enableBiometric() } }
    }

    private fun showArchive() {
        val items = db.archivedNotebooks()
        if (items.isEmpty()) { Toast.makeText(this, "آرشیو خالی است.", Toast.LENGTH_SHORT).show(); return }
        MaterialAlertDialogBuilder(this).setTitle("آرشیو حساب‌ها").setItems(items.map { it.title }.toTypedArray()) { _, which ->
            val item = items[which]
            MaterialAlertDialogBuilder(this).setTitle(item.title).setMessage("این حساب به لیست فعال برگردد؟")
                .setPositiveButton("بازیابی") { _, _ -> if (db.restoreArchivedNotebook(item.id)) Toast.makeText(this, "حساب بازیابی شد.", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "ظرفیت پوشه تکمیل است و حساب بازیابی نشد.", Toast.LENGTH_LONG).show() }
                .setNegativeButton("انصراف", null).show()
        }.show()
    }

    private fun showTrash() {
        val items = db.trashItems()
        if (items.isEmpty()) { Toast.makeText(this, "سطل زباله خالی است.", Toast.LENGTH_SHORT).show(); return }
        val now = System.currentTimeMillis()
        val labels = items.map {
            val days = ((5L * 24L * 60L * 60L * 1000L - (now - it.deletedAt)).coerceAtLeast(0L) / (24L * 60L * 60L * 1000L)) + 1
            "${it.title} — $days روز مانده"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle("سطل زباله").setItems(labels) { _, which ->
            val item = items[which]
            MaterialAlertDialogBuilder(this).setTitle("بازیابی").setMessage("${item.title} بازیابی شود؟")
                .setPositiveButton("بازیابی") { _, _ -> if (db.restoreTrash(item)) Toast.makeText(this, "بازیابی شد.", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "به دلیل محدودیت ظرفیت، بازیابی انجام نشد.", Toast.LENGTH_LONG).show() }
                .setNegativeButton("انصراف", null).show()
        }.show()
    }

    private fun askMonthlyReport() {
        val current = Jalali.now().substringBefore("/") + "/" + Jalali.now().split("/").getOrElse(1) { "01" }
        val input = EditText(this).apply { hint = "مثال: 1405/05"; setText(current); textSize = 18f }
        MaterialAlertDialogBuilder(this).setTitle("گزارش ماهانه").setMessage("سال و ماه شمسی را وارد کنید.").setView(input)
            .setPositiveButton("نمایش") { _, _ -> showMonthlyReport(input.text.toString().trim()) }.setNegativeButton("انصراف", null).show()
    }

    private fun showMonthlyReport(month: String) {
        val r = db.monthlySummary(month); val balance = r.credit - r.debt
        val text = "ماه: $month\n\nکل پرداخت کردم: ${"%,d".format(r.debt)} تومان\nکل دریافت کردم: ${"%,d".format(r.credit)} تومان\nمانده: ${"%,d".format(kotlin.math.abs(balance))} تومان ${if (balance < 0) "بدهکار" else if (balance > 0) "بستانکار" else "تسویه"}\nتعداد تراکنش‌ها: ${r.txCount}"
        MaterialAlertDialogBuilder(this).setTitle("گزارش ماهانه").setMessage(text).setPositiveButton("باشه", null).show()
    }

    private fun requestPin() {
        val input = EditText(this).apply { hint = "رمز ۴ رقمی"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; maxLines = 1 }
        MaterialAlertDialogBuilder(this).setTitle("تنظیم رمز برنامه").setMessage("یک رمز ۴ رقمی وارد کنید.").setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                val pin = input.text.toString()
                if (pin.length == 4 && pin.all { it.isDigit() }) { AppPrefs.prefs(this).edit().putString(AppPrefs.PIN_HASH, AppPrefs.hashPin(pin)).putString(AppPrefs.LOCK_MODE, "pin").apply(); Toast.makeText(this, "قفل با رمز فعال شد.", Toast.LENGTH_SHORT).show() }
                else { b.lockOff.isChecked = true; Toast.makeText(this, "رمز باید دقیقاً ۴ رقم باشد.", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("انصراف") { _, _ -> b.lockOff.isChecked = true }.setOnCancelListener { b.lockOff.isChecked = true }.show()
    }

    private fun enableBiometric() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) { AppPrefs.prefs(this).edit().putString(AppPrefs.LOCK_MODE, "biometric").apply(); Toast.makeText(this, "قفل اثر انگشت فعال شد.", Toast.LENGTH_SHORT).show() }
        else { b.lockOff.isChecked = true; Toast.makeText(this, "اثر انگشت در این دستگاه آماده نیست.", Toast.LENGTH_LONG).show() }
    }
}
