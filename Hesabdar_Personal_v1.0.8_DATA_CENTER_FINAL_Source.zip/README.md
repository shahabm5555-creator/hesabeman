# حسابدار شخصی — V1.0.4 Backup Safe

این نسخه بر پایه سورس پایدار قبلی ساخته شده و تمرکز این به‌روزرسانی روی **پشتیبان‌گیری و بازیابی مطمئن** است؛ طراحی و امکانات اصلی برنامه دست‌نخورده نگه داشته شده‌اند.

## محل دیتابیس اصلی
دیتابیس زنده در فضای خصوصی Android نگهداری می‌شود و نام آن:
`personal_hesabdar.db`

## محل بکاپ قابل نگهداری بعد از حذف برنامه
`Internal storage/Download/Hesabdarman/`

## فقط دو فایل بکاپ
- `hesabdar_database.db` — آخرین نسخه معتبر
- `hesabdar_database_previous.db` — نسخه معتبر قبلی

هیچ `history` یا فایل شماره‌دار دیگری توسط برنامه ساخته نمی‌شود. فایل‌های SQLite مانند `-wal`، `-shm` و `-journal` موقت هستند و نباید به عنوان بکاپ کپی شوند.

## نکته مهم
هر بکاپ قبل از انتشار با SQLite snapshot و `integrity_check` بررسی می‌شود. بازیابی نیز قبل از جایگزینی دیتابیس فعلی اعتبار فایل را بررسی می‌کند.

بعد از حذف و نصب مجدد برنامه، فایل‌های موجود در `Download/Hesabdarman` باقی می‌مانند. در تنظیمات، دکمه «بازیابی پشتیبان» اگر یک بکاپ معتبر پیدا کند، گزینه **آخرین پشتیبان** را نیز نمایش می‌دهد.

## ساخت APK
پروژه Android در ریشه همین مخزن قرار دارد؛ بنابراین GitHub Actions می‌تواند مستقیماً `settings.gradle.kts` را پیدا کند.


## پشتیبان‌گیری V1.0.4
پشتیبان خارجی فقط دو فایل دارد: `hesabdar_database.db` (آخرین) و `hesabdar_database_previous.db` (قبلی) در `Download/Hesabdarman`. فایل‌های journal/WAL/SHM پشتیبان نیستند. بعد از حذف و نصب مجدد، اگر دیتابیس تازه باشد، برنامه همین دو فایل را شناسایی و بازیابی را پیشنهاد می‌کند.

## V1.0.7 Data Center
The two files in `Download/Hesabdarman` are now the persistent data center. Startup imports the valid CURRENT database before any DbHelper is opened. If both external files are absent, the private database is reset to an empty database and the two slots are recreated. Numbered backup files are never used.
