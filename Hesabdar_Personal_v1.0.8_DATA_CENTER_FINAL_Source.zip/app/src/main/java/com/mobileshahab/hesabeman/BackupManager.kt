package com.mobileshahab.hesabeman

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * V1.1 two-slot DATA CENTER.
 *
 * The two public files are the persistent source of truth:
 *   Download/Hesabdarman/hesabdar_database.db            = CURRENT
 *   Download/Hesabdarman/hesabdar_database_previous.db   = PREVIOUS
 *
 * The private Android database is only the working copy/cache used by SQLite.
 * On every application start, CURRENT is imported into the private DB.
 * If CURRENT is missing but PREVIOUS is valid, PREVIOUS is promoted.
 * If both are missing, the private DB is reset to a new empty database.
 *
 * No numbered files are ever created or trusted.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val MIN_DB_SIZE = 4096L

    /**
     * The single startup gate. Call this BEFORE creating any DbHelper instance.
     * It makes the two public files authoritative.
     */
    @Synchronized
    fun initializeDataCenter(context: Context): Boolean {
        return try {
            cleanupLegacyFiles(context)
            val current = findExact(context, CANONICAL_NAME)
            val previous = findExact(context, PREVIOUS_NAME)
            val currentValid = current != null && isValidUri(context, current)
            val previousValid = previous != null && isValidUri(context, previous)

            when {
                currentValid -> {
                    importIntoLive(context, current!!)
                    // Keep the second recovery slot healthy, but never replace CURRENT.
                    if (!previousValid) copyExternalToSlot(context, current, PREVIOUS_NAME)
                    true
                }
                previousValid -> {
                    // CURRENT is absent/corrupt. PREVIOUS becomes the current source.
                    copyExternalToSlot(context, previous!!, CANONICAL_NAME)
                    importIntoLive(context, findExact(context, CANONICAL_NAME)!!)
                    true
                }
                else -> {
                    // Explicit data-center rule: with no external data files, the app is empty.
                    resetLiveDatabase(context)
                    ensureTwoSlotsFromLive(context)
                    true
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    /** Automatic backup after a successful database mutation. */
    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val snapshot = createConsistentSnapshot(context)
            try {
                validateDatabase(snapshot)
                val current = findExact(context, CANONICAL_NAME)
                val currentValid = current != null && isValidUri(context, current)

                // CURRENT is always the latest complete snapshot. PREVIOUS is the
                // last complete CURRENT, never a partially written SQLite file.
                if (currentValid) {
                    copyExternalToSlot(context, current!!, PREVIOUS_NAME)
                } else {
                    copyFileToSlot(context, snapshot, PREVIOUS_NAME)
                }
                copyFileToSlot(context, snapshot, CANONICAL_NAME)
                cleanupLegacyFiles(context)
            } finally {
                snapshot.delete()
            }
            if (!silent) Toast.makeText(context, "پشتیبان ذخیره شد. فقط دو فایل اصلی نگهداری می‌شوند.", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(context, "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}", Toast.LENGTH_LONG).show()
            false
        }
    }

    /** Direct restore remains available from Settings. */
    @Synchronized
    fun restoreLatest(context: Context): Boolean =
        findBestExternalBackup(context)?.let { restore(context, it) } ?: false

    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        val current = findExact(context, CANONICAL_NAME)
        if (current != null && isValidUri(context, current)) return current
        val previous = findExact(context, PREVIOUS_NAME)
        if (previous != null && isValidUri(context, previous)) return previous
        return null
    }

    /** Import one selected DB into the private live DB. */
    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val candidate = File(context.cacheDir, "restore_candidate.db")
        return try {
            candidate.delete()
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)
            replaceLiveDatabase(context, candidate)
            // A manually selected restore becomes the new DATA CENTER too.
            // This prevents the next startup from importing an older CURRENT file.
            copyFileToSlot(context, candidate, CANONICAL_NAME)
            copyFileToSlot(context, candidate, PREVIOUS_NAME)
            cleanupLegacyFiles(context)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}", Toast.LENGTH_LONG).show()
            false
        } finally { candidate.delete() }
    }

    /** True when an external slot exists and differs from the live working copy. */
    fun hasExternalBackupDifferentFromLive(context: Context): Boolean {
        val uri = findBestExternalBackup(context) ?: return false
        return try {
            val live = createConsistentSnapshot(context)
            val external = File(context.cacheDir, "external_compare.db")
            try {
                copyUriToFile(context.contentResolver, uri, external)
                sha256(live) != sha256(external)
            } finally { live.delete(); external.delete() }
        } catch (_: Exception) { false }
    }

    /**
     * Import a user-selected file. Kept separate from the automatic data-center
     * startup path so arbitrary files can never silently become the source of truth.
     */
    @Synchronized
    fun importSelectedBackup(context: Context, uri: Uri): Boolean {
        return restore(context, uri)
    }

    /**
     * Re-run the data-center synchronization when returning to the app after the
     * user copied files into Download/Hesabdarman while the app was open.
     */
    @Synchronized
    fun syncExternalIfPresent(context: Context): Boolean {
        val current = findExact(context, CANONICAL_NAME)
        val previous = findExact(context, PREVIOUS_NAME)
        if (current == null && previous == null) return false
        val source = when {
            current != null && isValidUri(context, current) -> current
            previous != null && isValidUri(context, previous) -> previous
            else -> return false
        }
        return try {
            importIntoLive(context, source)
            true
        } catch (_: Exception) { false }
    }

    private fun importIntoLive(context: Context, uri: Uri) {
        val candidate = File(context.cacheDir, "data_center_import.db")
        try {
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)
            replaceLiveDatabase(context, candidate)
        } finally { candidate.delete() }
    }

    private fun resetLiveDatabase(context: Context) {
        DbHelper.closeAll()
        val target = DbHelper.databaseFile(context)
        deleteSidecars(target)
        target.delete()
        // Opening it forces SQLiteOpenHelper.onCreate() and the complete empty schema.
        val helper = DbHelper(context)
        helper.writableDatabase
        helper.close()
    }

    private fun replaceLiveDatabase(context: Context, source: File) {
        DbHelper.closeAll()
        val target = DbHelper.databaseFile(context)
        target.parentFile?.mkdirs()
        val replacement = File(target.parentFile, "${DbHelper.DB_NAME}.replace.tmp")
        replacement.delete()
        deleteSidecars(target)
        copyFile(source, replacement)
        validateDatabase(replacement)
        if (target.exists() && !target.delete()) error("پایگاه داده فعلی قابل جایگزینی نیست")
        if (!replacement.renameTo(target)) {
            copyFile(replacement, target)
            replacement.delete()
        }
        deleteSidecars(target)
        validateDatabase(target)
    }

    private fun ensureTwoSlotsFromLive(context: Context) {
        val snapshot = createConsistentSnapshot(context)
        try {
            copyFileToSlot(context, snapshot, CANONICAL_NAME)
            copyFileToSlot(context, snapshot, PREVIOUS_NAME)
        } finally { snapshot.delete() }
    }

    private fun copyExternalToSlot(context: Context, sourceUri: Uri, name: String) {
        val temp = File(context.cacheDir, "slot_source_${name.replace('.', '_')}")
        try {
            copyUriToFile(context.contentResolver, sourceUri, temp)
            validateDatabase(temp)
            copyFileToSlot(context, temp, name)
        } finally { temp.delete() }
    }

    private fun copyFileToSlot(context: Context, source: File, name: String) {
        validateDatabase(source)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val dir = backupDirectory()
            if (!dir.exists() && !dir.mkdirs()) error("پوشه پشتیبان قابل ساخت نیست")
            val target = File(dir, name)
            val tmp = File(dir, ".${name}.tmp")
            copyFile(source, tmp)
            validateDatabase(tmp)
            if (!tmp.renameTo(target)) { copyFile(tmp, target); tmp.delete() }
            return
        }

        val resolver = context.contentResolver
        val existing = findExact(context, name)
        if (existing != null) {
            try {
                writeExistingUri(resolver, existing, source)
                if (isValidUri(context, existing)) {
                    removeDuplicateExactRows(context, name, keep = existing)
                    return
                }
            } catch (_: Exception) { }
            removeAllExactRows(context, name)
        }

        val uri = resolver.insert(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        ) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")
        try {
            resolver.openOutputStream(uri, "wt")?.use { out -> FileInputStream(source).use { it.copyTo(out) } }
                ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")
            val probe = File(context.cacheDir, "slot_probe.db")
            try { copyUriToFile(resolver, uri, probe); validateDatabase(probe) } finally { probe.delete() }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            removeDuplicateExactRows(context, name, keep = uri)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
    }

    private fun findExact(context: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val f = File(backupDirectory(), name)
            return if (f.exists()) Uri.fromFile(f) else null
        }
        context.contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH, name),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        )?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
        }
        return null
    }

    private fun removeDuplicateExactRows(context: Context, name: String, keep: Uri) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val rows = mutableListOf<Uri>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=?",
            arrayOf(RELATIVE_PATH, name), null
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val pending = c.getColumnIndexOrThrow(MediaStore.Downloads.IS_PENDING)
            while (c.moveToNext()) {
                if (c.getInt(pending) == 0) {
                    val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id))
                    if (uri != keep) rows += uri
                }
            }
        }
        rows.forEach { resolver.delete(it, null, null) }
    }

    private fun removeAllExactRows(context: Context, name: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        resolver.delete(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=?",
            arrayOf(RELATIVE_PATH, name)
        )
    }

    private fun cleanupLegacyFiles(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            backupDirectory().listFiles()?.forEach { f -> if (isLegacyName(f.name)) f.delete() }
            return
        }
        val resolver = context.contentResolver
        val rows = mutableListOf<Uri>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.RELATIVE_PATH),
            "${MediaStore.Downloads.RELATIVE_PATH}=?",
            arrayOf(RELATIVE_PATH), null
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (c.moveToNext()) {
                if (isLegacyName(c.getString(name))) rows += ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id))
            }
        }
        rows.forEach { resolver.delete(it, null, null) }
    }

    private fun isLegacyName(name: String): Boolean =
        name.matches(Regex("hesabdar_database(?:_previous)? \\(\\d+\\)\\.db")) ||
            name.startsWith("hesabdar_history_") || name.startsWith("hesabdar_database_backup")

    private fun backupDirectory(): File = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Hesabdarman")

    private fun createConsistentSnapshot(context: Context): File {
        val helper = DbHelper(context)
        val snapshot = File(context.cacheDir, "hesabdar_snapshot.db")
        snapshot.delete()
        return try {
            val db = helper.writableDatabase
            db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            val escaped = snapshot.absolutePath.replace("'", "''")
            db.execSQL("VACUUM INTO '$escaped'")
            helper.close()
            if (!snapshot.exists() || snapshot.length() < MIN_DB_SIZE) error("اسنپ‌شات دیتابیس ساخته نشد")
            snapshot
        } catch (e: Exception) {
            runCatching { helper.close() }
            snapshot.delete()
            throw e
        }
    }

    private fun writeExistingUri(resolver: ContentResolver, uri: Uri, source: File) {
        resolver.openOutputStream(uri, "wt")?.use { out -> FileInputStream(source).use { it.copyTo(out) } }
            ?: error("فایل پشتیبان قابل نوشتن نیست")
    }

    private fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        resolver.openInputStream(uri)?.use { input -> FileOutputStream(target, false).use { input.copyTo(it) } }
            ?: error("فایل قابل خواندن نیست")
    }

    private fun copyFile(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input -> FileOutputStream(target, false).use { input.copyTo(it) } }
    }

    private fun deleteSidecars(target: File) {
        File(target.path + "-wal").delete(); File(target.path + "-shm").delete(); File(target.path + "-journal").delete()
    }

    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val probe = File(context.cacheDir, "uri_probe.db")
        return try { copyUriToFile(context.contentResolver, uri, probe); validateDatabase(probe); true }
        catch (_: Exception) { false }
        finally { probe.delete() }
    }

    private fun sha256(file: File): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(8192)
            while (true) { val n = input.read(buffer); if (n <= 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < MIN_DB_SIZE) error("فایل پشتیبان خالی یا ناقص است")
        SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY).use { db ->
            val required = setOf("folders", "notebooks", "tx", "invoices", "invoice_items", "installment_plans", "installment_items", "checks", "app_meta")
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c -> while (c.moveToNext()) found += c.getString(0) }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")
            val integrityOk = db.rawQuery("PRAGMA integrity_check", null).use { it.moveToFirst() && it.getString(0).equals("ok", true) }
            if (!integrityOk) error("فایل پشتیبان آسیب‌دیده است")
            val appId = db.rawQuery("SELECT value FROM app_meta WHERE key='app_id' LIMIT 1", null).use { if (it.moveToFirst()) it.getString(0) else "" }
            if (appId != "hesabdar_personal") error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")
            val version = db.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        }
    }
}
