package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TxAdapter(
    private var items: List<TxRecord>,
    private val onEdit: (TxRecord) -> Unit,
    private val onDelete: (TxRecord) -> Unit
) : RecyclerView.Adapter<TxAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: com.google.android.material.card.MaterialCardView = view.findViewById(R.id.txCard)
        val type: TextView = view.findViewById(R.id.txType)
        val amount: TextView = view.findViewById(R.id.txAmount)
        val note: TextView = view.findViewById(R.id.txNote)
        val date: TextView = view.findViewById(R.id.txDate)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
    )
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val x = items[position]; val isDebt = x.kind == "debt"; val ctx = holder.itemView.context
        holder.card.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_soft else R.color.credit_soft))
        holder.type.setTextColor(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_text else R.color.credit_text))
        holder.type.text = if (isDebt) "پرداختی" else "دریافتی"
        holder.type.gravity = android.view.Gravity.RIGHT or android.view.Gravity.CENTER_VERTICAL
        holder.type.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
        holder.type.textDirection = View.TEXT_DIRECTION_RTL
        holder.amount.setTextColor(ContextCompat.getColor(ctx, if (isDebt) R.color.debt_text else R.color.credit_text))
        holder.amount.text = "${"%,d".format(java.util.Locale.US, x.amount)} تومان"
        holder.amount.gravity = android.view.Gravity.LEFT or android.view.Gravity.CENTER_VERTICAL
        holder.amount.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        holder.amount.textDirection = View.TEXT_DIRECTION_LTR
        holder.note.text = if (x.note.isBlank()) "بدون توضیحات" else x.note
        holder.note.gravity = android.view.Gravity.RIGHT or android.view.Gravity.CENTER_VERTICAL
        holder.note.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
        holder.note.textDirection = View.TEXT_DIRECTION_ANY
        holder.date.text = x.createdAt.replace(" - ", "\n")
        holder.itemView.setOnClickListener { onEdit(x) }
        holder.itemView.setOnLongClickListener { onDelete(x); true }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<TxRecord>) { items = newItems; notifyDataSetChanged() }
}
