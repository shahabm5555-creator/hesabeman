package com.mobileshahab.hesabeman

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SimpleAdapter(
    private var items: List<RowItem>,
    private val onClick: (RowItem) -> Unit
) : RecyclerView.Adapter<SimpleAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.text)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_simple, parent, false)
        return Holder(v)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.text.text = item.title
        holder.itemView.setOnClickListener { onClick(item) }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<RowItem>) { items = newItems; notifyDataSetChanged() }
}
