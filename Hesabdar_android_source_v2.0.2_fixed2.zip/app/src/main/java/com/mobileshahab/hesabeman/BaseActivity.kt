package com.mobileshahab.hesabeman

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        val prefs = newBase.getSharedPreferences(AppPrefs.FILE, Context.MODE_PRIVATE)
        val scale = when (prefs.getString(AppPrefs.TEXT_SIZE, "normal")) {
            "medium" -> 1.12f
            "large" -> 1.25f
            else -> 1.0f
        }
        val config = Configuration(newBase.resources.configuration)
        config.fontScale = scale
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }
}
