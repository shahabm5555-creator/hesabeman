package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityFolderBinding

class FolderActivity : BaseActivity() {
    private lateinit var b: ActivityFolderBinding
    private lateinit var db: DbHelper
    private lateinit var notebookAdapter: NotebookListAdapter
    private var folderId = 0L
    private var filter = "all"
    private var sort = "number"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFolderBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this); folderId = intent.getLongExtra("folder_id", 0)
        b.toolbar.title = intent.getStringExtra("folder_name") ?: "پوشه"
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        notebookAdapter = NotebookListAdapter(emptyList(),
            onClick = { startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", it.id)) },
            onLongClick = { showAccountActions(it) }
        )
        b.notebooks.layoutManager = LinearLayoutManager(this); b.notebooks.adapter = notebookAdapter
        b.addNotebook.setOnClickListener {
            if (db.countNotebooks(folderId) >= DbHelper.MAX_ACCOUNTS_PER_FOLDER) {
                Toast.makeText(this, "در هر پوشه حداکثر ۵۰۰ حساب مجاز است.", Toast.LENGTH_LONG).show()
            } else {
                promptNotebook(this) { name, phone -> if (db.addNotebook(folderId, name, phone)) refresh() }
            }
        }
        b.filterButton.setOnClickListener { chooseFilter() }
        b.sortButton.setOnClickListener { chooseSort() }
    }

    private fun showAccountActions(item: NotebookListItem) {
        val actions = arrayOf("تغییر ردیف", "انتقال به آرشیو", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> {
                    val max = db.countNotebooks(folderId).coerceAtLeast(1)
                    promptOrder(this, "تغییر ردیف حساب", item.sortOrder, max) { newRow ->
                        db.setNotebookOrder(item.id, newRow)
                        sort = "number"
                        b.sortButton.text = "شماره ردیف"
                        refresh()
                    }
                }
                1 -> if (db.archiveNotebook(item.id)) {
                    Toast.makeText(this, "حساب به آرشیو منتقل شد.", Toast.LENGTH_SHORT).show(); refresh()
                } else {
                    Toast.makeText(this, "فقط حساب تسویه‌شده قابل آرشیو است.", Toast.LENGTH_LONG).show()
                }
                2 -> MaterialAlertDialogBuilder(this)
                    .setTitle("حذف حساب")
                    .setMessage("این حساب تا ۵ روز در سطل زباله قابل بازیابی است.")
                    .setPositiveButton("حذف") { _, _ -> db.trashNotebook(item.id); refresh() }
                    .setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFilter() {
        val labels = arrayOf("همه", "بدهکارها", "بستانکارها", "تسویه‌شده‌ها")
        val values = arrayOf("all", "debt", "credit", "settled")
        MaterialAlertDialogBuilder(this).setTitle("فیلتر حساب‌ها").setItems(labels) { _, which ->
            filter = values[which]; b.filterButton.text = labels[which]; refresh()
        }.show()
    }

    private fun chooseSort() {
        val labels = arrayOf("شماره ردیف", "بیشترین بدهکاری", "بیشترین بستانکاری", "نام")
        val values = arrayOf("number", "debt", "credit", "name")
        MaterialAlertDialogBuilder(this).setTitle("مرتب‌سازی حساب‌ها").setItems(labels) { _, which ->
            sort = values[which]; b.sortButton.text = labels[which]; refresh()
        }.show()
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() { notebookAdapter.submit(db.notebooksDetailed(folderId, filter, sort)) }
}
