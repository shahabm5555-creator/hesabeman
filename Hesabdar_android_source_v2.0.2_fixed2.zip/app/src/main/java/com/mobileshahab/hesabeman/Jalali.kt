package com.mobileshahab.hesabeman

import java.util.Calendar
import java.util.Locale

object Jalali {
    fun now(): String {
        val c = Calendar.getInstance()
        val (jy, jm, jd) = gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return String.format(Locale.US, "%04d/%02d/%02d - %02d:%02d", jy, jm, jd, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    fun isValidTime(value: String): Boolean {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(value.trim()) ?: return false
        val h = m.groupValues[1].toIntOrNull() ?: return false
        val min = m.groupValues[2].toIntOrNull() ?: return false
        return h in 0..23 && min in 0..59
    }

    fun isValidDate(value: String): Boolean {
        val m = Regex("^(\\d{4})/(\\d{1,2})/(\\d{1,2})$").matchEntire(value.trim()) ?: return false
        val y = m.groupValues[1].toIntOrNull() ?: return false
        val mo = m.groupValues[2].toIntOrNull() ?: return false
        val d = m.groupValues[3].toIntOrNull() ?: return false
        if (y < 1200 || y > 1600 || mo !in 1..12 || d < 1 || d > if (mo <= 6) 31 else if (mo <= 11) 30 else 30) return false
        val g = jalaliToGregorian(y, mo, d)
        val back = gregorianToJalali(g.first, g.second, g.third)
        return back.first == y && back.second == mo && back.third == d
    }

    private fun isLeapJalali(year: Int): Boolean = isValidDate("%04d/12/30".format(Locale.US, year))

    private fun jalaliToGregorian(jyInput: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        var jy = jyInput
        var gy: Int
        if (jy > 979) { gy = 1600; jy -= 979 } else { gy = 621 }
        var days = 365 * jy + (jy / 33) * 8 + ((jy % 33 + 3) / 4) + 78 + jd
        days += if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186
        gy += 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            gy += 100 * (--days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
        val gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val monthDays = intArrayOf(31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 1
        var rem = gd
        while (gm <= 12 && rem > monthDays[gm - 1]) { rem -= monthDays[gm - 1]; gm++ }
        return Triple(gy, gm, rem)
    }

    private fun gregorianToJalali(gyInput: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy = gyInput
        var jy: Int
        if (gy > 1600) { jy = 979; gy -= 1600 } else { jy = 0; gy -= 621 }
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 - 80 + gd + gdm[gm - 1]
        jy += 33 * (days / 12053); days %= 12053; jy += 4 * (days / 1461); days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm: Int; val jd: Int
        if (days < 186) { jm = 1 + days / 31; jd = 1 + days % 31 } else { jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30 }
        return Triple(jy, jm, jd)
    }
}
