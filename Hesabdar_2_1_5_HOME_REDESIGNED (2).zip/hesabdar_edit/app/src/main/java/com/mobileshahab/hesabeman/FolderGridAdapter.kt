package com.mobileshahab.hesabeman

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FolderGridAdapter(
    private var items: List<FolderItem>,
    private val onClick: (FolderItem) -> Unit,
    private val onLongClick: (FolderItem) -> Unit,
    // Base text sizes (14sp name / 10.5sp count) multiplied by this; driven by the
    // «اندازه متن» setting so this card can grow a bit without breaking its fixed layout.
    private var textScale: Float = 1f
) : RecyclerView.Adapter<FolderGridAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.folderCard)
        val iconBg: View = view.findViewById(R.id.folderIconBg)
        val name: TextView = view.findViewById(R.id.folderName)
        val count: TextView = view.findViewById(R.id.folderCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder_grid, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]

        holder.name.text = item.name
        holder.name.textSize = 14f * textScale
        holder.count.text = "${item.notebookCount} حساب"
        holder.count.textSize = 10.5f * textScale

        val parsed = try {
            Color.parseColor(item.color)
        } catch (_: Exception) {
            Color.parseColor("#4D83B8")
        }
        val surface = ContextCompat.getColor(holder.itemView.context, R.color.surface)

        // Solid color for the icon badge / count pill so every category reads clearly
        // regardless of how pale or saturated its base color is.
        val solid = ColorStateList.valueOf(parsed)
        val cardTint = ColorUtils.blendARGB(surface, parsed, 0.14f)
        val strokeTint = ColorUtils.blendARGB(parsed, surface, 0.55f)

        holder.card.setCardBackgroundColor(cardTint)
        holder.card.strokeColor = strokeTint
        holder.iconBg.backgroundTintList = solid
        holder.count.backgroundTintList = solid
        holder.name.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text))

        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size

    fun submit(newItems: List<FolderItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setTextScale(scale: Float) {
        if (textScale == scale) return
        textScale = scale
        notifyDataSetChanged()
    }
}
