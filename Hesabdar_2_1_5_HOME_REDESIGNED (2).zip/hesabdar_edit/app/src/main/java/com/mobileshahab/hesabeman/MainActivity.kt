package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter
    private var dueShown = false
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable { override fun run() { updateClock(); clockHandler.postDelayed(this, 1000L) } }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        // Edge-to-edge safe spacing: content always stays clear of status/navigation bars and the fixed bottom bar.
        // Re-applied once more after the bottom bar gets its real measured height (it's 0 on the very first
        // pass), then this listener removes itself — re-triggering on every later layout pass caused the
        // scroll padding to be recalculated repeatedly and the content to visibly jump/reveal blank space.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(b.root) { _, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            val bottom = b.bottomBar.height + bars.bottom + dp(10)
            b.mainScroll.setPadding(b.mainScroll.paddingLeft, bars.top + dp(2), b.mainScroll.paddingRight, bottom)
            insets
        }
        b.bottomBar.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (b.bottomBar.height > 0) {
                    androidx.core.view.ViewCompat.requestApplyInsets(b.root)
                    b.bottomBar.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            }
        })
        androidx.core.view.ViewCompat.requestApplyInsets(b.root)
        fun animate(view: View, delay: Long) {
            view.alpha = 0f
            view.translationY = resources.displayMetrics.density * 10f
            view.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(260L).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        animate(b.summaryCard, 20)
        animate(b.quickInstallment, 70)
        animate(b.list, 120)
        animate(b.recentTransactionsCard, 180)
        b.digitalClock.typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
        adapter = FolderGridAdapter(emptyList(),
            onClick = { startActivity(Intent(this, FolderActivity::class.java).putExtra("folder_id", it.id).putExtra("folder_name", it.name)) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 4); b.list.adapter = adapter
        b.list.itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator()
        b.newUserButton.setOnClickListener { createNewUser() }
        b.searchButton.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.quickInvoice.setOnClickListener { chooseNotebookAndRun("صدور فاکتور") { id, name, phone ->
            startActivity(Intent(this, InvoiceActivity::class.java).apply {
                putExtra("notebook_id", id); putExtra("notebook_name", name); putExtra("notebook_phone", phone)
            })
        } }
        b.quickInstallment.setOnClickListener { chooseNotebookAndRun("صدور قسط") { id, name, _ ->
            startActivity(Intent(this, InstallmentActivity::class.java).apply {
                putExtra("notebook_id", id); putExtra("notebook_name", name)
            })
        } }
        b.quickCheck.setOnClickListener { chooseNotebookAndRun("ثبت چک") { id, name, _ ->
            startActivity(Intent(this, CheckActivity::class.java).apply {
                putExtra("notebook_id", id); putExtra("notebook_name", name); putExtra("auto_open", true)
            })
        } }
        b.quickPay.setOnClickListener { chooseNotebookAndTransaction("پرداخت به", "debt") }
        b.quickReceive.setOnClickListener { chooseNotebookAndTransaction("دریافت از", "credit") }
    }

    private fun activeNotebooks(): List<NotebookListItem> = db.folderItems().flatMap { db.notebooksDetailed(it.id) }

    private fun chooseNotebookAndRun(title: String, action: (Long, String, String) -> Unit) {
        val accounts = activeNotebooks()
        if (accounts.isEmpty()) {
            MaterialAlertDialogBuilder(this).setTitle("حسابی وجود ندارد")
                .setMessage("ابتدا یک کاربر/حساب جدید بسازید.")
                .setPositiveButton("ساخت کاربر") { _, _ -> createNewUser() }
                .setNegativeButton("انصراف", null).show()
            return
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_account_picker, null)
        dialogView.findViewById<android.widget.TextView>(R.id.accountPickerTitle).text = "انتخاب حساب برای $title"
        val search = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.accountSearch)
        val list = dialogView.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.accountList)
        val empty = dialogView.findViewById<android.widget.TextView>(R.id.accountSearchEmpty)
        val picker = AccountPickerAdapter(accounts) { selected ->
            currentDialog?.dismiss()
            action(selected.id, selected.name, selected.phone)
        }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = picker

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogView)
            .setNegativeButton("انصراف", null)
            .create()
        currentDialog = dialog

        search.doAfterTextChanged { editable ->
            val q = editable?.toString()?.trim()?.lowercase(java.util.Locale.getDefault()).orEmpty()
            val filtered = if (q.isBlank()) accounts else accounts.filter {
                it.name.lowercase(java.util.Locale.getDefault()).contains(q) ||
                    it.phone.replace(" ", "").contains(q.replace(" ", ""))
            }
            picker.submit(filtered)
            empty.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            list.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
        }
        dialog.setOnDismissListener { if (currentDialog === dialog) currentDialog = null }
        dialog.show()
    }

    private var currentDialog: android.app.Dialog? = null

    private fun chooseNotebookAndTransaction(title: String, kind: String) {
        chooseNotebookAndRun(title) { id, name, _ ->
            promptTransaction(this, title, kind) { selectedKind, amount, note, dateTime ->
                if (db.addTx(id, selectedKind, amount, note, dateTime) > 0L) {
                    Toast.makeText(this, "$title ثبت شد برای $name", Toast.LENGTH_SHORT).show()
                    refresh()
                } else Toast.makeText(this, "تراکنش نامعتبر است؛ مبلغ و تاریخ را بررسی کنید.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun createNewUser() {
        val folders = db.folderItems()
        if (folders.isEmpty()) return
        showFolderPickerForNewUser(folders)
    }

    private fun showFolderPickerForNewUser(folders: List<FolderItem>) {
        val view = layoutInflater.inflate(R.layout.dialog_folder_picker, null)
        view.findViewById<android.widget.TextView>(R.id.folderPickerTitle).text = "انتخاب پوشه برای کاربر جدید"
        val list = view.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.folderPickerList)
        list.layoutManager = LinearLayoutManager(this)

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(view)
            .setNegativeButton("انصراف", null)
            .create()
        currentDialog = dialog

        val adapter = object : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): androidx.recyclerview.widget.RecyclerView.ViewHolder {
                val row = android.widget.LinearLayout(parent.context).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = androidx.core.content.ContextCompat.getDrawable(parent.context, android.R.drawable.list_selector_background)
                    layoutParams = android.widget.LinearLayout.LayoutParams(-1, dp(58))
                }
                val icon = android.widget.TextView(parent.context).apply {
                    id = android.R.id.icon
                    gravity = android.view.Gravity.CENTER
                    setTextColor(color(R.color.surface))
                    background = androidx.core.content.ContextCompat.getDrawable(parent.context, R.drawable.bg_avatar)
                    layoutParams = android.widget.LinearLayout.LayoutParams(dp(38), dp(38))
                }
                val icon2 = android.widget.ImageView(parent.context).apply {
                    layoutParams = android.widget.LinearLayout.LayoutParams(dp(18), dp(18))
                    setImageResource(R.drawable.ic_folder_rounded)
                    imageTintList = android.content.res.ColorStateList.valueOf(color(R.color.surface))
                }
                val iconStack = android.widget.FrameLayout(parent.context).apply {
                    layoutParams = android.widget.LinearLayout.LayoutParams(dp(38), dp(38))
                    addView(icon)
                    addView(icon2, android.widget.FrameLayout.LayoutParams(dp(18), dp(18), android.view.Gravity.CENTER))
                }
                val text = android.widget.TextView(parent.context).apply {
                    id = android.R.id.text1; textSize = 13f; setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(color(R.color.text)); gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.RIGHT
                    setPadding(dp(10), 0, dp(10), 0)
                }
                val count = android.widget.TextView(parent.context).apply {
                    id = android.R.id.text2; textSize = 10f; setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(color(R.color.surface)); gravity = android.view.Gravity.CENTER
                    setPadding(dp(9), dp(2), dp(9), dp(2))
                    background = androidx.core.content.ContextCompat.getDrawable(parent.context, R.drawable.bg_chip_pill)
                }
                val lp = android.widget.LinearLayout.LayoutParams(0, -2, 1f)
                row.addView(iconStack); row.addView(text, lp); row.addView(count)
                return object : androidx.recyclerview.widget.RecyclerView.ViewHolder(row) {}
            }
            override fun onBindViewHolder(holder: androidx.recyclerview.widget.RecyclerView.ViewHolder, position: Int) {
                val item = folders[position]
                val row = holder.itemView as android.widget.LinearLayout
                val iconStack = row.getChildAt(0) as android.widget.FrameLayout
                val icon = iconStack.getChildAt(0) as android.widget.TextView
                val text = row.getChildAt(1) as android.widget.TextView
                val count = row.getChildAt(2) as android.widget.TextView
                val parsed = try { android.graphics.Color.parseColor(item.color) } catch (_: Exception) { color(R.color.primary) }
                icon.backgroundTintList = android.content.res.ColorStateList.valueOf(parsed)
                text.text = item.name
                count.text = "${item.notebookCount} حساب"
                count.backgroundTintList = android.content.res.ColorStateList.valueOf(parsed)
                row.setOnClickListener {
                    currentDialog?.dismiss()
                    if (db.countNotebooks(item.id) >= DbHelper.MAX_ACCOUNTS_PER_FOLDER) {
                        Toast.makeText(this@MainActivity, "ظرفیت این پوشه تکمیل است.", Toast.LENGTH_LONG).show()
                    } else {
                        promptNotebook(this@MainActivity) { name, phone -> if (db.addNotebook(item.id, name, phone)) refresh() }
                    }
                }
            }
            override fun getItemCount() = folders.size
        }
        list.adapter = adapter

        dialog.setOnShowListener {
            view.alpha = 0f
            view.translationY = dp(8).toFloat()
            view.animate().alpha(1f).translationY(0f).setDuration(220L).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        dialog.setOnDismissListener { if (currentDialog === dialog) currentDialog = null }
        dialog.show()
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        // «آبی آرام» به‌عنوان گزینه‌ی پیش‌فرض/اول فهرست قرار دارد.
        val names = arrayOf("آبی آرام", "سبز یشمی", "طلایی گرم", "بنفش شیک", "رز ملایم", "خاکستری سبز")
        val colors = arrayOf("#4D83B8", "#4B9B7C", "#C48A42", "#7D66B2", "#B65E79", "#667A78")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which ->
            db.setFolderColor(item.id, colors[which]); refresh()
        }.show()
    }

    override fun onResume() {
        super.onResume()
        db.purgeExpiredTrash()
        refresh()
        updateClock()
        clockHandler.removeCallbacks(clockTick)
        clockHandler.post(clockTick)
        if (!dueShown) { dueShown = true; showDueReminder() }
    }

    override fun onPause() {
        clockHandler.removeCallbacks(clockTick)
        super.onPause()
    }

    private fun updateClock() {
        val now = java.util.Calendar.getInstance()
        b.digitalClock.text = String.format(java.util.Locale.US, "%02d:%02d:%02d", now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), now.get(java.util.Calendar.SECOND))
        val jalali = Jalali.now()
        b.jalaliToday.text = jalali.substringBefore(" - ")
        b.todayWeekday.text = when (now.get(java.util.Calendar.DAY_OF_WEEK)) {
            java.util.Calendar.SATURDAY -> "شنبه"
            java.util.Calendar.SUNDAY -> "یکشنبه"
            java.util.Calendar.MONDAY -> "دوشنبه"
            java.util.Calendar.TUESDAY -> "سه‌شنبه"
            java.util.Calendar.WEDNESDAY -> "چهارشنبه"
            java.util.Calendar.THURSDAY -> "پنجشنبه"
            else -> "جمعه"
        }
    }

    private fun showDueReminder() {
        val today = Jalali.now().substringBefore(" - ")
        val due = db.dueNotebooks(today)
        if (due.isEmpty()) return
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val checks = mutableMapOf<Long, android.widget.CheckBox>()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        due.forEachIndexed { idx, n ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(12), dp(10), dp(12), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.rgb(255, 248, 235))
                    cornerRadius = dp(12).toFloat()
                }
            }
            row.addView(android.widget.TextView(this).apply {
                text = "${n.name} — ${"%,d".format(kotlin.math.abs(n.balance))} تومان\nسررسید: ${n.dueDate}"
                textSize = 13f; setTextColor(android.graphics.Color.rgb(42, 49, 47))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            val check = android.widget.CheckBox(this).apply {
                text = "دیگر برای سررسید همین تاریخ این حساب نمایش نده"
                textSize = 11f; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(2), dp(6), dp(2), 0)
            }
            checks[n.id] = check
            row.addView(check)
            box.addView(row)
            if (idx != due.lastIndex) box.addView(android.widget.Space(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(-1, dp(8))
            })
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(box)
            layoutParams = android.view.ViewGroup.LayoutParams(-1, if (due.size > 4) dp(360) else android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("یادآوری سررسید بدهی (${due.size} حساب)")
            .setView(scroll)
            .setPositiveButton("بررسی شد") { _, _ ->
                checks.forEach { (id, cb) -> if (cb.isChecked) db.ackDueReminder(id) }
            }.show()
    }

    private fun refresh() {
        // «اندازه متن» در تنظیمات: عادی=۱، متوسط کمی بزرگ‌تر (بدون بهم‌ریختن قالب کارت‌ها)، پررنگ همان بولد سراسری موجود است.
        val textScale = if (AppPrefs.prefs(this).getString(AppPrefs.TEXT_SIZE, "normal") == "medium") 1.08f else 1f
        adapter.setTextScale(textScale)
        b.totalDebt.textSize = 18f * textScale
        b.balanceCreditLine.textSize = 18f * textScale
        b.balanceNetLine.textSize = 18f * textScale

        val items = db.folderItems(); adapter.submit(items)
        val s = db.accountSummary()
        b.totalDebt.text = formatMoney(s.totalDebt)
        b.balanceCreditLine.text = formatMoney(s.totalCredit)
        val net = s.totalCredit - s.totalDebt
        val absNet = kotlin.math.abs(net)
        b.balanceNetLine.text = when {
            net > 0 -> "+${formatMoney(absNet)}"
            net < 0 -> "-${formatMoney(absNet)}"
            else -> "0"
        }
        when {
            net > 0 -> {
                b.balanceStatus.text = "بس"
                b.balanceNetLine.setTextColor(color(R.color.credit_text))
                b.balanceStatus.setTextColor(color(R.color.credit_text))
            }
            net < 0 -> {
                b.balanceStatus.text = "بد"
                b.balanceNetLine.setTextColor(color(R.color.debt_text))
                b.balanceStatus.setTextColor(color(R.color.debt_text))
            }
            else -> {
                b.balanceStatus.text = "تسویه"
                b.balanceNetLine.setTextColor(color(R.color.summary_blue))
                b.balanceStatus.setTextColor(color(R.color.secondary))
            }
        }
        b.debtorCount.text = "${s.debtors} نفر"
        b.creditorCount.text = "${s.creditors} نفر"
        b.checkCount.text = "${db.pendingCheckCount()} چک"
        b.installmentCount.text = "${db.upcomingInstallmentCount()} قسط"
        refreshRecentTransactions()
    }

    private fun refreshRecentTransactions() {
        val rows = listOf(b.recentRow1, b.recentRow2, b.recentRow3, b.recentRow4)
        val titles = listOf(b.recentTitle1, b.recentTitle2, b.recentTitle3, b.recentTitle4)
        val subtitles = listOf(b.recentSubtitle1, b.recentSubtitle2, b.recentSubtitle3, b.recentSubtitle4)
        val amounts = listOf(b.recentAmount1, b.recentAmount2, b.recentAmount3, b.recentAmount4)
        val dates = listOf(b.recentDate1, b.recentDate2, b.recentDate3, b.recentDate4)
        val icons = listOf(b.recentIcon1, b.recentIcon2, b.recentIcon3, b.recentIcon4)
        val dividers = listOf(b.recentDivider1, b.recentDivider2, b.recentDivider3)
        val transactions = db.recentTransactions(4)

        rows.forEach { it.visibility = View.GONE }
        dividers.forEachIndexed { index, divider ->
            divider.visibility = if (index < transactions.size - 1) View.VISIBLE else View.GONE
        }
        transactions.forEachIndexed { index, tx ->
            val row = rows[index]
            row.visibility = View.VISIBLE

            val isCredit = tx.kind == "credit"
            titles[index].text = if (isCredit) "دریافت از حساب" else "پرداخت به حساب"
            subtitles[index].text = if (tx.note.isBlank()) tx.notebookName else "${tx.notebookName} — ${tx.note}"
            amounts[index].text = if (isCredit) "+${formatMoney(tx.amount)}" else "-${formatMoney(tx.amount)}"
            amounts[index].setTextColor(color(if (isCredit) R.color.credit_text else R.color.debt_text))
            icons[index].text = if (isCredit) "↓" else "↑"
            icons[index].setTextColor(color(if (isCredit) R.color.credit_text else R.color.debt_text))
            icons[index].setBackgroundColor(color(if (isCredit) R.color.credit_soft else R.color.debt_soft))
            dates[index].text = tx.createdAt.substringAfter(" - ", tx.createdAt)

            row.setOnClickListener {
                startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", tx.notebookId))
            }
        }
        b.recentTransactionsHint.text = if (transactions.isEmpty()) "تراکنشی ثبت نشده" else "${transactions.size} مورد اخیر"
        b.recentTransactionsCard.visibility = if (transactions.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun formatMoney(value: Long) = "%,d".format(value)
    private fun color(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
}
