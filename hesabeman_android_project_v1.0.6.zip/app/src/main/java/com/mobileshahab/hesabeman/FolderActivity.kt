package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityFolderBinding

class FolderActivity : BaseActivity() {
    private lateinit var b: ActivityFolderBinding
    private lateinit var db: DbHelper
    private lateinit var notebookAdapter: NotebookListAdapter
    private var folderId = 0L
    private var filter = "all"
    private var sort = "number"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFolderBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this); folderId = intent.getLongExtra("folder_id", 0)
        b.toolbar.title = intent.getStringExtra("folder_name") ?: "پوشه"
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material); b.toolbar.setNavigationOnClickListener { finish() }
        notebookAdapter = NotebookListAdapter(emptyList(),
            onClick = { startActivity(Intent(this, NotebookActivity::class.java).putExtra("notebook_id", it.id)) },
            onLongClick = { showNotebookActions(it) }
        )
        b.notebooks.layoutManager = LinearLayoutManager(this); b.notebooks.adapter = notebookAdapter
        b.addNotebook.setOnClickListener {
            if (db.countNotebooks(folderId) >= 30) Toast.makeText(this, "در هر پوشه حداکثر ۳۰ دفترچه مجاز است.", Toast.LENGTH_LONG).show()
            else promptNotebook(this) { name, phone -> if (db.addNotebook(folderId, name, phone)) refresh() }
        }
        b.filterButton.setOnClickListener { chooseFilter() }
        b.sortButton.setOnClickListener { chooseSort() }
    }

    private fun showNotebookActions(item: NotebookListItem) {
        val actions = arrayOf("انتقال به آرشیو", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> if (db.archiveNotebook(item.id)) { Toast.makeText(this, "دفترچه به آرشیو منتقل شد.", Toast.LENGTH_SHORT).show(); refresh() }
                     else Toast.makeText(this, "فقط دفترچه تسویه‌شده قابل آرشیو است.", Toast.LENGTH_LONG).show()
                1 -> MaterialAlertDialogBuilder(this).setTitle("حذف دفترچه").setMessage("این دفترچه تا ۵ روز در سطل زباله قابل بازیابی است.")
                    .setPositiveButton("حذف") { _, _ -> db.trashNotebook(item.id); refresh() }.setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFilter() {
        val labels = arrayOf("همه", "بدهکارها", "بستانکارها", "تسویه‌شده‌ها")
        val values = arrayOf("all", "debt", "credit", "settled")
        MaterialAlertDialogBuilder(this).setTitle("فیلتر دفترچه‌ها").setItems(labels) { _, which -> filter = values[which]; b.filterButton.text = labels[which]; refresh() }.show()
    }

    private fun chooseSort() {
        val labels = arrayOf("شماره دفترچه", "بیشترین بدهکاری", "بیشترین بستانکاری", "نام")
        val values = arrayOf("number", "debt", "credit", "name")
        MaterialAlertDialogBuilder(this).setTitle("مرتب‌سازی دفترچه‌ها").setItems(labels) { _, which -> sort = values[which]; b.sortButton.text = labels[which]; refresh() }.show()
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() { notebookAdapter.submit(db.notebooksDetailed(folderId, filter, sort)) }
}
