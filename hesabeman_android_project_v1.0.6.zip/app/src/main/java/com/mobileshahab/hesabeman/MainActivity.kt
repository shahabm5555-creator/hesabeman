package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: FolderGridAdapter
    private var dueShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        adapter = FolderGridAdapter(emptyList(),
            onClick = { startActivity(Intent(this, FolderActivity::class.java).putExtra("folder_id", it.id).putExtra("folder_name", it.name)) },
            onLongClick = { showFolderActions(it) }
        )
        b.list.layoutManager = GridLayoutManager(this, 2); b.list.adapter = adapter
        b.add.setOnClickListener {
            if (db.countFolders(null) >= 10) Toast.makeText(this, "حداکثر ۱۰ پوشه اصلی مجاز است.", Toast.LENGTH_LONG).show()
            else promptText(this, "پوشه جدید", "نام پوشه") { name -> if (db.addFolder(null, name)) refresh() }
        }
        b.searchButton.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    private fun showFolderActions(item: FolderItem) {
        val actions = arrayOf("تغییر نام", "انتخاب رنگ", "تغییر اولویت ۱ تا ۱۰", "حذف به سطل زباله")
        MaterialAlertDialogBuilder(this).setTitle(item.name).setItems(actions) { _, which ->
            when (which) {
                0 -> promptText(this, "تغییر نام پوشه", item.name) { db.renameFolder(item.id, it); refresh() }
                1 -> chooseFolderColor(item)
                2 -> choosePriority(item)
                3 -> MaterialAlertDialogBuilder(this).setTitle("حذف پوشه").setMessage("پوشه و دفترچه‌های داخل آن تا ۵ روز در سطل زباله قابل بازیابی هستند.")
                    .setPositiveButton("حذف") { _, _ -> db.trashFolder(item.id); refresh() }.setNegativeButton("انصراف", null).show()
            }
        }.show()
    }

    private fun chooseFolderColor(item: FolderItem) {
        val names = arrayOf("سبز ملایم", "آبی ملایم", "کرم", "بنفش ملایم", "صورتی ملایم", "خاکستری روشن")
        val colors = arrayOf("#CFE8D8", "#D1E4F2", "#F0E6C9", "#E4D8EF", "#F1D5DD", "#DDE3E5")
        MaterialAlertDialogBuilder(this).setTitle("رنگ پوشه").setItems(names) { _, which -> db.setFolderColor(item.id, colors[which]); refresh() }.show()
    }

    private fun choosePriority(item: FolderItem) {
        val values = (1..10).map { "اولویت $it" }.toTypedArray()
        MaterialAlertDialogBuilder(this).setTitle("ترتیب نمایش پوشه").setSingleChoiceItems(values, item.sortOrder - 1) { dialog, which ->
            db.setFolderOrder(item.id, which + 1); dialog.dismiss(); refresh()
        }.show()
    }

    override fun onResume() {
        super.onResume()
        db.purgeExpiredTrash()
        BackupManager.maybeAutoBackup(this)
        refresh()
        if (!dueShown) { dueShown = true; showDueReminder() }
    }

    private fun showDueReminder() {
        val today = Jalali.now().substringBefore(" - ")
        val due = db.dueNotebooks(today)
        if (due.isEmpty()) return
        val text = due.joinToString("\n") { "• ${it.name} — ${"%,d".format(kotlin.math.abs(it.balance))} تومان — سررسید ${it.dueDate}" }
        MaterialAlertDialogBuilder(this).setTitle("یادآوری سررسید بدهی").setMessage(text).setPositiveButton("باشه", null).show()
    }

    private fun refresh() {
        val items = db.folderItems(); adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val s = db.accountSummary()
        b.totalDebt.text = "${formatMoney(s.totalDebt)} تومان"
        b.totalCredit.text = "${formatMoney(s.totalCredit)} تومان"
        b.totalBalance.text = "${formatMoney(kotlin.math.abs(s.balance))} تومان ${when { s.balance < 0 -> "بدهکار"; s.balance > 0 -> "بستانکار"; else -> "تسویه" }}"
        b.totalBalance.setTextColor(getColor(when { s.balance < 0 -> R.color.debt_text; s.balance > 0 -> R.color.credit_text; else -> R.color.neutral_text }))
        b.debtorCount.text = "${s.debtors} نفر"; b.creditorCount.text = "${s.creditors} نفر"
    }
    private fun formatMoney(value: Long) = "%,d".format(value)
}
