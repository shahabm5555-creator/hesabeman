package com.mobileshahab.hesabeman

import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint; textDirection = android.view.View.TEXT_DIRECTION_RTL; textSize = 18f; setPadding(36, 28, 36, 28)
    }
    MaterialAlertDialogBuilder(context).setTitle(title).setView(input)
        .setPositiveButton("ثبت") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
    val name = EditText(context).apply { hint = "نام شخص / دفترچه"; textSize = 18f; minHeight = 60 }
    val phone = EditText(context).apply { hint = "شماره موبایل (اختیاری)"; inputType = InputType.TYPE_CLASS_PHONE; textSize = 18f; minHeight = 60 }
    box.addView(name); box.addView(phone)
    MaterialAlertDialogBuilder(context).setTitle("دفترچه حساب جدید").setMessage("شماره موبایل برای تماس و ارسال مانده حساب استفاده می‌شود.").setView(box)
        .setPositiveButton("ثبت") { _, _ -> name.text.toString().trim().takeIf { it.isNotEmpty() }?.let { done(it, phone.text.toString().trim()) } }
        .setNegativeButton("انصراف", null).show()
}

fun promptTransaction(
    context: Context,
    title: String,
    initialAmount: Long? = null,
    initialNote: String = "",
    initialDateTime: String = Jalali.now(),
    done: (Long, String, String) -> Unit
) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
    val amount = EditText(context).apply {
        hint = "مبلغ به تومان"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 18f; minHeight = 60
        if (initialAmount != null) setText(initialAmount.toString())
    }
    val note = EditText(context).apply { hint = "توضیحات"; textSize = 18f; minHeight = 60; setText(initialNote) }
    val parts = initialDateTime.split(" - ")
    val date = EditText(context).apply { hint = "تاریخ شمسی، مثال 1405/05/21"; textSize = 17f; minHeight = 56; setText(parts.getOrNull(0).orEmpty()) }
    val time = EditText(context).apply { hint = "ساعت، مثال 23:42"; textSize = 17f; minHeight = 56; setText(parts.getOrNull(1).orEmpty()) }
    box.addView(amount); box.addView(note); box.addView(date); box.addView(time)
    MaterialAlertDialogBuilder(context).setTitle(title).setMessage("تاریخ و ساعت قابل تغییر است.").setView(box)
        .setPositiveButton("ثبت") { _, _ ->
            val a = amount.text.toString().toLongOrNull()
            if (a != null && a > 0) {
                val d = date.text.toString().trim().ifBlank { Jalali.now().substringBefore(" - ") }
                val t = time.text.toString().trim().ifBlank { Jalali.now().substringAfter(" - ") }
                done(a, note.text.toString().trim(), "$d - $t")
            }
        }.setNegativeButton("انصراف", null).show()
}
