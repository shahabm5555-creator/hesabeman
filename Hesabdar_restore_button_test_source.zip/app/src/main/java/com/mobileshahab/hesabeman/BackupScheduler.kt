package com.mobileshahab.hesabeman

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One debounced writer for the two-slot data center.
 * The private DB remains usable immediately; the external CURRENT slot is updated
 * shortly after a mutation and flushed when an activity leaves the foreground.
 */
object BackupScheduler {
    private const val DELAY_MS = 700L
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val dirty = AtomicBoolean(false)
    private var appContext: Context? = null

    @Synchronized
    fun request(context: Context) {
        appContext = context.applicationContext
        dirty.set(true)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ runBackup() }, DELAY_MS)
    }

    @Synchronized
    fun flush(context: Context) {
        appContext = context.applicationContext
        if (!dirty.get()) return
        handler.removeCallbacksAndMessages(null)
        if (!dirty.compareAndSet(true, false)) return
        // Wait here so a foreground/background transition cannot leave the data center stale.
        runCatching { BackupManager.backup(context, silent = true) }
    }

    private fun runBackup() {
        val context = appContext ?: return
        if (!dirty.compareAndSet(true, false)) return
        executor.execute { runCatching { BackupManager.backup(context, silent = true) } }
    }
}
