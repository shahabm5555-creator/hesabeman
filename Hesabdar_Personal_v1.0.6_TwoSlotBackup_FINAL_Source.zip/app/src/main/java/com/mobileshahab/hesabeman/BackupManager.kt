package com.mobileshahab.hesabeman

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Simple, deterministic two-slot backup system.
 *
 * Public backup folder: Download/Hesabdarman/
 * Exactly two files are used by this app:
 *   hesabdar_database.db
 *   hesabdar_database_previous.db
 *
 * The app database itself remains in Android private storage. Public files are
 * durable backups that survive uninstall. Numbered copies are never used.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val MIN_DB_SIZE = 4096L

    /**
     * Called when MainActivity starts. It guarantees the public backup area is in
     * a known state without destroying valid user backups.
     */
    @Synchronized
    fun ensureTwoSlots(context: Context): Boolean {
        return try {
            cleanupNumberedCopies(context)
            val current = findExact(context, CANONICAL_NAME)
            val previous = findExact(context, PREVIOUS_NAME)

            val currentValid = current != null && isValidUri(context, current)
            val previousValid = previous != null && isValidUri(context, previous)

            when {
                currentValid && previousValid -> true
                currentValid -> {
                    val source = File(context.cacheDir, "ensure_previous_source.db")
                    copyUriToFile(context.contentResolver, current!!, source)
                    try {
                        writeSlot(context, PREVIOUS_NAME, source)
                    } finally { source.delete() }
                    true
                }
                previousValid -> {
                    val source = File(context.cacheDir, "ensure_current_source.db")
                    copyUriToFile(context.contentResolver, previous!!, source)
                    try {
                        writeSlot(context, CANONICAL_NAME, source)
                    } finally { source.delete() }
                    true
                }
                else -> {
                    val snapshot = createConsistentSnapshot(context)
                    try {
                        writeSlot(context, CANONICAL_NAME, snapshot)
                        writeSlot(context, PREVIOUS_NAME, snapshot)
                    } finally { snapshot.delete() }
                    true
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Automatic backup after real database changes. */
    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val snapshot = createConsistentSnapshot(context)
            try {
                validateDatabase(snapshot)

                // If this is a newly installed empty database and an old valid
                // external backup already exists, never overwrite that backup.
                if (isFreshDatabase(context) && findBestExternalBackup(context) != null) {
                    return true
                }

                val current = findExact(context, CANONICAL_NAME)
                if (current != null && isValidUri(context, current)) {
                    val old = File(context.cacheDir, "old_primary.db")
                    copyUriToFile(context.contentResolver, current, old)
                    try {
                        validateDatabase(old)
                        writeSlot(context, PREVIOUS_NAME, old)
                    } finally { old.delete() }
                } else {
                    // First backup: previous is the same valid snapshot.
                    writeSlot(context, PREVIOUS_NAME, snapshot)
                }

                writeSlot(context, CANONICAL_NAME, snapshot)
                cleanupNumberedCopies(context)
            } finally { snapshot.delete() }

            if (!silent) Toast.makeText(
                context,
                "پشتیبان ذخیره شد. فقط دو فایل اصلی نگهداری می‌شوند.",
                Toast.LENGTH_LONG
            ).show()
            true
        } catch (e: Exception) {
            if (!silent) Toast.makeText(
                context,
                "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }

    /** Only the two exact slot names are trusted. Numbered copies are ignored. */
    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        val current = findExact(context, CANONICAL_NAME)
        if (current != null && isValidUri(context, current)) return current
        val previous = findExact(context, PREVIOUS_NAME)
        if (previous != null && isValidUri(context, previous)) return previous
        return null
    }

    fun restoreLatest(context: Context): Boolean {
        return findBestExternalBackup(context)?.let { restore(context, it) } ?: false
    }

    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val candidate = File(context.cacheDir, "restore_candidate.db")
        val target = DbHelper.databaseFile(context)
        val replacement = File(target.parentFile, "${DbHelper.DB_NAME}.restore.tmp")
        return try {
            candidate.delete(); replacement.delete()
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)

            DbHelper.closeAll()
            target.parentFile?.mkdirs()
            deleteSidecars(target)
            copyFile(candidate, replacement)
            validateDatabase(replacement)

            if (target.exists() && !target.delete()) error("پایگاه داده فعلی قابل جایگزینی نیست")
            if (!replacement.renameTo(target)) {
                copyFile(candidate, target)
                replacement.delete()
            }
            deleteSidecars(target)
            validateDatabase(target)
            true
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}",
                Toast.LENGTH_LONG
            ).show()
            false
        } finally {
            candidate.delete(); replacement.delete()
        }
    }

    @Synchronized
    fun hasExternalBackupDifferentFromLive(context: Context): Boolean {
        val uri = findBestExternalBackup(context) ?: return false
        return try {
            val live = createConsistentSnapshot(context)
            val external = File(context.cacheDir, "external_compare.db")
            try {
                copyUriToFile(context.contentResolver, uri, external)
                sha256(live) != sha256(external)
            } finally { live.delete(); external.delete() }
        } catch (_: Exception) { false }
    }

    fun isFreshDatabase(context: Context): Boolean {
        val file = DbHelper.databaseFile(context)
        if (!file.exists() || file.length() < MIN_DB_SIZE) return true
        return try {
            val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val tables = listOf("notebooks", "tx", "invoices", "installment_plans", "checks")
                tables.all { table ->
                    db.rawQuery("SELECT COUNT(*) FROM $table", null).use {
                        it.moveToFirst() && it.getLong(0) == 0L
                    }
                }
            } finally { db.close() }
        } catch (_: Exception) { true }
    }

    private fun createConsistentSnapshot(context: Context): File {
        val helper = DbHelper(context)
        val snapshot = File(context.cacheDir, "hesabdar_snapshot.db")
        snapshot.delete()
        return try {
            val db = helper.writableDatabase
            db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            val escaped = snapshot.absolutePath.replace("'", "''")
            db.execSQL("VACUUM INTO '$escaped'")
            helper.close()
            if (!snapshot.exists() || snapshot.length() < MIN_DB_SIZE) error("اسنپ‌شات دیتابیس ساخته نشد")
            snapshot
        } catch (e: Exception) {
            runCatching { helper.close() }
            snapshot.delete()
            throw e
        }
    }

    /**
     * Writes an existing MediaStore row when possible. If the row is stale or
     * cannot be written, it is replaced with one new row of the exact name.
     * This is the key rule that prevents (1), (2), (3)... files.
     */
    private fun writeSlot(context: Context, name: String, source: File) {
        validateDatabase(source)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val dir = backupDirectory()
            if (!dir.exists() && !dir.mkdirs()) error("پوشه پشتیبان قابل ساخت نیست")
            val target = File(dir, name)
            val tmp = File(dir, ".${name}.tmp")
            copyFile(source, tmp)
            validateDatabase(tmp)
            if (!tmp.renameTo(target)) {
                copyFile(tmp, target); tmp.delete()
            }
            cleanupLegacyFiles(dir)
            return
        }

        val resolver = context.contentResolver
        val existing = findExact(context, name)
        if (existing != null) {
            try {
                writeExistingUri(resolver, existing, source)
                if (isValidUri(context, existing)) return
            } catch (_: Exception) { }
            runCatching { resolver.delete(existing, null, null) }
        }

        // Remove every numbered variant before creating the exact row.
        cleanupNumberedCopies(context)
        val uri = resolver.insert(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        ) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")

        try {
            resolver.openOutputStream(uri, "wt")?.use { output ->
                FileInputStream(source).use { input -> input.copyTo(output) }
            } ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")

            val probe = File(context.cacheDir, "slot_probe.db")
            try {
                copyUriToFile(resolver, uri, probe)
                validateDatabase(probe)
            } finally { probe.delete() }

            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
    }

    private fun writeExistingUri(resolver: ContentResolver, uri: Uri, source: File) {
        resolver.openOutputStream(uri, "wt")?.use { output ->
            FileInputStream(source).use { input -> input.copyTo(output) }
        } ?: error("فایل پشتیبان قابل نوشتن نیست")
    }

    private fun findExact(context: Context, name: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val f = File(backupDirectory(), name)
            return if (f.exists()) Uri.fromFile(f) else null
        }
        context.contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH, name),
            null
        )?.use { c ->
            if (c.moveToFirst()) {
                return ContentUris.withAppendedId(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID))
                )
            }
        }
        return null
    }

    /** Delete every numbered/legacy backup produced by older versions. */
    private fun cleanupNumberedCopies(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            cleanupLegacyFiles(backupDirectory())
            return
        }
        val resolver = context.contentResolver
        val toDelete = mutableListOf<Uri>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=?",
            arrayOf(RELATIVE_PATH),
            null
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            val pending = c.getColumnIndexOrThrow(MediaStore.Downloads.IS_PENDING)
            while (c.moveToNext()) {
                val n = c.getString(name)
                if (c.getInt(pending) != 0) continue
                val numbered = n.matches(Regex("hesabdar_database(?:_previous)? \\(\\d+\\)\\.db"))
                val legacy = n.startsWith("hesabdar_history_") || n.startsWith("hesabdar_database_backup")
                if (numbered || legacy) {
                    toDelete += ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id))
                }
            }
        }
        toDelete.forEach { resolver.delete(it, null, null) }
    }

    private fun cleanupLegacyFiles(dir: File) {
        if (!dir.exists()) return
        dir.listFiles()?.forEach { f ->
            val n = f.name
            val numbered = n.matches(Regex("hesabdar_database(?:_previous)? \\(\\d+\\)\\.db"))
            val legacy = n.startsWith("hesabdar_history_") || n.startsWith("hesabdar_database_backup")
            if (numbered || legacy) f.delete()
        }
    }

    private fun backupDirectory(): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Hesabdarman"
    )

    private fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        } ?: error("فایل قابل خواندن نیست")
    }

    private fun copyFile(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        }
    }

    private fun deleteSidecars(target: File) {
        File(target.path + "-wal").delete()
        File(target.path + "-shm").delete()
        File(target.path + "-journal").delete()
    }

    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val probe = File(context.cacheDir, "uri_probe.db")
        return try {
            copyUriToFile(context.contentResolver, uri, probe)
            validateDatabase(probe)
            true
        } catch (_: Exception) { false }
        finally { probe.delete() }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < MIN_DB_SIZE) error("فایل پشتیبان خالی یا ناقص است")
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf(
                "folders", "notebooks", "tx", "invoices", "invoice_items",
                "installment_plans", "installment_items", "checks", "app_meta"
            )
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) found += c.getString(0)
            }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")

            val integrityOk = db.rawQuery("PRAGMA integrity_check", null).use {
                it.moveToFirst() && it.getString(0).equals("ok", true)
            }
            if (!integrityOk) error("فایل پشتیبان آسیب‌دیده است")

            val appId = db.rawQuery("SELECT value FROM app_meta WHERE key='app_id' LIMIT 1", null).use {
                if (it.moveToFirst()) it.getString(0) else ""
            }
            if (appId != "hesabdar_personal") error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")

            val version = db.rawQuery("PRAGMA user_version", null).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        } finally { db.close() }
    }
}
