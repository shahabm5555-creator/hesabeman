package com.mobileshahab.hesabeman

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Durable two-file backup system.
 *
 * The public backup folder contains ONLY these two logical files:
 *   1) hesabdar_database.db          -> current/latest snapshot
 *   2) hesabdar_database_previous.db -> previous snapshot
 *
 * There is no history chain and no SQLite journal/WAL file is ever used as a backup.
 * The live database remains in Android's private database directory.
 */
object BackupManager {
    const val CANONICAL_NAME = "hesabdar_database.db"
    const val PREVIOUS_NAME = "hesabdar_database_previous.db"
    private const val RELATIVE_PATH = "Download/Hesabdarman/"
    private const val MIN_DB_SIZE = 4096L

    @Synchronized
    fun backup(context: Context, silent: Boolean = false): Boolean {
        return try {
            val snapshot = createConsistentSnapshot(context)
            try {
                validateDatabase(snapshot)
                // A reinstall creates a fresh private database. If the old external
                // backup is still present, NEVER rotate/overwrite it just because
                // the user made the first transaction after reinstall. The old data
                // must survive until the user restores it or explicitly replaces it.
                if (isFreshDatabase(context) && findBestExternalBackup(context) != null) {
                    return true
                }
                publishTwoFiles(context, snapshot)
            } finally {
                snapshot.delete()
            }
            if (!silent) {
                Toast.makeText(
                    context,
                    "پشتیبان ذخیره شد.\nفقط دو فایل اصلی و قبلی نگهداری می‌شوند.",
                    Toast.LENGTH_LONG
                ).show()
            }
            true
        } catch (e: Exception) {
            if (!silent) {
                Toast.makeText(
                    context,
                    "خطا در پشتیبان‌گیری: ${e.message ?: "خطای نامشخص"}",
                    Toast.LENGTH_LONG
                ).show()
            }
            false
        }
    }

    /** Finds the current valid backup; previous is used only if current is missing/corrupt. */
    @Synchronized
    fun findBestExternalBackup(context: Context): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val current = findValidMediaCandidate(context, CANONICAL_NAME)
            if (current != null) return current
            return findValidMediaCandidate(context, PREVIOUS_NAME)
        }

        val dir = backupDirectory()
        val current = File(dir, CANONICAL_NAME)
        if (isValid(current)) return Uri.fromFile(current)
        val previous = File(dir, PREVIOUS_NAME)
        return if (isValid(previous)) Uri.fromFile(previous) else null
    }

    /**
     * Restores one SQLite snapshot selected by the user. The file name is irrelevant,
     * provided the database belongs to this app and passes integrity checks.
     */
    @Synchronized
    fun restore(context: Context, uri: Uri): Boolean {
        val candidate = File(context.cacheDir, "restore_candidate.db")
        val replacement = File(context.getDatabasePath(DbHelper.DB_NAME).parentFile, "${DbHelper.DB_NAME}.restore.tmp")
        return try {
            candidate.delete()
            replacement.delete()
            copyUriToFile(context.contentResolver, uri, candidate)
            validateDatabase(candidate)

            DbHelper.closeAll()
            val target = DbHelper.databaseFile(context)
            target.parentFile?.mkdirs()
            deleteSidecars(target)

            copyFile(candidate, replacement)
            validateDatabase(replacement)

            if (target.exists() && !target.delete()) {
                error("پایگاه داده فعلی قابل جایگزینی نیست")
            }
            if (!replacement.renameTo(target)) {
                copyFile(candidate, target)
                replacement.delete()
            }
            deleteSidecars(target)
            validateDatabase(target)
            true
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "خطا در بازیابی: ${e.message ?: "فایل پشتیبان معتبر نیست"}",
                Toast.LENGTH_LONG
            ).show()
            false
        } finally {
            candidate.delete()
            replacement.delete()
        }
    }

    /**
     * Returns true when the external canonical backup is valid but its contents differ
     * from the currently installed live database. This is used after reinstall/manual
     * replacement so a copied old backup can be detected without guessing by filename.
     */
    @Synchronized
    fun hasExternalBackupDifferentFromLive(context: Context): Boolean {
        val uri = findBestExternalBackup(context) ?: return false
        if (!isValidUri(context, uri)) return false
        return try {
            val live = createConsistentSnapshot(context)
            val external = File(context.cacheDir, "external_compare.db")
            try {
                copyUriToFile(context.contentResolver, uri, external)
                sha256(live) != sha256(external)
            } finally {
                live.delete()
                external.delete()
            }
        } catch (_: Exception) {
            false
        }
    }

    fun restoreLatest(context: Context): Boolean {
        val uri = findBestExternalBackup(context) ?: return false
        return restore(context, uri)
    }

    /** True when the installed database is only a fresh shell/default database. */
    fun isFreshDatabase(context: Context): Boolean {
        val file = DbHelper.databaseFile(context)
        if (!file.exists() || file.length() < MIN_DB_SIZE) return true
        return try {
            val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val counts = listOf("notebooks", "tx", "invoices", "installment_plans", "checks").map { table ->
                    db.rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
                }
                counts.all { it == 0L }
            } finally {
                db.close()
            }
        } catch (_: Exception) {
            true
        }
    }

    /** Creates a standalone SQLite file, so -wal/-shm/-journal are not needed. */
    private fun createConsistentSnapshot(context: Context): File {
        val helper = DbHelper(context)
        val snapshot = File(context.cacheDir, "hesabdar_snapshot.db")
        snapshot.delete()
        return try {
            val db = helper.writableDatabase
            db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { }
            val escaped = snapshot.absolutePath.replace("'", "''")
            db.execSQL("VACUUM INTO '$escaped'")
            helper.close()
            if (!snapshot.exists() || snapshot.length() < MIN_DB_SIZE) {
                error("اسنپ‌شات دیتابیس ساخته نشد")
            }
            snapshot
        } catch (e: Exception) {
            runCatching { helper.close() }
            snapshot.delete()
            throw e
        }
    }

    /**
     * Atomic-ish two-slot rotation. Existing files are overwritten instead of inserting
     * new MediaStore rows, which prevents hesabdar_database.db (1), (2), ... proliferation.
     */
    private fun publishTwoFiles(context: Context, source: File) {
        validateDatabase(source)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Remove old numbered MediaStore copies BEFORE inserting/writing anything.
            // Otherwise Android may auto-create another (1), (2), ... file.
            cleanupMediaStoreFolder(context)
            val current = findExactMediaCandidate(context, CANONICAL_NAME)
            if (current != null && isValidUri(context, current)) {
                val old = File(context.cacheDir, "old_primary.db")
                copyUriToFile(context.contentResolver, current, old)
                try {
                    validateDatabase(old)
                    writeMediaFile(context, PREVIOUS_NAME, old)
                } finally {
                    old.delete()
                }
            }
            writeMediaFile(context, CANONICAL_NAME, source)
            cleanupMediaStoreFolder(context)
        } else {
            val dir = backupDirectory()
            if (!dir.exists() && !dir.mkdirs()) error("پوشه پشتیبان قابل ساخت نیست")
            val current = File(dir, CANONICAL_NAME)
            val previous = File(dir, PREVIOUS_NAME)
            if (isValid(current)) copyFile(current, previous)

            val tmp = File(dir, ".${CANONICAL_NAME}.tmp")
            copyFile(source, tmp)
            validateDatabase(tmp)
            if (current.exists() && !current.delete()) error("فایل پشتیبان قبلی قابل جایگزینی نیست")
            if (!tmp.renameTo(current)) {
                copyFile(source, current)
                tmp.delete()
            }
            cleanupLegacyFiles(dir)
        }
    }

    private fun writeMediaFile(context: Context, name: String, source: File) {
        val resolver = context.contentResolver
        val uri = findExactMediaCandidate(context, name) ?: run {
            resolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                    put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
            ) ?: error("امکان ساخت فایل پشتیبان وجود ندارد")
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 1) }, null, null)
            }
            resolver.openOutputStream(uri, "wt")?.use { output ->
                FileInputStream(source).use { input -> input.copyTo(output) }
            } ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")

            val probe = File(context.cacheDir, "backup_probe.db")
            try {
                copyUriToFile(resolver, uri, probe)
                validateDatabase(probe)
            } finally {
                probe.delete()
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.update(uri, ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/x-sqlite3")
                    put(MediaStore.Downloads.RELATIVE_PATH, RELATIVE_PATH)
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }, null, null)
            }
        } catch (e: Exception) {
            // Do not delete an existing valid slot if writing it failed.
            throw e
        }
    }

    private fun findExactMediaCandidate(context: Context, logicalName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH, logicalName),
            null
        )?.use { c ->
            if (c.moveToFirst()) {
                val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID))
                return ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
            }
        }
        return null
    }

    private fun findAnyMediaCandidate(context: Context, logicalName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        data class MediaCandidate(val uri: Uri, val name: String, val modified: Long)
        val matches = mutableListOf<MediaCandidate>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_MODIFIED),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            val modified = c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
            while (c.moveToNext()) {
                val n = c.getString(name)
                if (isSlotName(n, logicalName)) {
                    matches += MediaCandidate(
                        ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id)),
                        n,
                        c.getLong(modified)
                    )
                }
            }
        }
        // Always prefer the exact canonical name. A file manager may leave an older
        // duplicate such as "hesabdar_database.db (1)"; never let that shadow the
        // real two-slot file.
        return matches.firstOrNull { it.name == logicalName }?.uri
            ?: matches.maxByOrNull { it.modified }?.uri
    }

    private fun findValidMediaCandidate(context: Context, logicalName: String): Uri? {
        val candidates = mediaCandidates(context, logicalName)
        for (uri in candidates) {
            if (isValidUri(context, uri)) return uri
        }
        return null
    }

    private fun mediaCandidates(context: Context, logicalName: String): List<Uri> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return emptyList()
        val resolver = context.contentResolver
        data class MediaCandidate(val uri: Uri, val name: String, val modified: Long)
        val result = mutableListOf<MediaCandidate>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_MODIFIED),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH),
            "${MediaStore.Downloads.DATE_MODIFIED} DESC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            val modified = c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
            while (c.moveToNext()) {
                val n = c.getString(name)
                if (isSlotName(n, logicalName)) {
                    result += MediaCandidate(
                        ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id)),
                        n,
                        c.getLong(modified)
                    )
                }
            }
        }
        return result.sortedWith(compareBy<MediaCandidate> { if (it.name == logicalName) 0 else 1 }.thenByDescending { it.modified }).map { it.uri }
    }

    /** Deletes numbered copies and old history files, leaving exactly the two logical slots. */
    private fun cleanupMediaStoreFolder(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val resolver = context.contentResolver
        val deleteUris = mutableListOf<Uri>()
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.IS_PENDING),
            "${MediaStore.Downloads.RELATIVE_PATH}=? AND ${MediaStore.Downloads.IS_PENDING}=0",
            arrayOf(RELATIVE_PATH),
            null
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (c.moveToNext()) {
                val n = c.getString(name)
                val isCurrent = n == CANONICAL_NAME
                val isPrevious = n == PREVIOUS_NAME
                val isDuplicate = isSlotName(n, CANONICAL_NAME) || isSlotName(n, PREVIOUS_NAME)
                val isOld = n.startsWith("hesabdar_history_") || n.startsWith("hesabdar_database_backup")
                if ((!isCurrent && !isPrevious && isDuplicate) || isOld) {
                    deleteUris += ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id))
                }
            }
        }
        deleteUris.forEach { resolver.delete(it, null, null) }
    }

    private fun cleanupLegacyFiles(dir: File) {
        dir.listFiles()?.forEach { file ->
            if (!file.isFile) return@forEach
            val n = file.name
            val numbered = n.matches(Regex("hesabdar_database(?:_previous)? \\(\\d+\\)\\.db"))
            if (numbered || n.startsWith("hesabdar_history_") || n.startsWith("hesabdar_database_backup")) {
                file.delete()
            }
        }
    }

    private fun isSlotName(actual: String, logical: String): Boolean {
        if (actual == logical) return true
        val base = logical.removeSuffix(".db")
        return actual.matches(Regex("${Regex.escape(base)} \\(\\d+\\)\\.db"))
    }

    private fun backupDirectory(): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Hesabdarman"
    )

    private fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        } ?: error("فایل قابل خواندن نیست")
    }

    private fun copyFile(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target, false).use { output -> input.copyTo(output) }
        }
    }

    private fun deleteSidecars(target: File) {
        File(target.path + "-wal").delete()
        File(target.path + "-shm").delete()
        File(target.path + "-journal").delete()
    }

    private fun isValid(file: File): Boolean = runCatching {
        validateDatabase(file)
        true
    }.getOrDefault(false)

    private fun isValidUri(context: Context, uri: Uri): Boolean {
        val probe = File(context.cacheDir, "uri_probe.db")
        return try {
            copyUriToFile(context.contentResolver, uri, probe)
            validateDatabase(probe)
            true
        } catch (_: Exception) {
            false
        } finally {
            probe.delete()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun validateDatabase(file: File) {
        if (!file.exists() || file.length() < MIN_DB_SIZE) {
            error("فایل پشتیبان خالی یا ناقص است")
        }
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = setOf(
                "folders", "notebooks", "tx", "invoices", "invoice_items",
                "installment_plans", "installment_items", "checks", "app_meta"
            )
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) found += c.getString(0)
            }
            if (!found.containsAll(required)) error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")

            val integrityOk = db.rawQuery("PRAGMA integrity_check", null).use {
                it.moveToFirst() && it.getString(0).equals("ok", true)
            }
            if (!integrityOk) error("فایل پشتیبان آسیب‌دیده است")

            val appId = db.rawQuery("SELECT value FROM app_meta WHERE key='app_id' LIMIT 1", null).use {
                if (it.moveToFirst()) it.getString(0) else ""
            }
            if (appId != "hesabdar_personal") error("این فایل پشتیبان متعلق به حسابدار شخصی نیست")

            val version = db.rawQuery("PRAGMA user_version", null).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (version > DbHelper.DATABASE_VERSION) error("نسخه پشتیبان از نسخه فعلی برنامه جدیدتر است")
        } finally {
            db.close()
        }
    }
}
