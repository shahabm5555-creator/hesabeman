package com.mobileshahab.hesabeman

import android.content.Context
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

private fun normalizeDigits(value: String): String = value.map {
    when (it) {
        in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
        else -> it
    }
}.joinToString("")

private fun formatAmountInput(value: String): String {
    val digits = normalizeDigits(value).filter(Char::isDigit).trimStart('0').ifEmpty { "0" }
    return try { "%,d".format(digits.toLong()) } catch (_: Exception) { digits }
}

private fun attachDateFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(8)
            val formatted = buildString {
                raw.forEachIndexed { i, ch ->
                    if (i == 4 || i == 6) append('/')
                    append(ch)
                }
            }
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

private fun attachTimeFormatter(input: EditText) {
    input.addTextChangedListener(object : TextWatcher {
        private var busy = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(e: Editable?) {
            if (busy) return
            val raw = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).take(4)
            val formatted = if (raw.length > 2) raw.substring(0, 2) + ":" + raw.substring(2) else raw
            if (e?.toString() != formatted) { busy = true; input.setText(formatted); input.setSelection(formatted.length); busy = false }
        }
    })
}

fun promptText(context: Context, title: String, hint: String = "", done: (String) -> Unit) {
    val input = EditText(context).apply {
        this.hint = hint; textDirection = View.TEXT_DIRECTION_RTL; textSize = 18f; setPadding(36, 28, 36, 28)
    }
    MaterialAlertDialogBuilder(context).setTitle(title).setView(input)
        .setPositiveButton("ثبت") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptNotebook(context: Context, done: (String, String) -> Unit) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
    val name = EditText(context).apply { hint = "نام شخص / حساب"; textSize = 18f; minHeight = 60 }
    val phone = EditText(context).apply { hint = "شماره موبایل (اختیاری)"; inputType = InputType.TYPE_CLASS_PHONE; textSize = 18f; minHeight = 60 }
    box.addView(name); box.addView(phone)
    MaterialAlertDialogBuilder(context).setTitle("حساب جدید").setMessage("شماره موبایل برای تماس و ارسال مانده حساب استفاده می‌شود.").setView(box)
        .setPositiveButton("ثبت") { _, _ -> name.text.toString().trim().takeIf { it.isNotEmpty() }?.let { done(it, normalizeDigits(phone.text.toString().trim())) } }
        .setNegativeButton("انصراف", null).show()
}

fun promptOrder(context: Context, title: String, current: Int, max: Int, done: (Int) -> Unit) {
    val input = EditText(context).apply {
        hint = "شماره ردیف از ۱ تا $max"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 18f; minHeight = 60
        setText(current.toString()); selectAll()
    }
    MaterialAlertDialogBuilder(context).setTitle(title)
        .setMessage("ردیف جدید را وارد کنید؛ موارد دیگر خودکار جابه‌جا می‌شوند.")
        .setView(input)
        .setPositiveButton("انتقال") { _, _ -> input.text.toString().toIntOrNull()?.takeIf { it in 1..max }?.let(done) }
        .setNegativeButton("انصراف", null).show()
}

fun promptTransaction(
    context: Context,
    title: String,
    initialKind: String = "debt",
    initialAmount: Long? = null,
    initialNote: String = "",
    initialDateTime: String = Jalali.now(),
    done: (String, Long, String, String) -> Unit
) {
    val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 8) }

    val typeGroup = RadioGroup(context).apply { orientation = RadioGroup.HORIZONTAL; gravity = android.view.Gravity.CENTER }
    val debtRadio = RadioButton(context).apply { text = "پرداخت کردم"; textSize = 15f; isChecked = initialKind == "debt" }
    val creditRadio = RadioButton(context).apply { text = "دریافت کردم"; textSize = 15f; isChecked = initialKind == "credit" }
    typeGroup.addView(debtRadio, RadioGroup.LayoutParams(0, 52, 1f)); typeGroup.addView(creditRadio, RadioGroup.LayoutParams(0, 52, 1f))

    val amount = EditText(context).apply {
        hint = "مبلغ به تومان"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 18f; minHeight = 58
        filters = arrayOf(InputFilter.LengthFilter(18))
        setText(initialAmount?.let { "%,d".format(it) } ?: "")
        setSelection(text.length)
        addTextChangedListener(object : TextWatcher {
            private var busy = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                val formatted = formatAmountInput(e?.toString().orEmpty())
                if (e?.toString() != formatted) { busy = true; setText(formatted); setSelection(text.length); busy = false }
            }
        })
    }
    val note = EditText(context).apply { hint = "توضیحات"; textSize = 17f; minHeight = 56; setText(initialNote) }
    val parts = initialDateTime.split(" - ")
    val date = EditText(context).apply {
        hint = "تاریخ شمسی، مثال 1405/05/21"; textSize = 17f; minHeight = 54; setText(parts.getOrNull(0).orEmpty())
        inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(InputFilter.LengthFilter(10))
    }
    val time = EditText(context).apply {
        hint = "ساعت، مثال 23:42"; textSize = 17f; minHeight = 54; setText(parts.getOrNull(1).orEmpty())
        inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(InputFilter.LengthFilter(5))
    }
    attachDateFormatter(date)
    attachTimeFormatter(time)
    box.addView(typeGroup); box.addView(amount); box.addView(note); box.addView(date); box.addView(time)

    val dialog = MaterialAlertDialogBuilder(context).setTitle(title).setMessage("مبلغ با جداکننده سه‌رقمی نمایش داده می‌شود؛ تاریخ و ساعت باید معتبر باشند.").setView(box)
        .setPositiveButton("ثبت", null).setNegativeButton("انصراف", null).create()
    dialog.setOnShowListener {
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val a = normalizeDigits(amount.text.toString()).replace(",", "").toLongOrNull()
            val d = normalizeDigits(date.text.toString().trim())
            val t = normalizeDigits(time.text.toString().trim())
            val finalDate = if (d.isBlank()) Jalali.now().substringBefore(" - ") else d
            val finalTime = if (t.isBlank()) Jalali.now().substringAfter(" - ") else t
            when {
                a == null || a <= 0L -> Toast.makeText(context, "مبلغ معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                !Jalali.isValidDate(finalDate) -> Toast.makeText(context, "تاریخ شمسی معتبر نیست.", Toast.LENGTH_SHORT).show()
                !Jalali.isValidTime(finalTime) -> Toast.makeText(context, "ساعت معتبر نیست.", Toast.LENGTH_SHORT).show()
                else -> {
                    val kind = if (debtRadio.isChecked) "debt" else "credit"
                    done(kind, a, note.text.toString().trim(), "$finalDate - $finalTime")
                    dialog.dismiss()
                }
            }
        }
    }
    dialog.show()
}
