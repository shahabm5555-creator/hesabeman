package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class InvoiceActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1
    private var notebookName: String = ""
    private val items = mutableListOf<InvoiceItem>()
    private lateinit var itemsContainer: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var kindDebt: RadioButton
    private lateinit var kindCredit: RadioButton

    private val pdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, bars.top, 0, bars.bottom); insets
            }
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 0, 12, 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(64))
        }
        val backBtn = MaterialButton(this).apply {
            text = "×"; textSize = 24f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            minWidth = 0; insetTop = 0; insetBottom = 0
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { finish() }
        }
        val toolbarTitle = TextView(this).apply {
            text = "فاکتور جدید — $notebookName"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        toolbar.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        toolbar.addView(toolbarTitle)
        toolbar.addView(View(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(toolbar)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(80))
        }

        // ── Items section ──
        val itemsCard = card()
        itemsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(6))
        }
        itemsCard.addView(itemsContainer)

        val addItemBtn = MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 13f
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.primary_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
            cornerRadius = dp(14)
            layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) }
            setOnClickListener { showAddItemDialog() }
        }

        // ── Summary ──
        val summaryCard = card()
        val summaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val totalLabel = TextView(this).apply {
            text = "جمع کل:"; textSize = 14f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        totalText = TextView(this).apply {
            text = "۰ تومان"; textSize = 16f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.primary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        summaryRow.addView(totalLabel); summaryRow.addView(totalText)
        summaryCard.addView(summaryRow)

        // ── Kind (debt / credit) ──
        val kindCard = card()
        val kindBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val kindLabel = TextView(this).apply {
            text = "نوع تراکنش در حساب"; textSize = 12f
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
        }
        val kindRow = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        kindDebt = RadioButton(this).apply {
            text = "↑ پرداختی"; textSize = 13f; isChecked = true
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        kindCredit = RadioButton(this).apply {
            text = "↓ دریافتی"; textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        kindRow.addView(kindDebt); kindRow.addView(kindCredit)
        kindBox.addView(kindLabel); kindBox.addView(kindRow)
        kindCard.addView(kindBox)

        // ── Note ──
        val noteCard = card()
        val noteField = EditText(this).apply {
            hint = "توضیحات اختیاری فاکتور"
            textSize = 13f; gravity = Gravity.END
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setHintTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            background = null
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        noteCard.addView(noteField)

        // ── Action buttons ──
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        }
        val btnSave = MaterialButton(this).apply {
            text = "ثبت در حساب"; textSize = 13f; cornerRadius = dp(16)
            layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) }
            setOnClickListener { saveInvoice(noteField.text.toString()) }
        }
        val btnPdf = MaterialButton(this).apply {
            text = "PDF / ذخیره"; textSize = 13f; cornerRadius = dp(16)
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_soft))
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_text))
            layoutParams = LinearLayout.LayoutParams(0, dp(52), 0.55f).apply { marginStart = dp(6) }
            setOnClickListener {
                if (items.isEmpty()) { Toast.makeText(this@InvoiceActivity, "هیچ قلمی اضافه نشده.", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                // Save to Downloads/HesabdarInvoices automatically (archive folder) and also share
                val invNum = db.nextInvoiceNumber(notebookId)
                val fileName = "فاکتور-${notebookName.replace("/","-")}-شماره${invNum}.pdf"
                val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                val invoiceDir = java.io.File(dir, "HesabdarInvoices").also { it.mkdirs() }
                val file = java.io.File(invoiceDir, fileName)
                val uri = android.net.Uri.fromFile(file)
                exportPdfToFile(uri, file)
            }
        }
        btnRow.addView(btnSave); btnRow.addView(btnPdf)

        inner.addView(itemsCard); inner.addView(addItemBtn)
        inner.addView(summaryCard); inner.addView(kindCard)
        inner.addView(noteCard); inner.addView(btnRow)
        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun card(): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(18).toFloat(); cardElevation = dp(1).toFloat()
        setCardBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.surface))
        strokeWidth = dp(1); strokeColor = ContextCompat.getColor(this@InvoiceActivity, R.color.divider)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun refreshItems() {
        itemsContainer.removeAllViews()
        items.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val info = TextView(this).apply {
                text = "${item.name}  ×${item.qty}  @${ "%,d".format(item.unitPrice) }  = ${ "%,d".format(item.total) } تومان"
                textSize = 12f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            }
            val del = MaterialButton(this).apply {
                text = "×"; textSize = 16f; minWidth = 0; insetTop = 0; insetBottom = 0
                setPadding(dp(8), 0, dp(8), 0)
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.debt_text))
                setOnClickListener { items.removeAt(idx); refreshItems() }
            }
            row.addView(info); row.addView(del)
            itemsContainer.addView(row)
            if (idx < items.size - 1) {
                itemsContainer.addView(View(this).apply {
                    setBackgroundColor(ContextCompat.getColor(this@InvoiceActivity, R.color.divider))
                    layoutParams = LinearLayout.LayoutParams(-1, dp(1))
                })
            }
        }
        val total = items.sumOf { it.total }
        totalText.text = "%,d تومان".format(total)
    }

    private fun showAddItemDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        fun field(hint: String) = EditText(this).apply {
            this.hint = hint; textSize = 14f; gravity = Gravity.END
            setTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.text))
            setHintTextColor(ContextCompat.getColor(this@InvoiceActivity, R.color.secondary))
            setPadding(0, dp(10), 0, dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        }
        val nameField = field("نام کالا/خدمات").apply {
            gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
        }
        val qtyField = field("مقدار (عدد)").apply {
            inputType = android.text.InputType.TYPE_CLASS_PHONE; setText("1")
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        }
        val priceField = field("فی (تومان)").apply {
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            addTextChangedListener(object : android.text.TextWatcher {
                private var busy = false
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: android.text.Editable?) {
                    if (busy) return
                    val digits = normalizeDigits(e?.toString().orEmpty()).filter(Char::isDigit).trimStart('0').ifEmpty { "" }
                    val formatted = if (digits.isEmpty()) "" else groupDigits(digits)
                    if (e?.toString() != formatted) {
                        busy = true; setText(formatted); setSelection(text.length); busy = false
                    }
                }
            })
        }
        box.addView(nameField); box.addView(qtyField); box.addView(priceField)

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("افزودن قلم فاکتور")
            .setView(box)
            .setPositiveButton("افزودن") { _, _ ->
                val name = nameField.text.toString().trim()
                val qty = normalizeDigits(qtyField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
                val price = normalizeDigits(priceField.text.toString()).filter(Char::isDigit).toLongOrNull() ?: 0L
                when {
                    name.isBlank() -> Toast.makeText(this, "نام را وارد کنید.", Toast.LENGTH_SHORT).show()
                    qty <= 0 -> Toast.makeText(this, "مقدار معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                    price <= 0 -> Toast.makeText(this, "فی معتبر وارد کنید.", Toast.LENGTH_SHORT).show()
                    else -> { items.add(InvoiceItem(name = name, qty = qty, unitPrice = price)); refreshItems() }
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun normalizeDigits(value: String): String = value.map {
        when (it) {
            in '۰'..'۹' -> ('0'.code + (it.code - '۰'.code)).toChar()
            in '٠'..'٩' -> ('0'.code + (it.code - '٠'.code)).toChar()
            else -> it
        }
    }.joinToString("")

    private fun groupDigits(digits: String): String {
        val sb = StringBuilder()
        for ((i, c) in digits.reversed().withIndex()) {
            if (i > 0 && i % 3 == 0) sb.append(',')
            sb.append(c)
        }
        return sb.reverse().toString()
    }

    private fun saveInvoice(note: String) {
        if (items.isEmpty()) { Toast.makeText(this, "حداقل یک قلم اضافه کنید.", Toast.LENGTH_SHORT).show(); return }
        val kind = if (kindDebt.isChecked) "debt" else "credit"
        val id = db.saveInvoice(notebookId, kind, items, note, Jalali.now())
        if (id != -1L) {
            Toast.makeText(this, "فاکتور با موفقیت ثبت شد.", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK); finish()
        } else {
            Toast.makeText(this, "خطا در ثبت فاکتور.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportPdf(uri: Uri) {
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        exportPdfToFile(uri, null, prefs)
    }

    private fun exportPdfToFile(uri: android.net.Uri, file: java.io.File?, prefs: android.content.SharedPreferences = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)) {
        val sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: ""
        val sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: ""
        val sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: ""
        val sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: ""
        val invNum = db.nextInvoiceNumber(notebookId)
        val targetUri = if (file != null) {
            android.net.Uri.fromFile(file)
        } else uri
        InvoicePdfExporter.export(
            context = this,
            uri = targetUri,
            invoiceNumber = invNum,
            buyerName = notebookName,
            sellerName = sellerName,
            sellerAddress = sellerAddress,
            sellerPhone = sellerPhone,
            sellerSlogan = sellerSlogan,
            items = items,
            date = Jalali.now(),
            onDone = { _ ->
                val shareFile = file ?: run {
                    val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    java.io.File(java.io.File(dir, "HesabdarInvoices").also { it.mkdirs() }, "فاکتور-${notebookName.replace("/","-")}-${invNum}.pdf")
                }
                val shareUri = try {
                    androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.provider", shareFile)
                } catch (e: Exception) { android.net.Uri.fromFile(shareFile) }
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (file != null) Toast.makeText(this, "ذخیره در Downloads/HesabdarInvoices", Toast.LENGTH_LONG).show()
                startActivity(Intent.createChooser(share, "ارسال فاکتور PDF"))
            }
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
