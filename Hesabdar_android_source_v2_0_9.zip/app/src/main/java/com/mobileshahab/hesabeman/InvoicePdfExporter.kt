package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object InvoicePdfExporter {

    fun export(
        context: Context,
        uri: Uri,
        invoiceNumber: Int,
        buyerName: String,
        sellerName: String,
        sellerAddress: String,
        sellerPhone: String,
        sellerSlogan: String,
        items: List<InvoiceItem>,
        date: String,
        onDone: (Uri) -> Unit
    ): Boolean {
        return try {
            val pageW = 595; val pageH = 842
            val m = 36f // margin

            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
            val c = page.canvas

            // ── Paints ──
            val bold = Typeface.DEFAULT_BOLD
            val paintTitle = paint(18f, bold, align = Paint.Align.CENTER)
            val paintSub = paint(11f, align = Paint.Align.CENTER)
            val paintLabel = paint(10f, bold)
            val paintValue = paint(10f)
            val paintSmall = paint(9f, color = Color.GRAY)
            val paintHeader = paint(10f, bold, align = Paint.Align.CENTER)
            val paintCell = paint(10f, align = Paint.Align.CENTER)
            val paintTotal = paint(11f, bold)
            val linePaint = Paint().apply { color = Color.rgb(180, 180, 180); strokeWidth = 0.8f }
            val thickLine = Paint().apply { color = Color.rgb(0, 100, 80); strokeWidth = 2f }
            val fillPaint = Paint().apply { color = Color.rgb(220, 239, 229) }
            val fillDark = Paint().apply { color = Color.rgb(0, 100, 80) }

            var y = m

            // ── Top green bar (taller for bigger shop name) ──
            c.drawRect(m, y, pageW - m, y + 70f, fillDark)
            val paintShopName = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 22f; typeface = bold; color = Color.WHITE; textAlign = Paint.Align.CENTER
            }
            c.drawText(sellerName.ifBlank { "فاکتور فروش" }, pageW / 2f, y + 28f, paintShopName)
            if (sellerSlogan.isNotBlank()) {
                val paintWhiteSub = paint(11f, color = Color.WHITE, align = Paint.Align.CENTER)
                c.drawText(sellerSlogan, pageW / 2f, y + 48f, paintWhiteSub)
            }
            y += 76f

            // ── Invoice number + date (bigger) ──
            val paintInfoBig = paint(12f, bold)
            c.drawText("فاکتور شماره $invoiceNumber", pageW - m, y, paintInfoBig.apply { textAlign = Paint.Align.RIGHT })
            c.drawText("تاریخ: $date", m, y, paint(12f, color = Color.rgb(40,40,40), align = Paint.Align.LEFT))
            y += 22f

            // ── Buyer/Seller cards ──
            val cardH = 48f; val halfW = (pageW - 2 * m - 10f) / 2f
            val xRight = m; val xLeft = m + halfW + 10f
            for ((x, label, value) in listOf(
                Triple(xRight, "خریدار", buyerName),
                Triple(xLeft, "فروشنده", sellerName.ifBlank { "—" })
            )) {
                c.drawRect(x, y, x + halfW, y + cardH, fillPaint)
                c.drawRect(x, y, x + halfW, y + 18f, fillDark)
                val cx = x + halfW / 2f
                c.drawText(label, cx, y + 13f, paint(10f, bold, Color.WHITE, Paint.Align.CENTER))
                c.drawText(value, cx, y + 34f, paintCell)
            }
            y += cardH + 16f

            // ── Contact info below cards (with gap) ──
            if (sellerPhone.isNotBlank() || sellerAddress.isNotBlank()) {
                val contactPaint = paint(9f, color = Color.rgb(80, 80, 80), align = Paint.Align.CENTER)
                val contact = listOfNotNull(
                    sellerPhone.takeIf { it.isNotBlank() },
                    sellerAddress.takeIf { it.isNotBlank() }
                ).joinToString("   |   ")
                c.drawText(contact, pageW / 2f, y, contactPaint)
                y += 18f
            }
            y += 8f

            // ── Items table header ──
            val cols = floatArrayOf(m, m + 30f, m + 180f, m + 270f, m + 370f) // ردیف, کالا, مقدار, فی, جمع
            val colW = floatArrayOf(30f, 150f, 90f, 100f, pageW - m - 370f)
            c.drawRect(m, y, pageW - m, y + 20f, fillDark)
            val headers = listOf("ج", "جمع (تومان)", "فی (تومان)", "مقدار", "شرح کالا/خدمات", "رج")
            // RTL column order: رج | شرح | مقدار | فی | جمع
            val colCenters = floatArrayOf(
                pageW - m - 12f,        // رج
                pageW - m - 30f - 75f,  // شرح
                pageW - m - 30f - 150f - 45f,
                pageW - m - 30f - 150f - 90f - 50f,
                m + 52f
            )
            val hdr = listOf("رج", "شرح کالا/خدمات", "مقدار", "فی (تومان)", "جمع (تومان)")
            hdr.forEachIndexed { i, h ->
                c.drawText(h, colCenters[i], y + 14f, paint(9f, bold, Color.WHITE, Paint.Align.CENTER))
            }
            y += 22f

            // ── Item rows ──
            items.forEachIndexed { idx, item ->
                val rowBg = if (idx % 2 == 0) Color.WHITE else Color.rgb(245, 250, 247)
                c.drawRect(m, y, pageW - m, y + 22f, Paint().apply { color = rowBg })
                val vals = listOf(
                    "${idx + 1}",
                    if (item.name.length > 22) item.name.take(22) + "…" else item.name,
                    "%,d عدد".format(item.qty),
                    "%,d".format(item.unitPrice),
                    "%,d".format(item.total)
                )
                vals.forEachIndexed { i, v ->
                    c.drawText(v, colCenters[i], y + 15f, paintCell)
                }
                c.drawLine(m, y + 22f, pageW - m, y + 22f, linePaint)
                y += 24f
            }
            y += 8f
            c.drawLine(m, y, pageW - m, y, thickLine); y += 14f

            // ── Totals ──
            val grandTotal = items.sumOf { it.total }
            val summaryRows = listOf("جمع کل" to grandTotal, "دریافتی" to 0L, "قابل پرداخت" to grandTotal, "جمع اقلام" to items.size.toLong())
            summaryRows.forEach { (label, value) ->
                c.drawRect(m + 140f, y, pageW - m, y + 20f, fillPaint)
                val displayVal = if (label == "جمع اقلام") "$value" else "%,d".format(value)
                c.drawText(displayVal, m + 190f, y + 14f, paintTotal.apply { textAlign = Paint.Align.CENTER })
                c.drawText(label, pageW - m - 20f, y + 14f, paintLabel.apply { textAlign = Paint.Align.RIGHT })
                c.drawLine(m + 140f, y + 20f, pageW - m, y + 20f, linePaint)
                y += 22f
            }

            // ── Amount in words ──
            y += 8f
            c.drawRect(m, y, pageW - m, y + 22f, fillPaint)
            c.drawText("قابل پرداخت: ${amountInWords(grandTotal)} تومان", pageW / 2f, y + 15f, paintSub)
            y += 30f

            // ── Signature row ──
            val sigW = (pageW - 2 * m - 10f) / 2f
            for ((x, label) in listOf(m to "امضا فروشنده", m + sigW + 10f to "امضا خریدار")) {
                c.drawRect(x, y, x + sigW, y + 55f, fillPaint)
                c.drawRect(x, y, x + sigW, y + 18f, fillDark)
                c.drawText(label, x + sigW / 2f, y + 13f, paint(9f, bold, Color.WHITE, Paint.Align.CENTER))
            }

            doc.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Cannot open output")
            doc.close()
            Toast.makeText(context, "فاکتور PDF ذخیره شد.", Toast.LENGTH_LONG).show()
            onDone(uri)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ساخت PDF: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun paint(size: Float, face: Typeface = Typeface.DEFAULT, color: Int = Color.BLACK, align: Paint.Align = Paint.Align.RIGHT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; typeface = face; this.color = color; textAlign = align }

    private fun amountInWords(amount: Long): String {
        // Basic helper — just formats with commas, full word conversion is a separate library effort
        return "%,d".format(amount)
    }
}
