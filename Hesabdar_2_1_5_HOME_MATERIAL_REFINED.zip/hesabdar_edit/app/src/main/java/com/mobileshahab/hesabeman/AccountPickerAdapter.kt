package com.mobileshahab.hesabeman

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AccountPickerAdapter(
    private var items: List<NotebookListItem>,
    private val onClick: (NotebookListItem) -> Unit
) : RecyclerView.Adapter<AccountPickerAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.accountName)
        val phone: TextView = view.findViewById(R.id.accountPhone)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_account_picker, parent, false)
    )
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.name.text = item.name
        holder.phone.text = if (item.phone.isBlank()) "بدون شماره" else item.phone
        holder.itemView.setOnClickListener { onClick(item) }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<NotebookListItem>) { items = newItems; notifyDataSetChanged() }
}
