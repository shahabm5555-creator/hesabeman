package com.mobileshahab.hesabeman

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        // Font mode is handled by typeface below, not by fontScale, so cards keep
        // stable dimensions on small and large phones.
        super.attachBaseContext(newBase)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        if (AppPrefs.prefs(this).getString(AppPrefs.TEXT_SIZE, "normal") == "bold") {
            applyBold(window.decorView)
        }
    }

    private fun applyBold(view: View) {
        if (view is TextView) {
            view.setTypeface(view.typeface ?: Typeface.DEFAULT, Typeface.BOLD)
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyBold(view.getChildAt(i))
        }
    }
}
