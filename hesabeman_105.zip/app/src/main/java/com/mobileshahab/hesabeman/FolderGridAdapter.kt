package com.mobileshahab.hesabeman

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FolderGridAdapter(
    private var items: List<FolderItem>,
    private val onClick: (FolderItem) -> Unit,
    private val onLongClick: (FolderItem) -> Unit
) : RecyclerView.Adapter<FolderGridAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val accent: View = view.findViewById(R.id.folderAccent)
        val name: TextView = view.findViewById(R.id.folderName)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_folder_grid, parent, false)
    )
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]; holder.name.text = item.name
        val parsed = try { Color.parseColor(item.color) } catch (_: Exception) { Color.parseColor("#DCEFE5") }
        holder.accent.setBackgroundColor(parsed)
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }
    override fun getItemCount() = items.size
    fun submit(newItems: List<FolderItem>) { items = newItems; notifyDataSetChanged() }
}
