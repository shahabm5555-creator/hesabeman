package com.mobileshahab.hesabeman

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InvoiceListActivity : AppCompatActivity() {

    private lateinit var db: DbHelper
    private var notebookId: Long = -1
    private var notebookName: String = ""
    private var notebookPhone: String = ""
    private lateinit var listContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", -1)
        notebookName = intent.getStringExtra("notebook_name") ?: ""
        notebookPhone = intent.getStringExtra("notebook_phone") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.background))
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                v.setPadding(0, bars.top, 0, bars.bottom); insets
            }
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(-1, dp(64))
            setBackgroundColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.surface))
        }
        val backBtn = MaterialButton(this).apply {
            text = "×"; textSize = 22f; minWidth = 0; insetTop = 0; insetBottom = 0
            setPadding(dp(8), 0, dp(8), 0)
            backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.text))
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "فاکتورهای $notebookName"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val newBtn = MaterialButton(this).apply {
            text = "+ جدید"; textSize = 12f; cornerRadius = dp(14); insetTop = 0; insetBottom = 0
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(-2, dp(40))
            setOnClickListener {
                val i = Intent(this@InvoiceListActivity, InvoiceActivity::class.java).apply {
                    putExtra("notebook_id", notebookId)
                    putExtra("notebook_name", notebookName)
                    putExtra("notebook_phone", notebookPhone)
                }
                startActivityForResult(i, 100)
            }
        }
        toolbar.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        toolbar.addView(title)
        toolbar.addView(newBtn)
        root.addView(toolbar)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(16))
        }
        listContainer = inner
        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadList()
    }

    private fun loadList() {
        listContainer.removeAllViews()
        val invoices = db.invoices(notebookId)
        if (invoices.isEmpty()) {
            val empty = TextView(this).apply {
                text = "هیچ فاکتوری ثبت نشده"; textSize = 14f; gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
                setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.secondary))
            }
            listContainer.addView(empty)
            return
        }
        invoices.forEach { inv ->
            val card = MaterialCardView(this).apply {
                radius = dp(16).toFloat(); cardElevation = dp(1).toFloat()
                setCardBackgroundColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.surface))
                strokeWidth = dp(1); strokeColor = ContextCompat.getColor(this@InvoiceListActivity, R.color.divider)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            }

            // Header row
            val headerRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val kindColor = if (inv.kind == "debt") ContextCompat.getColor(this, R.color.debt_text)
                           else ContextCompat.getColor(this, R.color.credit_text)
            val kindText = if (inv.kind == "debt") "↑ پرداختی" else "↓ دریافتی"
            val kindPill = TextView(this).apply {
                text = kindText; textSize = 10f; setTextColor(kindColor)
                backgroundTintList = ColorStateList.valueOf(
                    if (inv.kind == "debt") ContextCompat.getColor(this@InvoiceListActivity, R.color.debt_soft)
                    else ContextCompat.getColor(this@InvoiceListActivity, R.color.credit_soft))
                background = ContextCompat.getDrawable(this@InvoiceListActivity, R.drawable.bg_status_pill)
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }
            val invTitle = TextView(this).apply {
                text = "فاکتور شماره ${inv.number}"; textSize = 14f
                setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.text))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            headerRow.addView(kindPill); headerRow.addView(invTitle)
            box.addView(headerRow)

            // Date + amount
            val infoRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            }
            val dateText = TextView(this).apply {
                text = inv.createdAt; textSize = 11f
                setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.secondary))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val remaining = (inv.total - inv.prepay).coerceAtLeast(0L)
            val amtText = TextView(this).apply {
                text = "%,d تومان".format(remaining); textSize = 13f
                setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.primary))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            infoRow.addView(dateText); infoRow.addView(amtText)
            box.addView(infoRow)

            if (inv.note.isNotBlank()) {
                box.addView(TextView(this).apply {
                    text = inv.note; textSize = 11f
                    setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.secondary))
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
                })
            }

            // Action buttons
            val btnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            }
            fun actionBtn(label: String, bgColor: Int, textColor: Int, action: () -> Unit) =
                MaterialButton(this).apply {
                    text = label; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
                    backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@InvoiceListActivity, bgColor))
                    setTextColor(ContextCompat.getColor(this@InvoiceListActivity, textColor))
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) }
                    setOnClickListener { action() }
                }

            val shareBtn = actionBtn("اشتراک/PDF", R.color.primary_soft, R.color.primary) { sharePdf(inv) }
            val editBtn = actionBtn("ویرایش", R.color.neutral_soft, R.color.text) { editInvoice(inv) }
            btnRow.addView(shareBtn); btnRow.addView(editBtn)
            box.addView(btnRow)

            card.addView(box)
            listContainer.addView(card)
        }
    }

    private fun sharePdf(inv: DbHelper.InvoiceHeader) {
        val items = db.invoiceItems(inv.id)
        val prefs = getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE)
        val sellerName = prefs.getString(AppPrefs.SELLER_NAME, "") ?: ""
        val sellerAddress = prefs.getString(AppPrefs.SELLER_ADDRESS, "") ?: ""
        val sellerPhone = prefs.getString(AppPrefs.SELLER_PHONE, "") ?: ""
        val sellerSlogan = prefs.getString(AppPrefs.SELLER_SLOGAN, "") ?: ""
        val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val pdfDir = java.io.File(dir, "hesabdar/hPdf").also { it.mkdirs() }
        val file = java.io.File(pdfDir, "فاکتور-${notebookName.replace("/","-")}-شماره${inv.number}.pdf")
        val uri = Uri.fromFile(file)
        InvoicePdfExporter.export(
            context = this, uri = uri, invoiceNumber = inv.number,
            buyerName = notebookName, buyerPhone = notebookPhone,
            sellerName = sellerName, sellerAddress = sellerAddress,
            sellerPhone = sellerPhone, sellerSlogan = sellerSlogan,
            items = items, date = inv.createdAt, prepay = inv.prepay,
            onDone = {
                val shareUri = try {
                    androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.provider", file)
                } catch (e: Exception) { Uri.fromFile(file) }
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "ارسال فاکتور"))
            }
        )
    }

    private fun editInvoice(inv: DbHelper.InvoiceHeader) {
        val items = db.invoiceItems(inv.id).toMutableList()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        // Items list with delete
        val itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshItems() {
            itemsBox.removeAllViews()
            items.forEachIndexed { idx, item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                val info = TextView(this).apply {
                    text = "${item.name}  ×${item.qty}  @${ "%,d".format(item.unitPrice) } = ${"%,d".format(item.total)} تومان"
                    textSize = 11f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.text))
                }
                val del = MaterialButton(this).apply {
                    text = "×"; textSize = 14f; minWidth = 0; insetTop = 0; insetBottom = 0
                    setPadding(dp(8), 0, dp(8), 0)
                    backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                    setTextColor(ContextCompat.getColor(this@InvoiceListActivity, R.color.debt_text))
                    setOnClickListener { items.removeAt(idx); refreshItems() }
                }
                row.addView(info); row.addView(del)
                itemsBox.addView(row)
            }
        }
        refreshItems()

        val addItemBtn = MaterialButton(this).apply {
            text = "+ افزودن قلم"; textSize = 12f; cornerRadius = dp(12); insetTop = 0; insetBottom = 0
            layoutParams = LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(8) }
            setOnClickListener {
                val iBox = LinearLayout(this@InvoiceListActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(16), dp(4), dp(16), dp(4))
                }
                fun ef(hint: String) = EditText(this@InvoiceListActivity).apply {
                    this.hint = hint; textSize = 13f; gravity = Gravity.END
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
                }
                val nf = ef("نام کالا/خدمات"); val qf = ef("مقدار").apply { inputType = android.text.InputType.TYPE_CLASS_PHONE; setText("1") }
                val pf = ef("فی (تومان)").apply { inputType = android.text.InputType.TYPE_CLASS_PHONE }
                iBox.addView(nf); iBox.addView(qf); iBox.addView(pf)
                MaterialAlertDialogBuilder(this@InvoiceListActivity).setTitle("افزودن قلم").setView(iBox)
                    .setPositiveButton("افزودن") { _, _ ->
                        val n = nf.text.toString().trim()
                        val q = qf.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val p = pf.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        if (n.isNotBlank() && q > 0 && p > 0) { items.add(InvoiceItem(name = n, qty = q, unitPrice = p)); refreshItems() }
                        else Toast.makeText(this@InvoiceListActivity, "اطلاعات ناقص.", Toast.LENGTH_SHORT).show()
                    }.setNegativeButton("انصراف", null).show()
            }
        }

        // Kind selector
        val kindGroup = android.widget.RadioGroup(this).apply {
            orientation = android.widget.RadioGroup.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        val rdDebt = android.widget.RadioButton(this).apply {
            id = View.generateViewId(); text = "↑ پرداختی"; layoutParams = android.widget.RadioGroup.LayoutParams(0, -2, 1f)
            isChecked = inv.kind == "debt"
        }
        val rdCredit = android.widget.RadioButton(this).apply {
            id = View.generateViewId(); text = "↓ دریافتی"; layoutParams = android.widget.RadioGroup.LayoutParams(0, -2, 1f)
            isChecked = inv.kind == "credit"
        }
        kindGroup.addView(rdDebt); kindGroup.addView(rdCredit)
        if (inv.kind == "debt") kindGroup.check(rdDebt.id) else kindGroup.check(rdCredit.id)

        // Prepay field
        val prepayField = EditText(this).apply {
            hint = "پیش‌پرداخت (تومان)"; textSize = 13f; gravity = Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setText(if (inv.prepay > 0) "%,d".format(inv.prepay) else "")
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }

        box.addView(itemsBox); box.addView(addItemBtn)
        box.addView(TextView(this).apply { text = "نوع تراکنش"; textSize = 11f; setPadding(0, dp(10), 0, 0) })
        box.addView(kindGroup); box.addView(prepayField)

        MaterialAlertDialogBuilder(this).setTitle("ویرایش فاکتور شماره ${inv.number}")
            .setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                if (items.isEmpty()) { Toast.makeText(this, "حداقل یک قلم لازم است.", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val newKind = if (kindGroup.checkedRadioButtonId == rdDebt.id) "debt" else "credit"
                val newPrepay = prepayField.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                db.updateInvoice(inv.id, notebookId, newKind, items, inv.note, newPrepay)
                Toast.makeText(this, "فاکتور ویرایش شد.", Toast.LENGTH_SHORT).show()
                loadList()
            }
            .setNegativeButton("انصراف", null).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) loadList()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
