package com.mobileshahab.hesabeman

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatDelegate

class HesabemanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Never auto-restore an external backup at startup. A backup can never
        // overwrite live financial data without an explicit user action.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        val handler = Handler(Looper.getMainLooper())
        var started = 0
        val saveRunnable = Runnable { Thread { runCatching { BackupManager.maybeAutoBackup(this) } }.start() }
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                started++
                handler.removeCallbacks(saveRunnable)
            }
            override fun onActivityStopped(activity: Activity) {
                started = (started - 1).coerceAtLeast(0)
                if (started == 0) {
                    // Give the activity a short grace period for the last DB transaction to finish.
                    handler.removeCallbacks(saveRunnable)
                    handler.postDelayed(saveRunnable, 700L)
                }
            }
            override fun onActivityCreated(a: Activity, s: android.os.Bundle?) = Unit
            override fun onActivityResumed(a: Activity) = Unit
            override fun onActivityPaused(a: Activity) = Unit
            override fun onActivitySaveInstanceState(a: Activity, outState: android.os.Bundle) = Unit
            override fun onActivityDestroyed(a: Activity) = Unit
        })
    }
}
