package com.mobileshahab.hesabeman

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mobileshahab.hesabeman.databinding.ActivitySearchBinding

class SearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySearchBinding.inflate(layoutInflater); setContentView(b.root)
        val db = DbHelper(this)
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.search.setOnClickListener {
            val q = b.query.text.toString().trim()
            b.results.text = if (q.isBlank()) "عبارت جستجو را وارد کنید."
            else db.search(q).joinToString("\n\n").ifBlank { "نتیجه‌ای پیدا نشد." }
        }
    }
}
