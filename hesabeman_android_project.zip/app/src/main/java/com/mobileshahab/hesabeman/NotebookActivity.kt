package com.mobileshahab.hesabeman

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivityNotebookBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotebookActivity : AppCompatActivity() {
    private lateinit var b: ActivityNotebookBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: SimpleAdapter
    private var notebookId = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNotebookBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        notebookId = intent.getLongExtra("notebook_id", 0)
        b.toolbar.title = intent.getStringExtra("notebook_name") ?: "دفترچه حساب"
        b.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        b.toolbar.setNavigationOnClickListener { finish() }

        adapter = SimpleAdapter(emptyList()) {}
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter

        b.addDebt.setOnClickListener { add("debt", "ثبت بدهکار") }
        b.addCredit.setOnClickListener { add("credit", "ثبت بستانکار") }
    }

    private fun add(kind: String, title: String) {
        promptTransaction(this, title) { amount, note ->
            val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("fa")).format(Date())
            db.addTx(notebookId, kind, amount, note, date)
            refresh()
        }
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        adapter.submit(db.tx(notebookId))
        val x = db.balance(notebookId)
        b.balance.text = "${"%,d".format(kotlin.math.abs(x))} تومان ${if (x >= 0) "بستانکار" else "بدهکار"}"
    }
}
