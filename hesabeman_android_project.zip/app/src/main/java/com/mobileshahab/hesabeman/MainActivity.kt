package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.mobileshahab.hesabeman.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var adapter: SimpleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        db = DbHelper(this)
        adapter = SimpleAdapter(emptyList()) {
            startActivity(Intent(this, FolderActivity::class.java)
                .putExtra("folder_id", it.id).putExtra("folder_name", it.title))
        }
        b.list.layoutManager = LinearLayoutManager(this); b.list.adapter = adapter
        b.add.setOnClickListener { promptText(this, "پوشه جدید", "نام پوشه") { name -> db.addFolder(null, name); refresh() } }
        b.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.search -> startActivity(Intent(this, SearchActivity::class.java))
                R.id.backup -> BackupManager.backup(this)
                R.id.about -> startActivity(Intent(this, AboutActivity::class.java))
            }
            true
        }
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        val items = db.folders(null)
        adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
