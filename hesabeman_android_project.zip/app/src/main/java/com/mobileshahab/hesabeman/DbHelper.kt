package com.mobileshahab.hesabeman

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RowItem(val id: Long, val title: String)

class DbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, 1) {
    companion object { const val DB_NAME = "hesabeman.db" }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE folders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER,
            name TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE notebooks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            name TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notebook_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            amount INTEGER NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addFolder(parentId: Long?, name: String) {
        writableDatabase.insert("folders", null, ContentValues().apply {
            if (parentId == null) putNull("parent_id") else put("parent_id", parentId)
            put("name", name)
        })
    }

    fun folders(parentId: Long?): List<RowItem> {
        val out = mutableListOf<RowItem>()
        val sql = if (parentId == null)
            "SELECT id,name FROM folders WHERE parent_id IS NULL ORDER BY id DESC"
        else "SELECT id,name FROM folders WHERE parent_id=? ORDER BY id DESC"
        val args = if (parentId == null) null else arrayOf(parentId.toString())
        readableDatabase.rawQuery(sql, args).use {
            while (it.moveToNext()) out += RowItem(it.getLong(0), it.getString(1))
        }
        return out
    }

    fun addNotebook(folderId: Long, name: String) {
        writableDatabase.insert("notebooks", null, ContentValues().apply {
            put("folder_id", folderId); put("name", name)
        })
    }

    fun notebooks(folderId: Long): List<RowItem> {
        val out = mutableListOf<RowItem>()
        readableDatabase.rawQuery(
            "SELECT id,name FROM notebooks WHERE folder_id=? ORDER BY id DESC",
            arrayOf(folderId.toString())
        ).use { while (it.moveToNext()) out += RowItem(it.getLong(0), it.getString(1)) }
        return out
    }

    fun addTx(notebookId: Long, kind: String, amount: Long, note: String, date: String) {
        writableDatabase.insert("tx", null, ContentValues().apply {
            put("notebook_id", notebookId); put("kind", kind); put("amount", amount)
            put("note", note); put("created_at", date)
        })
    }

    fun tx(notebookId: Long): List<RowItem> {
        val out = mutableListOf<RowItem>()
        readableDatabase.rawQuery(
            "SELECT id,kind,amount,note,created_at FROM tx WHERE notebook_id=? ORDER BY id DESC",
            arrayOf(notebookId.toString())
        ).use {
            while (it.moveToNext()) {
                val kind = if (it.getString(1) == "debt") "بدهکار" else "بستانکار"
                val amount = "%,d".format(it.getLong(2))
                val note = it.getString(3).orEmpty()
                out += RowItem(it.getLong(0), "$kind — $amount تومان\n$note\n${it.getString(4)}")
            }
        }
        return out
    }

    fun balance(notebookId: Long): Long {
        readableDatabase.rawQuery(
            """SELECT COALESCE(SUM(CASE WHEN kind='credit' THEN amount ELSE -amount END),0)
               FROM tx WHERE notebook_id=?""",
            arrayOf(notebookId.toString())
        ).use { if (it.moveToFirst()) return it.getLong(0) }
        return 0
    }

    fun search(q: String): List<String> {
        val x = "%$q%"
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM folders WHERE name LIKE ? LIMIT 20", arrayOf(x))
            .use { while (it.moveToNext()) out += "پوشه: ${it.getString(0)}" }
        readableDatabase.rawQuery("SELECT name FROM notebooks WHERE name LIKE ? LIMIT 20", arrayOf(x))
            .use { while (it.moveToNext()) out += "دفترچه: ${it.getString(0)}" }
        readableDatabase.rawQuery(
            """SELECT n.name,t.kind,t.amount,t.note,t.created_at
               FROM tx t JOIN notebooks n ON n.id=t.notebook_id
               WHERE t.note LIKE ? OR CAST(t.amount AS TEXT) LIKE ? LIMIT 30""",
            arrayOf(x, x)
        ).use {
            while (it.moveToNext()) {
                val kind = if (it.getString(1) == "debt") "بدهکار" else "بستانکار"
                out += "${it.getString(0)} — $kind — ${"%,d".format(it.getLong(2))} تومان\n${it.getString(3).orEmpty()} | ${it.getString(4)}"
            }
        }
        return out
    }
}
