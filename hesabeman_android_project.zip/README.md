# حسابدار من

اپلیکیشن اندروید «حسابدار من» با رابط کاملاً فارسی و RTL.

- Package: `com.mobileshahab.hesabeman`
- Version name: `01`
- پوشه و زیرپوشه
- دفترچه حساب
- ثبت بدهکار / بستانکار
- محاسبه مانده
- جستجو
- بکاپ دیتابیس در `Download/hesabeman`
- صفحه درباره موبایل شهاب
- GitHub Actions برای اجرای `assembleDebug` و انتشار APK به‌عنوان Artifact

## ساخت APK در GitHub

پس از Push به `main` یا `master`، وارد تب **Actions** شوید و Workflow با نام **Android Debug APK** را باز کنید.
بعد از موفقیت Build، فایل Artifact با نام `hesabeman-debug-apk` قابل دریافت است.
