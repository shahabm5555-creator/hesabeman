package com.mobileshahab.hesabeman

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mobileshahab.hesabeman.databinding.ActivityLockBinding

class LockActivity : BaseActivity() {
    private lateinit var b: ActivityLockBinding
    private var authenticated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLockBinding.inflate(layoutInflater); setContentView(b.root)

        // DATA CENTER: the two external database files are authoritative.
        // Synchronize them BEFORE any DbHelper/MainActivity instance is created.
        BackupManager.initializeDataCenter(this)

        // A reinstall removes the private DB. External backups live in Download and
        // therefore survive uninstall. Detect them before entering the app and ask
        // the user explicitly; never overwrite data silently at startup.
        val backupUri = BackupManager.findBestExternalBackup(this)
        val fresh = BackupManager.isFreshDatabase(this)
        // Two recovery situations are supported:
        // 1) reinstall -> new/fresh private DB while an old external backup exists
        // 2) user manually copies an old backup over the canonical file after launch
        //    -> the external DB differs from the live DB and must be offered for restore.
        val externalChanged = if (backupUri != null && !fresh) {
            BackupManager.hasExternalBackupDifferentFromLive(this)
        } else false

        if (backupUri != null && (fresh || externalChanged)) {
            MaterialAlertDialogBuilder(this)
                .setTitle(if (fresh) "پشتیبان قدیمی پیدا شد" else "پشتیبان خارجی جدید پیدا شد")
                .setMessage(
                    if (fresh) {
                        "یک پشتیبان معتبر در Download/Hesabdarman پیدا شد.\n\n" +
                        "اطلاعات فعلی برنامه خالی است. برای جلوگیری از از بین رفتن پشتیبان، قبل از ثبت تراکنش می‌توانید اطلاعات قدیمی را بازیابی کنید."
                    } else {
                        "محتوای فایل پشتیبان با اطلاعات فعلی برنامه متفاوت است.\n\n" +
                        "احتمالاً یک فایل پشتیبان قدیمی را در پوشه Hesabdarman جایگزین کرده‌اید. آیا می‌خواهید همین فایل را روی دیتابیس برنامه بازیابی کنیم؟"
                    }
                )
                .setPositiveButton("بازیابی") { _, _ ->
                    if (BackupManager.restore(this, backupUri)) {
                        Toast.makeText(this, "اطلاعات با موفقیت بازیابی شد.", Toast.LENGTH_LONG).show()
                    }
                    continueToApp()
                }
                .setNegativeButton("فعلاً نه") { _, _ -> continueToApp() }
                .setOnCancelListener { continueToApp() }
                .show()
        } else {
            continueToApp()
        }
    }

    private fun continueToApp() {
        val mode = AppPrefs.prefs(this).getString(AppPrefs.LOCK_MODE, "off") ?: "off"
        when (mode) {
            "pin" -> showPin()
            "biometric" -> showBiometric()
            else -> enterApp()
        }
    }

    private fun showPin() {
        b.pinBox.visibility = View.VISIBLE
        b.biometricMessage.visibility = View.GONE
        b.unlock.setOnClickListener {
            val pin = b.pin.text.toString()
            val saved = AppPrefs.prefs(this).getString(AppPrefs.PIN_HASH, "")
            if (pin.length == 4 && AppPrefs.hashPin(pin) == saved) enterApp()
            else {
                b.pin.text?.clear()
                Toast.makeText(this, "رمز نادرست است.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showBiometric() {
        b.pinBox.visibility = View.GONE
        b.biometricMessage.visibility = View.VISIBLE
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            b.biometricMessage.text = "اثر انگشت در دسترس نیست. از تنظیمات سیستم آن را فعال کنید."
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result); enterApp()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                b.biometricMessage.text = "برای ورود، دوباره اثر انگشت را امتحان کنید."
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ورود به حسابدار شخصی")
            .setSubtitle("اثر انگشت خود را تأیید کنید")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .setNegativeButtonText("انصراف")
            .build()
        b.biometricMessage.setOnClickListener { prompt.authenticate(info) }
        prompt.authenticate(info)
    }

    private fun enterApp() {
        if (authenticated) return
        authenticated = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
